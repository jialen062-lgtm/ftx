package com.niejiale.zonetask.network;

import com.niejiale.zonetask.client.ClientPacketHandler;
import com.niejiale.zonetask.zone.Zone;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** S2C：某维度下全部已保存区域。 */
public record SyncZonesPacket(ResourceLocation dim, List<Zone> zones) {
    public void encode(FriendlyByteBuf buf) {
        buf.writeResourceLocation(dim);
        buf.writeVarInt(zones.size());
        for (Zone z : zones) z.write(buf);
    }

    public static SyncZonesPacket decode(FriendlyByteBuf buf) {
        ResourceLocation dim = buf.readResourceLocation();
        int n = buf.readVarInt();
        List<Zone> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) list.add(Zone.read(buf));
        return new SyncZonesPacket(dim, list);
    }

    public static void handle(SyncZonesPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.onZones(msg)));
        ctx.get().setPacketHandled(true);
    }
}
