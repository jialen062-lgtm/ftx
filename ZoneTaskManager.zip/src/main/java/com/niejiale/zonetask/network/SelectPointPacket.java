package com.niejiale.zonetask.network;

import com.niejiale.zonetask.ModItems;
import com.niejiale.zonetask.zone.SelectionManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** C2S：isA=true 记录点 A（左键），false 记录点 B（右键）。 */
public record SelectPointPacket(boolean isA, BlockPos pos) {
    public void encode(FriendlyByteBuf buf) { buf.writeBoolean(isA); buf.writeBlockPos(pos); }
    public static SelectPointPacket decode(FriendlyByteBuf buf) { return new SelectPointPacket(buf.readBoolean(), buf.readBlockPos()); }

    public static void handle(SelectPointPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p == null) return;
            // 服务端校验：必须手持该物品，且距离合理（防作弊）
            if (!p.getMainHandItem().is(ModItems.ZONE_DIVIDER.get())) return;
            if (p.distanceToSqr(Vec3.atCenterOf(msg.pos)) > 12 * 12) return;
            SelectionManager.set(p, msg.isA, msg.pos);
            p.displayClientMessage(Component.literal("已记录点 " + (msg.isA ? "A" : "B") + ": "
                    + msg.pos.getX() + ", " + msg.pos.getY() + ", " + msg.pos.getZ()), true);
        });
        ctx.get().setPacketHandled(true);
    }
}
