package com.niejiale.zonetask.task;

import com.niejiale.zonetask.ModItems;
import com.niejiale.zonetask.ZoneTaskMod;
import com.niejiale.zonetask.command.PyCommand;
import com.niejiale.zonetask.network.EvacStatePacket;
import com.niejiale.zonetask.network.ZoneNetwork;
import com.niejiale.zonetask.zone.SelectionManager;
import com.niejiale.zonetask.zone.Zone;
import com.niejiale.zonetask.zone.ZoneStorage;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;

/** 服务端事件：生命周期、死亡监听、玩家同步、拦截划分器的方块交互。 */
@Mod.EventBusSubscriber(modid = ZoneTaskMod.MODID)
public final class TaskEvents {

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent e) { ZoneStorage.onServerStart(e.getServer()); }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        ZoneStorage.onServerStop();
        EvacuationManager.reset();
        SelectionManager.clear();
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) { PyCommand.register(e.getDispatcher()); }

    /**
     * 监听 LivingDeathEvent：
     *  - 仅服务端处理；LOWEST 且不接收已取消事件，避免统计到被其他模组/脚本取消的“假死亡”
     *  - 死者必须是 CNPC 的 NPC 且阵营为 Aggressive（SuspectChecker）
     *  - 找到包含死者位置的区域，重新扫描该区域存活嫌疑人，归零则进入阶段二
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDeath(LivingDeathEvent e) {
        LivingEntity dead = e.getEntity();
        if (!(dead.level() instanceof ServerLevel level) || level.isClientSide) return;
        if (!SuspectChecker.isSuspect(dead, level)) return;

        ResourceLocation dim = level.dimension().location();
        for (Zone zone : new ArrayList<>(ZoneStorage.zones(dim).values())) {
            if (!zone.contains(dead.position())) continue;
            if (SuspectChecker.countAlive(level, zone, dead) == 0) {
                EvacuationManager.start(level.getServer(), zone);
            }
        }
    }

    // ---------- 玩家同步 ----------
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ZoneNetwork.syncZones(p);
        SelectionManager.send(p);
        ZoneNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new EvacStatePacket(EvacuationManager.isActive()));
    }

    @SubscribeEvent
    public static void onChangeDim(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) { ZoneNetwork.syncZones(p); SelectionManager.send(p); }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) { ZoneNetwork.syncZones(p); SelectionManager.send(p); }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        SelectionManager.remove(p.getUUID());
        EvacuationManager.onLogout(p);
    }

    // ---------- 服务端兜底：手持划分器时不允许破坏/放置/交互方块 ----------
    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (!e.getLevel().isClientSide() && e.getEntity().getMainHandItem().is(ModItems.ZONE_DIVIDER.get())) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock e) {
        if (!e.getLevel().isClientSide() && e.getEntity().getMainHandItem().is(ModItems.ZONE_DIVIDER.get())) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    private TaskEvents() {}
}
