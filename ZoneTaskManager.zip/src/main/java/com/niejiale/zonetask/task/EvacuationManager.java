package com.niejiale.zonetask.task;

import com.niejiale.zonetask.config.ZoneConfig;
import com.niejiale.zonetask.network.EvacStatePacket;
import com.niejiale.zonetask.network.ZoneNetwork;
import com.niejiale.zonetask.zone.Zone;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;

/** 阶段二：全员撤离投票 + 传送结算（仅服务端、仅主线程访问）。 */
public final class EvacuationManager {
    private static boolean active = false;
    private static final Set<UUID> ready = new HashSet<>();

    public static boolean isActive() { return active; }

    public static void start(MinecraftServer server, Zone zone) {
        if (active) return;
        active = true;
        ready.clear();
        broadcast(server, Component.literal("已清除所有嫌疑人，按 P 键撤离").withStyle(ChatFormatting.GREEN));
        ZoneNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new EvacStatePacket(true));
    }

    /** 玩家按下 P（EvacReadyPacket） */
    public static void onReady(ServerPlayer p) {
        if (!active) return;
        if (!ready.add(p.getUUID())) return;          // 重复按键忽略
        MinecraftServer server = p.server;
        int remaining = remaining(server, null);
        broadcast(server, Component.literal("[" + p.getGameProfile().getName() + "] 已准备撤离，还剩 " + remaining + " 人未准备"));
        if (remaining == 0) settle(server);
    }

    /** 玩家下线：移除其投票；若剩余在线玩家都已准备，则直接结算 */
    public static void onLogout(ServerPlayer p) {
        ready.remove(p.getUUID());
        if (!active) return;
        MinecraftServer server = p.server;
        boolean othersOnline = server.getPlayerList().getPlayers().stream().anyMatch(o -> o != p);
        if (othersOnline && remaining(server, p) == 0) settle(server);
    }

    private static int remaining(MinecraftServer server, ServerPlayer exclude) {
        int n = 0;
        for (ServerPlayer o : server.getPlayerList().getPlayers()) {
            if (o != exclude && !ready.contains(o.getUUID())) n++;
        }
        return n;
    }

    private static void settle(MinecraftServer server) {
        Optional<Vec3> target = ZoneConfig.getTarget();
        if (target.isEmpty()) {
            broadcast(server, Component.literal("坐标不存在！").withStyle(ChatFormatting.RED));
            ready.clear();     // 保持撤离阶段，配置修好后可重新按 P
            return;
        }
        Vec3 t = target.get();
        ResourceLocation dimId = ResourceLocation.tryParse(ZoneConfig.DIMENSION.get().trim());
        ServerLevel fixed = dimId == null ? null : server.getLevel(ResourceKey.create(net.minecraft.core.registries.Registries.DIMENSION, dimId));
        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            ServerLevel dest = fixed != null ? fixed : p.serverLevel();
            p.stopRiding();
            p.teleportTo(dest, t.x, t.y, t.z, p.getYRot(), p.getXRot());
        }
        reset();
        ZoneNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new EvacStatePacket(false));
    }

    public static void reset() {
        active = false;
        ready.clear();
    }

    private static void broadcast(MinecraftServer server, Component c) {
        server.getPlayerList().broadcastSystemMessage(c, false);
    }

    private EvacuationManager() {}
}
