package com.niejiale.zonetask.config;

import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeConfigSpec;

import java.util.Optional;

public final class ZoneConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.ConfigValue<String> X, Y, Z, DIMENSION;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("撤离传送设置。x / y / z 留空表示未设置，此时触发撤离会提示“坐标不存在！”").push("evacuation");
        X = b.comment("撤离传送 X 坐标").define("x", "");
        Y = b.comment("撤离传送 Y 坐标").define("y", "");
        Z = b.comment("撤离传送 Z 坐标").define("z", "");
        DIMENSION = b.comment("撤离目标维度，例如 minecraft:overworld；留空 = 玩家当前所在维度").define("dimension", "");
        b.pop();
        SPEC = b.build();
    }

    /** 三个坐标都是合法数字才返回，否则 empty（= 坐标不存在） */
    public static Optional<Vec3> getTarget() {
        try {
            String x = X.get().trim(), y = Y.get().trim(), z = Z.get().trim();
            if (x.isEmpty() || y.isEmpty() || z.isEmpty()) return Optional.empty();
            return Optional.of(new Vec3(Double.parseDouble(x), Double.parseDouble(y), Double.parseDouble(z)));
        } catch (NumberFormatException ex) {
            return Optional.empty();
        }
    }

    private ZoneConfig() {}
}
