package com.niejiale.zonetask.client;

import com.niejiale.zonetask.zone.Zone;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/** 客户端缓存：由 S2C 数据包写入，渲染/按键逻辑读取。 */
public final class ClientState {
    public static ResourceLocation zonesDim = null;
    public static List<Zone> zones = List.of();
    public static ResourceLocation selDim = null;
    public static BlockPos selA = null, selB = null;
    public static boolean evacActive = false;

    public static void reset() {
        zonesDim = null; zones = List.of(); selDim = null; selA = null; selB = null; evacActive = false;
    }

    private ClientState() {}
}
