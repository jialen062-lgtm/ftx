package noppes.npcs.api.handler.data;
import noppes.npcs.api.entity.IPlayer;
public interface IFaction {
    int playerStatus(IPlayer<?> player);
}
