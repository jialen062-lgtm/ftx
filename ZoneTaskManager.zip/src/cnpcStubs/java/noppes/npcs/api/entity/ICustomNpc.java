package noppes.npcs.api.entity;
import noppes.npcs.api.handler.data.IFaction;
public interface ICustomNpc<T> extends IEntity<T> {
    IFaction getFaction();
}
