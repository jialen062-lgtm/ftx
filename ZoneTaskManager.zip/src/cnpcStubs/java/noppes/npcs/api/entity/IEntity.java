package noppes.npcs.api.entity;
public interface IEntity<T> { }
