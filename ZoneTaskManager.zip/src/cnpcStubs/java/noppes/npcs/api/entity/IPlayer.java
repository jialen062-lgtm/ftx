package noppes.npcs.api.entity;
public interface IPlayer<T> extends IEntity<T> { }
