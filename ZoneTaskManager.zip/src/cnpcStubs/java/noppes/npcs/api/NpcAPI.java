package noppes.npcs.api;

import noppes.npcs.api.entity.IEntity;

/** 仅用于编译的桩类（不会打进模组 jar）。运行时使用真实的 CNPC。 */
public abstract class NpcAPI {
    public static NpcAPI Instance() { throw new UnsupportedOperationException("stub"); }
    public abstract IEntity<?> getIEntity(Object entity);
}
