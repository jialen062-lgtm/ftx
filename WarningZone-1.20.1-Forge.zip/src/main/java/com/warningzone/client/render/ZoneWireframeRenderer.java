package com.warningzone.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.warningzone.WarningZoneMod;
import com.warningzone.client.ClientZoneCache;
import com.warningzone.data.NameColor;
import com.warningzone.data.WarningZoneData;
import com.warningzone.item.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = WarningZoneMod.MOD_ID, value = Dist.CLIENT)
public final class ZoneWireframeRenderer {
    private ZoneWireframeRenderer() {
    }

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.level == null) {
            return;
        }

        // 仅当玩家主手或副手持「警告区域器」时渲染边界线框，否则隐藏
        boolean holdingWand = player.getMainHandItem().is(ModItems.WARNING_ZONE_WAND.get())
                || player.getOffhandItem().is(ModItems.WARNING_ZONE_WAND.get());
        if (!holdingWand) {
            return;
        }

        Vec3 camPos = event.getCamera().getPosition();
        PoseStack poseStack = event.getPoseStack();
        poseStack.pushPose();
        poseStack.translate(-camPos.x, -camPos.y, -camPos.z);

        MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        VertexConsumer consumer = bufferSource.getBuffer(RenderType.lines());

        // 1. 渲染当前维度已保存的所有警告区域边界线框
        for (WarningZoneData zone : ClientZoneCache.getZones()) {
            NameColor color = zone.getWarnerColor();
            LevelRenderer.renderLineBox(
                    poseStack,
                    consumer,
                    zone.toAABB().inflate(0.002D),
                    color.getR(), color.getG(), color.getB(), 1.0F
            );
        }

        // 2. 渲染正在框选中的 A/B 临时选区预览（绿色/黄色）
        BlockPos posA = ClientZoneCache.getPendingPosA();
        BlockPos posB = ClientZoneCache.getPendingPosB();
        if (posA != null && posB != null) {
            AABB preview = new AABB(
                    Math.min(posA.getX(), posB.getX()),
                    Math.min(posA.getY(), posB.getY()),
                    Math.min(posA.getZ(), posB.getZ()),
                    Math.max(posA.getX(), posB.getX()) + 1.0D,
                    Math.max(posA.getY(), posB.getY()) + 1.0D,
                    Math.max(posA.getZ(), posB.getZ()) + 1.0D
            ).inflate(0.004D);
            LevelRenderer.renderLineBox(poseStack, consumer, preview, 0.2F, 1.0F, 0.2F, 1.0F);
        } else if (posA != null) {
            LevelRenderer.renderLineBox(poseStack, consumer, new AABB(posA).inflate(0.004D), 0.2F, 1.0F, 0.2F, 1.0F);
        } else if (posB != null) {
            LevelRenderer.renderLineBox(poseStack, consumer, new AABB(posB).inflate(0.004D), 1.0F, 0.85F, 0.2F, 1.0F);
        }

        bufferSource.endBatch(RenderType.lines());
        poseStack.popPose();
    }
}
