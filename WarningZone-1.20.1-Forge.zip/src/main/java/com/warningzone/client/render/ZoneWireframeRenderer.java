package com.warningzone.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.warningzone.WarningZoneMod;
import com.warningzone.client.ClientZoneCache;
import com.warningzone.data.NameColor;
import com.warningzone.data.WarningZoneData;
import com.warningzone.item.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = WarningZoneMod.MOD_ID, value = Dist.CLIENT)
public final class ZoneWireframeRenderer {
    private ZoneWireframeRenderer() {
    }

    private static boolean isHoldingZoneTool(Player player) {
        return player.getMainHandItem().is(ModItems.WARNING_ZONE_WAND.get())
                || player.getOffhandItem().is(ModItems.WARNING_ZONE_WAND.get())
                || player.getMainHandItem().is(ModItems.ZONE_EDITOR_WAND.get())
                || player.getOffhandItem().is(ModItems.ZONE_EDITOR_WAND.get());
    }

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.level == null || !isHoldingZoneTool(player)) {
            return;
        }

        List<WarningZoneData> zones = ClientZoneCache.getZones();
        BlockPos posA = ClientZoneCache.getPendingPosA();
        BlockPos posB = ClientZoneCache.getPendingPosB();
        if (zones.isEmpty() && posA == null && posB == null) {
            return;
        }

        Vec3 camPos = event.getCamera().getPosition();
        Frustum frustum = event.getFrustum();
        double maxDist = mc.options.getEffectiveRenderDistance() * 16.0D + 32.0D;
        double maxDistSq = maxDist * maxDist;

        PoseStack poseStack = event.getPoseStack();
        poseStack.pushPose();
        poseStack.translate(-camPos.x, -camPos.y, -camPos.z);

        MultiBufferSource.BufferSource bufferSource = mc.renderBuffers().bufferSource();
        VertexConsumer consumer = bufferSource.getBuffer(RenderType.lines());

        // 1. 渲染当前维度内视距与视锥体可见的已保存区域边界线框（零 AABB 分配）
        for (int i = 0, size = zones.size(); i < size; i++) {
            WarningZoneData zone = zones.get(i);
            AABB renderBox = zone.toRenderAABB();
            if (renderBox.distanceToSqr(camPos) > maxDistSq || !frustum.isVisible(renderBox)) {
                continue;
            }
            NameColor color = zone.getWarnerColor();
            LevelRenderer.renderLineBox(
                    poseStack,
                    consumer,
                    renderBox,
                    color.getR(), color.getG(), color.getB(), 1.0F
            );
        }

        // 2. 渲染正在框选中的 A/B 临时选区预览（绿色/黄色）
        if (posA != null && posB != null) {
            AABB preview = new AABB(
                    Math.min(posA.getX(), posB.getX()),
                    Math.min(posA.getY(), posB.getY()),
                    Math.min(posA.getZ(), posB.getZ()),
                    Math.max(posA.getX(), posB.getX()) + 1.0D,
                    Math.max(posA.getY(), posB.getY()) + 1.0D,
                    Math.max(posA.getZ(), posB.getZ()) + 1.0D
            ).inflate(0.004D);
            LevelRenderer.renderLineBox(poseStack, consumer, preview, 0.2F, 1.0F, 0.2F, 1.0F);
        } else if (posA != null) {
            LevelRenderer.renderLineBox(poseStack, consumer, new AABB(posA).inflate(0.004D), 0.2F, 1.0F, 0.2F, 1.0F);
        } else if (posB != null) {
            LevelRenderer.renderLineBox(poseStack, consumer, new AABB(posB).inflate(0.004D), 1.0F, 0.85F, 0.2F, 1.0F);
        }

        bufferSource.endBatch(RenderType.lines());
        poseStack.popPose();
    }
}
