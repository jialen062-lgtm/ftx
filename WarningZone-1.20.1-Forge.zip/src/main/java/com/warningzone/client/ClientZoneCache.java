package com.warningzone.client;

import com.warningzone.data.WarningZoneData;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public final class ClientZoneCache {
    private static ResourceLocation currentDimension;
    private static volatile List<WarningZoneData> zonesSnapshot = Collections.emptyList();

    @Nullable
    private static BlockPos pendingPosA;
    @Nullable
    private static BlockPos pendingPosB;

    private ClientZoneCache() {
    }

    public static void setZones(ResourceLocation dimension, List<WarningZoneData> zones) {
        currentDimension = dimension;
        zonesSnapshot = (zones == null || zones.isEmpty())
                ? Collections.emptyList()
                : List.copyOf(zones);
    }

    public static List<WarningZoneData> getZones() {
        return zonesSnapshot;
    }

    @Nullable
    public static ResourceLocation getCurrentDimension() {
        return currentDimension;
    }

    public static void setPendingPosA(@Nullable BlockPos posA) {
        pendingPosA = posA;
    }

    public static void setPendingPosB(@Nullable BlockPos posB) {
        pendingPosB = posB;
    }

    @Nullable
    public static BlockPos getPendingPosA() {
        return pendingPosA;
    }

    @Nullable
    public static BlockPos getPendingPosB() {
        return pendingPosB;
    }

    public static void clearPendingSelection() {
        pendingPosA = null;
        pendingPosB = null;
    }

    @Nullable
    public static WarningZoneData findById(UUID id) {
        List<WarningZoneData> list = zonesSnapshot;
        for (int i = 0, size = list.size(); i < size; i++) {
            WarningZoneData zone = list.get(i);
            if (zone.getId().equals(id)) {
                return zone;
            }
        }
        return null;
    }

    @Nullable
    public static WarningZoneData findMatchingZone(BlockPos posA, BlockPos posB) {
        List<WarningZoneData> list = zonesSnapshot;
        for (int i = 0, size = list.size(); i < size; i++) {
            WarningZoneData zone = list.get(i);
            if (zone.matchesBounds(posA, posB)) {
                return zone;
            }
        }
        return null;
    }

    @Nullable
    public static WarningZoneData findZoneAt(BlockPos pos) {
        List<WarningZoneData> list = zonesSnapshot;
        for (int i = 0, size = list.size(); i < size; i++) {
            WarningZoneData zone = list.get(i);
            if (zone.containsBlock(pos)) {
                return zone;
            }
        }
        return null;
    }
}
