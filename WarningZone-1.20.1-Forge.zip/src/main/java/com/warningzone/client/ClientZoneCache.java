package com.warningzone.client;

import com.warningzone.data.WarningZoneData;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public final class ClientZoneCache {
    private static ResourceLocation currentDimension;
    private static final List<WarningZoneData> ZONES = new CopyOnWriteArrayList<>();

    @Nullable
    private static BlockPos pendingPosA;
    @Nullable
    private static BlockPos pendingPosB;

    private ClientZoneCache() {
    }

    public static void setZones(ResourceLocation dimension, List<WarningZoneData> zones) {
        currentDimension = dimension;
        ZONES.clear();
        ZONES.addAll(zones);
    }

    public static List<WarningZoneData> getZones() {
        return Collections.unmodifiableList(ZONES);
    }

    @Nullable
    public static ResourceLocation getCurrentDimension() {
        return currentDimension;
    }

    public static void setPendingPosA(@Nullable BlockPos posA) {
        pendingPosA = posA;
    }

    public static void setPendingPosB(@Nullable BlockPos posB) {
        pendingPosB = posB;
    }

    @Nullable
    public static BlockPos getPendingPosA() {
        return pendingPosA;
    }

    @Nullable
    public static BlockPos getPendingPosB() {
        return pendingPosB;
    }

    public static void clearPendingSelection() {
        pendingPosA = null;
        pendingPosB = null;
    }

    @Nullable
    public static WarningZoneData findMatchingZone(BlockPos posA, BlockPos posB) {
        for (WarningZoneData zone : ZONES) {
            if (zone.matchesBounds(posA, posB)) {
                return zone;
            }
        }
        return null;
    }

    @Nullable
    public static WarningZoneData findZoneAt(BlockPos pos) {
        for (WarningZoneData zone : ZONES) {
            if (pos.getX() >= zone.getMinX() && pos.getX() <= zone.getMaxX()
                    && pos.getY() >= zone.getMinY() && pos.getY() <= zone.getMaxY()
                    && pos.getZ() >= zone.getMinZ() && pos.getZ() <= zone.getMaxZ()) {
                return zone;
            }
        }
        return null;
    }
}
