package com.warningzone.client.screen;

import com.warningzone.client.ClientZoneCache;
import com.warningzone.data.NameColor;
import com.warningzone.data.TriggerLimitMode;
import com.warningzone.data.WarningZoneData;
import com.warningzone.network.C2SClearSelectionPacket;
import com.warningzone.network.C2SDeleteZonePacket;
import com.warningzone.network.C2SSaveZonePacket;
import com.warningzone.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import javax.annotation.Nullable;
import java.util.UUID;

public class WarningZoneScreen extends Screen {
    private static final int PANEL_WIDTH = 300;
    private static final int PANEL_HEIGHT = 285;

    private final BlockPos posA;
    private final BlockPos posB;
    @Nullable
    private final UUID editingZoneId;

    private EditBox warnerNameBox;
    private EditBox warningContentBox;
    private EditBox secondWarnerNameBox;
    private EditBox secondWarningContentBox;

    private Button colorButton;
    private Button limitButton;
    private Button secondWarningToggleButton;
    private Button saveButton;
    private Button deleteButton;
    private Button cancelButton;

    private NameColor selectedColor;
    private TriggerLimitMode selectedLimit;
    private boolean secondWarningEnabled;
    private final String initialName;
    private final String initialContent;
    private final String initialSecondName;
    private final String initialSecondContent;

    public WarningZoneScreen(BlockPos posA, BlockPos posB, @Nullable WarningZoneData existingZone) {
        super(Component.translatable("screen.warningzone.title"));
        this.posA = posA;
        this.posB = posB;
        if (existingZone != null) {
            this.editingZoneId = existingZone.getId();
            this.initialName = existingZone.getWarnerName();
            this.initialContent = existingZone.getWarningContent();
            this.selectedColor = existingZone.getWarnerColor();
            this.selectedLimit = existingZone.getTriggerLimit();
            this.secondWarningEnabled = existingZone.isSecondWarningEnabled();
            this.initialSecondName = existingZone.getSecondWarnerName();
            this.initialSecondContent = existingZone.getSecondWarningContent();
        } else {
            this.editingZoneId = null;
            this.initialName = "指挥部";
            this.initialContent = "前方为警戒区域，请立即撤离！";
            this.selectedColor = NameColor.BLUE;
            this.selectedLimit = TriggerLimitMode.SINGLE_PLAYER;
            this.secondWarningEnabled = false;
            this.initialSecondName = "指挥部";
            this.initialSecondContent = "继续前进！";
        }
    }

    @Override
    protected void init() {
        super.init();
        int left = (this.width - PANEL_WIDTH) / 2;
        int top = (this.height - PANEL_HEIGHT) / 2;
        int fieldWidth = PANEL_WIDTH - 28;
        int fieldX = left + 14;

        // 1. 警告人名字输入框
        this.warnerNameBox = new EditBox(
                this.font, fieldX, top + 34, fieldWidth, 18,
                Component.translatable("screen.warningzone.warner_name")
        );
        this.warnerNameBox.setMaxLength(32);
        this.warnerNameBox.setValue(this.initialName);
        this.addRenderableWidget(this.warnerNameBox);

        // 2. 警告内容输入框
        this.warningContentBox = new EditBox(
                this.font, fieldX, top + 67, fieldWidth, 18,
                Component.translatable("screen.warningzone.warning_content")
        );
        this.warningContentBox.setMaxLength(160);
        this.warningContentBox.setValue(this.initialContent);
        this.addRenderableWidget(this.warningContentBox);

        // 3. 颜色切换 & 触发限制切换按钮（并排）
        int halfWidth = (fieldWidth - 8) / 2;
        this.colorButton = Button.builder(buildColorButtonText(), btn -> {
            this.selectedColor = this.selectedColor.next();
            btn.setMessage(buildColorButtonText());
        }).bounds(fieldX, top + 92, halfWidth, 20).build();
        this.addRenderableWidget(this.colorButton);

        this.limitButton = Button.builder(buildLimitButtonText(), btn -> {
            this.selectedLimit = this.selectedLimit.next();
            btn.setMessage(buildLimitButtonText());
        }).bounds(fieldX + halfWidth + 8, top + 92, halfWidth, 20).build();
        this.addRenderableWidget(this.limitButton);

        // 4. 隔2秒后再次警告开关按钮
        this.secondWarningToggleButton = Button.builder(buildSecondToggleText(), btn -> {
            this.secondWarningEnabled = !this.secondWarningEnabled;
            btn.setMessage(buildSecondToggleText());
            updateSecondFieldsEditable();
        }).bounds(fieldX, top + 118, fieldWidth, 20).build();
        this.addRenderableWidget(this.secondWarningToggleButton);

        // 5. 2秒后警告人名称输入框
        this.secondWarnerNameBox = new EditBox(
                this.font, fieldX, top + 153, fieldWidth, 18,
                Component.translatable("screen.warningzone.second_warner_name")
        );
        this.secondWarnerNameBox.setMaxLength(32);
        this.secondWarnerNameBox.setValue(this.initialSecondName);
        this.addRenderableWidget(this.secondWarnerNameBox);

        // 6. 2秒后警告内容输入框
        this.secondWarningContentBox = new EditBox(
                this.font, fieldX, top + 186, fieldWidth, 18,
                Component.translatable("screen.warningzone.second_warning_content")
        );
        this.secondWarningContentBox.setMaxLength(160);
        this.secondWarningContentBox.setValue(this.initialSecondContent);
        this.addRenderableWidget(this.secondWarningContentBox);

        updateSecondFieldsEditable();

        // 7. 功能按钮行：保存区域 / 删除区域 / 取消
        int btnY = top + 252;
        int btnWidth = 84;
        int gap = (fieldWidth - btnWidth * 3) / 2;

        this.saveButton = Button.builder(Component.translatable("screen.warningzone.save"), btn -> onSave())
                .bounds(fieldX, btnY, btnWidth, 20)
                .build();
        this.addRenderableWidget(this.saveButton);

        this.deleteButton = Button.builder(Component.translatable("screen.warningzone.delete"), btn -> onDelete())
                .bounds(fieldX + btnWidth + gap, btnY, btnWidth, 20)
                .build();
        this.deleteButton.active = (this.editingZoneId != null);
        this.addRenderableWidget(this.deleteButton);

        this.cancelButton = Button.builder(Component.translatable("screen.warningzone.cancel"), btn -> onCancel())
                .bounds(fieldX + (btnWidth + gap) * 2, btnY, btnWidth, 20)
                .build();
        this.addRenderableWidget(this.cancelButton);

        this.setInitialFocus(this.warnerNameBox);
    }

    private void updateSecondFieldsEditable() {
        if (this.secondWarnerNameBox != null) {
            this.secondWarnerNameBox.setEditable(this.secondWarningEnabled);
        }
        if (this.secondWarningContentBox != null) {
            this.secondWarningContentBox.setEditable(this.secondWarningEnabled);
        }
    }

    private Component buildColorButtonText() {
        return Component.translatable("screen.warningzone.color_label")
                .append(": ")
                .append(this.selectedColor.getDisplayName());
    }

    private Component buildLimitButtonText() {
        return Component.translatable("screen.warningzone.limit_label")
                .append(": ")
                .append(this.selectedLimit.getDisplayName());
    }

    private Component buildSecondToggleText() {
        Component state = Component.translatable(
                this.secondWarningEnabled ? "screen.warningzone.toggle.on" : "screen.warningzone.toggle.off"
        ).withStyle(this.secondWarningEnabled ? ChatFormatting.GREEN : ChatFormatting.GRAY);
        return Component.translatable("screen.warningzone.second_warning_toggle")
                .append(": ")
                .append(state);
    }

    private void onSave() {
        String name = this.warnerNameBox.getValue().trim();
        String content = this.warningContentBox.getValue().trim();
        if (name.isEmpty()) {
            name = "系统警告";
        }
        String secondName = this.secondWarnerNameBox.getValue().trim();
        String secondContent = this.secondWarningContentBox.getValue().trim();

        ModNetwork.CHANNEL.sendToServer(new C2SSaveZonePacket(
                this.editingZoneId,
                this.posA,
                this.posB,
                name,
                this.selectedColor,
                content,
                this.selectedLimit,
                this.secondWarningEnabled,
                secondName,
                secondContent
        ));
        ClientZoneCache.clearPendingSelection();
        this.onClose();
    }

    private void onDelete() {
        if (this.editingZoneId != null) {
            ModNetwork.CHANNEL.sendToServer(new C2SDeleteZonePacket(this.editingZoneId));
        }
        ClientZoneCache.clearPendingSelection();
        this.onClose();
    }

    private void onCancel() {
        ModNetwork.CHANNEL.sendToServer(new C2SClearSelectionPacket());
        ClientZoneCache.clearPendingSelection();
        this.onClose();
    }

    @Override
    public void tick() {
        super.tick();
        if (this.warnerNameBox != null) {
            this.warnerNameBox.tick();
        }
        if (this.warningContentBox != null) {
            this.warningContentBox.tick();
        }
        if (this.secondWarnerNameBox != null) {
            this.secondWarnerNameBox.tick();
        }
        if (this.secondWarningContentBox != null) {
            this.secondWarningContentBox.tick();
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(guiGraphics);

        int left = (this.width - PANEL_WIDTH) / 2;
        int top = (this.height - PANEL_HEIGHT) / 2;

        guiGraphics.fill(left, top, left + PANEL_WIDTH, top + PANEL_HEIGHT, 0xCC181A20);
        guiGraphics.renderOutline(left, top, PANEL_WIDTH, PANEL_HEIGHT, 0xFF4A5568);
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, top + 8, 0xFFFFFF);

        int fieldX = left + 14;
        guiGraphics.drawString(this.font, Component.translatable("screen.warningzone.warner_name"), fieldX, top + 23, 0xCCCCCC);
        guiGraphics.drawString(this.font, Component.translatable("screen.warningzone.warning_content"), fieldX, top + 56, 0xCCCCCC);
        guiGraphics.drawString(this.font, Component.translatable("screen.warningzone.second_warner_name"), fieldX, top + 142, 0xCCCCCC);
        guiGraphics.drawString(this.font, Component.translatable("screen.warningzone.second_warning_content"), fieldX, top + 175, 0xCCCCCC);

        // 实时预览（无 [] 括号，格式为：警告人名称: 警告内容）
        MutableComponent preview1 = Component.literal(this.warnerNameBox.getValue())
                .withStyle(this.selectedColor.getFormatting())
                .append(Component.literal(": " + this.warningContentBox.getValue()).withStyle(ChatFormatting.WHITE));
        guiGraphics.drawString(this.font, preview1, fieldX, top + 214, 0xFFFFFF);

        if (this.secondWarningEnabled) {
            String sName = this.secondWarnerNameBox.getValue().trim();
            if (sName.isEmpty()) {
                sName = this.warnerNameBox.getValue();
            }
            MutableComponent preview2 = Component.literal("2秒后 ")
                    .withStyle(ChatFormatting.GRAY)
                    .append(Component.literal(sName).withStyle(this.selectedColor.getFormatting()))
                    .append(Component.literal(": " + this.secondWarningContentBox.getValue()).withStyle(ChatFormatting.WHITE));
            guiGraphics.drawString(this.font, preview2, fieldX, top + 229, 0xFFFFFF);
        }

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
