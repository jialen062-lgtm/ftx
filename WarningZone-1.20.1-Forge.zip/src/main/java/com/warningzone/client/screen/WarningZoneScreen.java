package com.warningzone.client.screen;

import com.warningzone.client.ClientZoneCache;
import com.warningzone.data.NameColor;
import com.warningzone.data.TriggerLimitMode;
import com.warningzone.data.WarningZoneData;
import com.warningzone.network.C2SClearSelectionPacket;
import com.warningzone.network.C2SDeleteZonePacket;
import com.warningzone.network.C2SSaveZonePacket;
import com.warningzone.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import javax.annotation.Nullable;
import java.util.UUID;

public class WarningZoneScreen extends Screen {
    private static final int PANEL_WIDTH = 280;
    private static final int PANEL_HEIGHT = 215;

    private final BlockPos posA;
    private final BlockPos posB;
    @Nullable
    private final UUID editingZoneId;

    private EditBox warnerNameBox;
    private EditBox warningContentBox;
    private Button colorButton;
    private Button limitButton;
    private Button saveButton;
    private Button deleteButton;
    private Button cancelButton;

    private NameColor selectedColor;
    private TriggerLimitMode selectedLimit;
    private String initialName;
    private String initialContent;

    public WarningZoneScreen(BlockPos posA, BlockPos posB, @Nullable WarningZoneData existingZone) {
        super(Component.translatable("screen.warningzone.title"));
        this.posA = posA;
        this.posB = posB;
        if (existingZone != null) {
            this.editingZoneId = existingZone.getId();
            this.initialName = existingZone.getWarnerName();
            this.initialContent = existingZone.getWarningContent();
            this.selectedColor = existingZone.getWarnerColor();
            this.selectedLimit = existingZone.getTriggerLimit();
        } else {
            this.editingZoneId = null;
            this.initialName = "指挥部";
            this.initialContent = "前方为警戒区域，请立即撤离！";
            this.selectedColor = NameColor.BLUE;
            this.selectedLimit = TriggerLimitMode.SINGLE_PLAYER;
        }
    }

    @Override
    protected void init() {
        super.init();
        int left = (this.width - PANEL_WIDTH) / 2;
        int top = (this.height - PANEL_HEIGHT) / 2;
        int fieldWidth = PANEL_WIDTH - 24;
        int fieldX = left + 12;

        // 1. 警告人名字输入框
        this.warnerNameBox = new EditBox(
                this.font, fieldX, top + 36, fieldWidth, 20,
                Component.translatable("screen.warningzone.warner_name")
        );
        this.warnerNameBox.setMaxLength(32);
        this.warnerNameBox.setValue(this.initialName);
        this.addRenderableWidget(this.warnerNameBox);

        // 2. 警告内容输入框
        this.warningContentBox = new EditBox(
                this.font, fieldX, top + 76, fieldWidth, 20,
                Component.translatable("screen.warningzone.warning_content")
        );
        this.warningContentBox.setMaxLength(160);
        this.warningContentBox.setValue(this.initialContent);
        this.addRenderableWidget(this.warningContentBox);

        // 3. 警告人名字颜色切换按钮（蓝色 / 红色）
        this.colorButton = Button.builder(buildColorButtonText(), btn -> {
            this.selectedColor = this.selectedColor.next();
            btn.setMessage(buildColorButtonText());
        }).bounds(fieldX, top + 108, fieldWidth, 20).build();
        this.addRenderableWidget(this.colorButton);

        // 4. 触发限制模式切换按钮（单人限制 / 全服限制 / 无限制）
        this.limitButton = Button.builder(buildLimitButtonText(), btn -> {
            this.selectedLimit = this.selectedLimit.next();
            btn.setMessage(buildLimitButtonText());
        }).bounds(fieldX, top + 134, fieldWidth, 20).build();
        this.addRenderableWidget(this.limitButton);

        // 5. 功能按钮行：保存区域 / 删除区域 / 取消
        int btnY = top + 182;
        int btnWidth = 80;
        int gap = (fieldWidth - btnWidth * 3) / 2;

        this.saveButton = Button.builder(Component.translatable("screen.warningzone.save"), btn -> onSave())
                .bounds(fieldX, btnY, btnWidth, 20)
                .build();
        this.addRenderableWidget(this.saveButton);

        this.deleteButton = Button.builder(Component.translatable("screen.warningzone.delete"), btn -> onDelete())
                .bounds(fieldX + btnWidth + gap, btnY, btnWidth, 20)
                .build();
        this.deleteButton.active = (this.editingZoneId != null);
        this.addRenderableWidget(this.deleteButton);

        this.cancelButton = Button.builder(Component.translatable("screen.warningzone.cancel"), btn -> onCancel())
                .bounds(fieldX + (btnWidth + gap) * 2, btnY, btnWidth, 20)
                .build();
        this.addRenderableWidget(this.cancelButton);

        this.setInitialFocus(this.warnerNameBox);
    }

    private Component buildColorButtonText() {
        return Component.translatable("screen.warningzone.color_label")
                .append(": ")
                .append(this.selectedColor.getDisplayName());
    }

    private Component buildLimitButtonText() {
        return Component.translatable("screen.warningzone.limit_label")
                .append(": ")
                .append(this.selectedLimit.getDisplayName());
    }

    private void onSave() {
        String name = this.warnerNameBox.getValue().trim();
        String content = this.warningContentBox.getValue().trim();
        if (name.isEmpty()) {
            name = "系统警告";
        }
        ModNetwork.CHANNEL.sendToServer(new C2SSaveZonePacket(
                this.editingZoneId,
                this.posA,
                this.posB,
                name,
                this.selectedColor,
                content,
                this.selectedLimit
        ));
        ClientZoneCache.clearPendingSelection();
        this.onClose();
    }

    private void onDelete() {
        if (this.editingZoneId != null) {
            ModNetwork.CHANNEL.sendToServer(new C2SDeleteZonePacket(this.editingZoneId));
        }
        ClientZoneCache.clearPendingSelection();
        this.onClose();
    }

    private void onCancel() {
        ModNetwork.CHANNEL.sendToServer(new C2SClearSelectionPacket());
        ClientZoneCache.clearPendingSelection();
        this.onClose();
    }

    @Override
    public void tick() {
        super.tick();
        if (this.warnerNameBox != null) {
            this.warnerNameBox.tick();
        }
        if (this.warningContentBox != null) {
            this.warningContentBox.tick();
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(guiGraphics);

        int left = (this.width - PANEL_WIDTH) / 2;
        int top = (this.height - PANEL_HEIGHT) / 2;

        // 半透明深色面板背景与边框
        guiGraphics.fill(left, top, left + PANEL_WIDTH, top + PANEL_HEIGHT, 0xCC181A20);
        guiGraphics.renderOutline(left, top, PANEL_WIDTH, PANEL_HEIGHT, 0xFF4A5568);

        // 标题与坐标范围提示
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, top + 10, 0xFFFFFF);

        int fieldX = left + 12;
        guiGraphics.drawString(this.font, Component.translatable("screen.warningzone.warner_name"), fieldX, top + 25, 0xCCCCCC);
        guiGraphics.drawString(this.font, Component.translatable("screen.warningzone.warning_content"), fieldX, top + 65, 0xCCCCCC);

        // 实时效果预览：[蓝色/红色名字] 白色警告内容
        MutableComponent preview = Component.literal("[")
                .append(Component.literal(this.warnerNameBox.getValue()).withStyle(this.selectedColor.getFormatting()))
                .append(Component.literal("] "))
                .withStyle(this.selectedColor.getFormatting())
                .append(Component.literal(this.warningContentBox.getValue()).withStyle(ChatFormatting.WHITE));
        guiGraphics.drawString(this.font, preview, fieldX, top + 163, 0xFFFFFF);

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
