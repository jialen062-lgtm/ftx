package com.warningzone.client;

import com.warningzone.WarningZoneMod;
import com.warningzone.client.screen.WarningZoneScreen;
import com.warningzone.data.WarningZoneData;
import com.warningzone.item.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = WarningZoneMod.MOD_ID, value = Dist.CLIENT)
public final class ClientInteractEvents {
    private ClientInteractEvents() {
    }

    @SubscribeEvent
    public static void onClientLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (!event.getLevel().isClientSide()) {
            return;
        }
        ItemStack stack = event.getItemStack();
        if (!stack.is(ModItems.WARNING_ZONE_WAND.get())) {
            return;
        }
        ClientZoneCache.setPendingPosA(event.getPos().immutable());
        tryOpenScreen();
    }

    @SubscribeEvent
    public static void onClientRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!event.getLevel().isClientSide() || event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        ItemStack stack = event.getItemStack();
        if (!stack.is(ModItems.WARNING_ZONE_WAND.get())) {
            return;
        }

        // Shift + 右键已存在的区域，直接打开该区域的编辑/删除界面
        if (event.getEntity().isShiftKeyDown()) {
            WarningZoneData hitZone = ClientZoneCache.findZoneAt(event.getPos());
            if (hitZone != null) {
                BlockPos a = new BlockPos(hitZone.getMinX(), hitZone.getMinY(), hitZone.getMinZ());
                BlockPos b = new BlockPos(hitZone.getMaxX(), hitZone.getMaxY(), hitZone.getMaxZ());
                Minecraft.getInstance().setScreen(new WarningZoneScreen(a, b, hitZone));
                return;
            }
        }

        ClientZoneCache.setPendingPosB(event.getPos().immutable());
        tryOpenScreen();
    }

    private static void tryOpenScreen() {
        BlockPos posA = ClientZoneCache.getPendingPosA();
        BlockPos posB = ClientZoneCache.getPendingPosB();
        if (posA != null && posB != null) {
            WarningZoneData existing = ClientZoneCache.findMatchingZone(posA, posB);
            Minecraft.getInstance().setScreen(new WarningZoneScreen(posA, posB, existing));
        }
    }
}
