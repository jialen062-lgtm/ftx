package com.warningzone.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.warningzone.WarningZoneMod;
import com.warningzone.compat.CnpcIntegration;
import com.warningzone.network.ModNetwork;
import com.warningzone.network.S2CSyncZonesPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class WarningZoneManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type ZONE_LIST_TYPE = new TypeToken<List<WarningZoneData>>() {}.getType();
    private static final int SECOND_WARNING_DELAY_TICKS = 40; // 2 秒 = 40 ticks

    private static final Map<ResourceLocation, Map<UUID, WarningZoneData>> ZONES_BY_DIM = new ConcurrentHashMap<>();
    // 按维度缓存不可变列表快照，供高频 PlayerTickEvent 零分配遍历
    private static final Map<ResourceLocation, List<WarningZoneData>> ZONE_SNAPSHOTS = new ConcurrentHashMap<>();
    private static volatile long nextScheduledTick = Long.MAX_VALUE;
    private static final Map<UUID, Set<UUID>> SINGLE_PLAYER_TRIGGERED = new ConcurrentHashMap<>();
    private static final Set<UUID> SERVER_WIDE_LOCKED = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Set<UUID>> SERVER_WIDE_DIED = new ConcurrentHashMap<>();
    private static final Map<UUID, Set<UUID>> UNLIMITED_INSIDE = new ConcurrentHashMap<>();
    private static final ConcurrentLinkedQueue<ScheduledWarning> SCHEDULED_WARNINGS = new ConcurrentLinkedQueue<>();

    private static class ScheduledWarning {
        final long executeAtTick;
        @Nullable
        final UUID targetPlayerId; // null 表示全服在线玩家
        final Component message;

        ScheduledWarning(long executeAtTick, @Nullable UUID targetPlayerId, Component message) {
            this.executeAtTick = executeAtTick;
            this.targetPlayerId = targetPlayerId;
            this.message = message;
        }
    }

    private WarningZoneManager() {
    }

    public static void clearAll() {
        ZONES_BY_DIM.clear();
        ZONE_SNAPSHOTS.clear();
        nextScheduledTick = Long.MAX_VALUE;
        SINGLE_PLAYER_TRIGGERED.clear();
        SERVER_WIDE_LOCKED.clear();
        SERVER_WIDE_DIED.clear();
        UNLIMITED_INSIDE.clear();
        SCHEDULED_WARNINGS.clear();
    }

    public static Path getStorageDir(MinecraftServer server) {
        return server.getWorldPath(LevelResource.ROOT).resolve("warningzone").resolve("zones");
    }

    private static String toSafeFileName(ResourceLocation dimension) {
        return dimension.getNamespace() + "_" + dimension.getPath().replace('/', '_') + ".json";
    }

    public static void loadAll(MinecraftServer server) {
        clearAll();
        Path dir = getStorageDir(server);
        if (!Files.exists(dir)) {
            return;
        }
        for (ServerLevel level : server.getAllLevels()) {
            ResourceLocation dimId = level.dimension().location();
            Path file = dir.resolve(toSafeFileName(dimId));
            if (!Files.exists(file)) {
                continue;
            }
            try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                List<WarningZoneData> list = GSON.fromJson(reader, ZONE_LIST_TYPE);
                if (list != null) {
                    Map<UUID, WarningZoneData> map = new ConcurrentHashMap<>();
                    for (WarningZoneData zone : list) {
                        if (zone != null && zone.getId() != null) {
                            map.put(zone.getId(), zone);
                        }
                    }
                    ZONES_BY_DIM.put(dimId, map);
                    rebuildSnapshot(dimId);
                }
            } catch (Exception e) {
                WarningZoneMod.LOGGER.error("Failed to load warning zones for dimension {}", dimId, e);
            }
        }
    }

    public static void saveDimension(MinecraftServer server, ResourceLocation dimId) {
        Path dir = getStorageDir(server);
        try {
            Files.createDirectories(dir);
            Path file = dir.resolve(toSafeFileName(dimId));
            Collection<WarningZoneData> zones = getZones(dimId);
            try (Writer writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                GSON.toJson(new ArrayList<>(zones), ZONE_LIST_TYPE, writer);
            }
        } catch (IOException e) {
            WarningZoneMod.LOGGER.error("Failed to save warning zones for dimension {}", dimId, e);
        }
    }

    public static void saveAll(MinecraftServer server) {
        for (ResourceLocation dimId : ZONES_BY_DIM.keySet()) {
            saveDimension(server, dimId);
        }
    }

    private static void rebuildSnapshot(ResourceLocation dimId) {
        Map<UUID, WarningZoneData> map = ZONES_BY_DIM.get(dimId);
        if (map == null || map.isEmpty()) {
            ZONE_SNAPSHOTS.remove(dimId);
        } else {
            ZONE_SNAPSHOTS.put(dimId, List.copyOf(map.values()));
        }
    }

    public static List<WarningZoneData> getZones(ResourceLocation dimId) {
        return ZONE_SNAPSHOTS.getOrDefault(dimId, Collections.emptyList());
    }

    @Nullable
    public static WarningZoneData getZoneById(ResourceLocation dimId, UUID zoneId) {
        Map<UUID, WarningZoneData> map = ZONES_BY_DIM.get(dimId);
        return map == null ? null : map.get(zoneId);
    }

    @Nullable
    public static WarningZoneData findZoneForEditor(ResourceLocation dimId, BlockPos clickedOrPlayerPos, BlockPos playerPos) {
        Collection<WarningZoneData> zones = getZones(dimId);
        for (WarningZoneData zone : zones) {
            if (zone.containsBlock(clickedOrPlayerPos)) {
                return zone;
            }
        }
        for (WarningZoneData zone : zones) {
            if (zone.containsBlock(playerPos)) {
                return zone;
            }
        }
        WarningZoneData nearest = null;
        double bestDistSq = 16.0D * 16.0D;
        Vec3 p = Vec3.atCenterOf(clickedOrPlayerPos);
        for (WarningZoneData zone : zones) {
            double distSq = zone.toAABB().distanceToSqr(p);
            if (distSq <= bestDistSq) {
                bestDistSq = distSq;
                nearest = zone;
            }
        }
        return nearest;
    }

    public static void saveOrUpdateZone(ServerLevel level, WarningZoneData zone) {
        ResourceLocation dimId = level.dimension().location();
        ZONES_BY_DIM.computeIfAbsent(dimId, k -> new ConcurrentHashMap<>()).put(zone.getId(), zone);
        rebuildSnapshot(dimId);
        resetZoneState(zone.getId());
        saveDimension(level.getServer(), dimId);
        syncDimensionToClients(level);
    }

    public static boolean deleteZone(ServerLevel level, UUID zoneId) {
        ResourceLocation dimId = level.dimension().location();
        Map<UUID, WarningZoneData> map = ZONES_BY_DIM.get(dimId);
        if (map == null || map.remove(zoneId) == null) {
            return false;
        }
        rebuildSnapshot(dimId);
        resetZoneState(zoneId);
        saveDimension(level.getServer(), dimId);
        syncDimensionToClients(level);
        return true;
    }

    /**
     * 指令 /sc jg：删除所有维度的全部警告区域并同步至所有在线玩家。
     */
    public static int deleteAllZones(MinecraftServer server) {
        int removedCount = 0;
        for (Map<UUID, WarningZoneData> map : ZONES_BY_DIM.values()) {
            removedCount += map.size();
            map.clear();
        }
        ZONE_SNAPSHOTS.clear();
        nextScheduledTick = Long.MAX_VALUE;
        SINGLE_PLAYER_TRIGGERED.clear();
        SERVER_WIDE_LOCKED.clear();
        SERVER_WIDE_DIED.clear();
        UNLIMITED_INSIDE.clear();
        SCHEDULED_WARNINGS.clear();

        for (ServerLevel level : server.getAllLevels()) {
            saveDimension(server, level.dimension().location());
            syncDimensionToClients(level);
        }
        return removedCount;
    }

    public static void resetZoneState(UUID zoneId) {
        SINGLE_PLAYER_TRIGGERED.remove(zoneId);
        SERVER_WIDE_LOCKED.remove(zoneId);
        SERVER_WIDE_DIED.remove(zoneId);
        UNLIMITED_INSIDE.remove(zoneId);
    }

    public static void syncDimensionToClients(ServerLevel level) {
        ResourceLocation dimId = level.dimension().location();
        List<WarningZoneData> list = new ArrayList<>(getZones(dimId));
        ModNetwork.CHANNEL.send(
                PacketDistributor.DIMENSION.with(level::dimension),
                new S2CSyncZonesPacket(dimId, list)
        );
    }

    public static void syncDimensionToPlayer(ServerPlayer player) {
        ResourceLocation dimId = player.level().dimension().location();
        List<WarningZoneData> list = new ArrayList<>(getZones(dimId));
        ModNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new S2CSyncZonesPacket(dimId, list)
        );
    }

    public static void tickPlayer(ServerPlayer player) {
        // 降频至每 2 tick 检测一次 (10Hz) 且跳过旁观者，降低服务端 50% 检测开销
        if ((player.tickCount & 1) != 0 || player.isSpectator()) {
            return;
        }
        ResourceLocation dimId = player.level().dimension().location();
        List<WarningZoneData> zones = getZones(dimId);
        if (zones.isEmpty()) {
            return;
        }

        double px = player.getX();
        double py = player.getY();
        double pz = player.getZ();
        AABB playerBox = player.getBoundingBox();
        UUID playerId = player.getUUID();
        MinecraftServer server = player.getServer();
        long currentTick = server != null ? server.getTickCount() : 0L;

        for (int i = 0, size = zones.size(); i < size; i++) {
            WarningZoneData zone = zones.get(i);
            boolean near = zone.isNearPoint(px, py, pz, 1.0D);
            boolean inside = near && zone.toAABB().intersects(playerBox);

            switch (zone.getTriggerLimit()) {
                case SINGLE_PLAYER -> {
                    if (inside) {
                        Set<UUID> triggered = SINGLE_PLAYER_TRIGGERED
                                .computeIfAbsent(zone.getId(), k -> ConcurrentHashMap.newKeySet());
                        if (triggered.add(playerId)) {
                            sendWarning(player, zone);
                            scheduleFollowUpIfEnabled(zone, playerId, currentTick);
                        }
                    }
                }
                case SERVER_WIDE -> {
                    if (inside && !SERVER_WIDE_LOCKED.contains(zone.getId())) {
                        SERVER_WIDE_LOCKED.add(zone.getId());
                        SERVER_WIDE_DIED.computeIfAbsent(zone.getId(), k -> ConcurrentHashMap.newKeySet()).clear();
                        if (server != null) {
                            for (ServerPlayer online : server.getPlayerList().getPlayers()) {
                                sendWarning(online, zone);
                            }
                            scheduleFollowUpIfEnabled(zone, null, currentTick);
                        }
                    }
                }
                case UNLIMITED -> {
                    Set<UUID> insideSet = UNLIMITED_INSIDE
                            .computeIfAbsent(zone.getId(), k -> ConcurrentHashMap.newKeySet());
                    if (inside) {
                        if (insideSet.add(playerId)) {
                            sendWarning(player, zone);
                            scheduleFollowUpIfEnabled(zone, playerId, currentTick);
                        }
                    } else {
                        insideSet.remove(playerId);
                    }
                }
            } else if (sw.executeAtTick < newMinTick) {
                newMinTick = sw.executeAtTick;
            }
        }
        nextScheduledTick = newMinTick;
    }

    private static void scheduleFollowUpIfEnabled(WarningZoneData zone, @Nullable UUID targetPlayerId, long currentTick) {
        if (!zone.isSecondWarningEnabled()) {
            return;
        }
        String secondContent = zone.getSecondWarningContent();
        if (secondContent.isEmpty()) {
            return;
        }
        String secondName = zone.getSecondWarnerName().isEmpty() ? zone.getWarnerName() : zone.getSecondWarnerName();
        Component msg = buildWarningComponent(secondName, zone.getWarnerColor(), secondContent);
        long executeAt = currentTick + SECOND_WARNING_DELAY_TICKS;
        if (executeAt < nextScheduledTick) {
            nextScheduledTick = executeAt;
        }
        SCHEDULED_WARNINGS.add(new ScheduledWarning(executeAt, targetPlayerId, msg));
    }

    public static void tickScheduledWarnings(MinecraftServer server) {
        if (SCHEDULED_WARNINGS.isEmpty()) {
            nextScheduledTick = Long.MAX_VALUE;
            return;
        }
        long currentTick = server.getTickCount();
        if (currentTick < nextScheduledTick) {
            return;
        }
        long newMinTick = Long.MAX_VALUE;
        Iterator<ScheduledWarning> it = SCHEDULED_WARNINGS.iterator();
        while (it.hasNext()) {
            ScheduledWarning sw = it.next();
            if (currentTick >= sw.executeAtTick) {
                it.remove();
                if (sw.targetPlayerId == null) {
                    for (ServerPlayer online : server.getPlayerList().getPlayers()) {
                        online.sendSystemMessage(sw.message);
                        CnpcIntegration.notifyPlayer(online, sw.message.getString());
                    }
                } else {
                    ServerPlayer target = server.getPlayerList().getPlayer(sw.targetPlayerId);
                    if (target != null) {
                        target.sendSystemMessage(sw.message);
                        CnpcIntegration.notifyPlayer(target, sw.message.getString());
                    }
                }
            } else if (sw.executeAtTick < newMinTick) {
                newMinTick = sw.executeAtTick;
            }
        }
        nextScheduledTick = newMinTick;
    }

    public static void onPlayerDeath(ServerPlayer deadPlayer) {
        UUID deadId = deadPlayer.getUUID();

        for (Set<UUID> triggered : SINGLE_PLAYER_TRIGGERED.values()) {
            triggered.remove(deadId);
        }

        for (Set<UUID> inside : UNLIMITED_INSIDE.values()) {
            inside.remove(deadId);
        }

        if (SERVER_WIDE_LOCKED.isEmpty()) {
            return;
        }
        MinecraftServer server = deadPlayer.getServer();
        if (server == null) {
            return;
        }
        List<ServerPlayer> onlinePlayers = server.getPlayerList().getPlayers();
        for (UUID zoneId : new ArrayList<>(SERVER_WIDE_LOCKED)) {
            Set<UUID> diedSet = SERVER_WIDE_DIED
                    .computeIfAbsent(zoneId, k -> ConcurrentHashMap.newKeySet());
            diedSet.add(deadId);

            boolean allOnlineDied = !onlinePlayers.isEmpty()
                    && onlinePlayers.stream().allMatch(p -> diedSet.contains(p.getUUID()));
            if (allOnlineDied) {
                SERVER_WIDE_LOCKED.remove(zoneId);
                diedSet.clear();
            }
        }
    }

    public static void onPlayerLogout(ServerPlayer player) {
        UUID playerId = player.getUUID();
        for (Set<UUID> inside : UNLIMITED_INSIDE.values()) {
            inside.remove(playerId);
        }
    }

    public static Component buildWarningComponent(String warnerName, NameColor color, String content) {
        MutableComponent namePart = Component.literal(warnerName).withStyle(color.getFormatting());
        MutableComponent contentPart = Component.literal(": " + content).withStyle(ChatFormatting.WHITE);
        return namePart.append(contentPart);
    }

    private static void sendWarning(ServerPlayer target, WarningZoneData zone) {
        Component message = buildWarningComponent(zone.getWarnerName(), zone.getWarnerColor(), zone.getWarningContent());
        // 仅向聊天框发送警告消息（已移除屏幕中心 Actionbar 提示与 [] 括号）
        target.sendSystemMessage(message);
        CnpcIntegration.notifyPlayer(target, message.getString());
    }
}
