package com.warningzone.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.warningzone.WarningZoneMod;
import com.warningzone.compat.CnpcIntegration;
import com.warningzone.network.ModNetwork;
import com.warningzone.network.S2CSyncZonesPacket;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.PacketDistributor;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class WarningZoneManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type ZONE_LIST_TYPE = new TypeToken<List<WarningZoneData>>() {}.getType();

    // 按维度存储区域: dimensionId -> (zoneId -> WarningZoneData)
    private static final Map<ResourceLocation, Map<UUID, WarningZoneData>> ZONES_BY_DIM = new ConcurrentHashMap<>();

    // 单人限制状态: zoneId -> 已触发过该区域的玩家 UUID 集合
    private static final Map<UUID, Set<UUID>> SINGLE_PLAYER_TRIGGERED = new ConcurrentHashMap<>();

    // 全服限制状态: 当前处于锁定（已触发、等待全服在线玩家死亡重置）的区域 ID 集合
    private static final Set<UUID> SERVER_WIDE_LOCKED = ConcurrentHashMap.newKeySet();

    // 全服限制死亡记录: zoneId -> 自触发以来已死亡过的玩家 UUID 集合
    private static final Map<UUID, Set<UUID>> SERVER_WIDE_DIED = new ConcurrentHashMap<>();

    // 无限制模式防刷屏状态: zoneId -> 当前正处于区域内的玩家 UUID 集合（离开后移出，再次进入可再次触发）
    private static final Map<UUID, Set<UUID>> UNLIMITED_INSIDE = new ConcurrentHashMap<>();

    private WarningZoneManager() {
    }

    public static void clearAll() {
        ZONES_BY_DIM.clear();
        SINGLE_PLAYER_TRIGGERED.clear();
        SERVER_WIDE_LOCKED.clear();
        SERVER_WIDE_DIED.clear();
        UNLIMITED_INSIDE.clear();
    }

    public static Path getStorageDir(MinecraftServer server) {
        return server.getWorldPath(LevelResource.ROOT).resolve("warningzone").resolve("zones");
    }

    private static String toSafeFileName(ResourceLocation dimension) {
        return dimension.getNamespace() + "_" + dimension.getPath().replace('/', '_') + ".json";
    }

    public static void loadAll(MinecraftServer server) {
        clearAll();
        Path dir = getStorageDir(server);
        if (!Files.exists(dir)) {
            return;
        }
        for (ServerLevel level : server.getAllLevels()) {
            ResourceLocation dimId = level.dimension().location();
            Path file = dir.resolve(toSafeFileName(dimId));
            if (!Files.exists(file)) {
                continue;
            }
            try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                List<WarningZoneData> list = GSON.fromJson(reader, ZONE_LIST_TYPE);
                if (list != null) {
                    Map<UUID, WarningZoneData> map = new ConcurrentHashMap<>();
                    for (WarningZoneData zone : list) {
                        if (zone != null && zone.getId() != null) {
                            map.put(zone.getId(), zone);
                        }
                    }
                    ZONES_BY_DIM.put(dimId, map);
                }
            } catch (Exception e) {
                WarningZoneMod.LOGGER.error("Failed to load warning zones for dimension {}", dimId, e);
            }
        }
    }

    public static void saveDimension(MinecraftServer server, ResourceLocation dimId) {
        Path dir = getStorageDir(server);
        try {
            Files.createDirectories(dir);
            Path file = dir.resolve(toSafeFileName(dimId));
            Collection<WarningZoneData> zones = getZones(dimId);
            try (Writer writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                GSON.toJson(new ArrayList<>(zones), ZONE_LIST_TYPE, writer);
            }
        } catch (IOException e) {
            WarningZoneMod.LOGGER.error("Failed to save warning zones for dimension {}", dimId, e);
        }
    }

    public static void saveAll(MinecraftServer server) {
        for (ResourceLocation dimId : ZONES_BY_DIM.keySet()) {
            saveDimension(server, dimId);
        }
    }

    public static Collection<WarningZoneData> getZones(ResourceLocation dimId) {
        Map<UUID, WarningZoneData> map = ZONES_BY_DIM.get(dimId);
        return map == null ? Collections.emptyList() : map.values();
    }

    public static void saveOrUpdateZone(ServerLevel level, WarningZoneData zone) {
        ResourceLocation dimId = level.dimension().location();
        ZONES_BY_DIM.computeIfAbsent(dimId, k -> new ConcurrentHashMap<>()).put(zone.getId(), zone);
        // 更新区域配置后清理该区域的旧触发缓存
        resetZoneState(zone.getId());
        saveDimension(level.getServer(), dimId);
        syncDimensionToClients(level);
    }

    public static boolean deleteZone(ServerLevel level, UUID zoneId) {
        ResourceLocation dimId = level.dimension().location();
        Map<UUID, WarningZoneData> map = ZONES_BY_DIM.get(dimId);
        if (map == null || map.remove(zoneId) == null) {
            return false;
        }
        resetZoneState(zoneId);
        saveDimension(level.getServer(), dimId);
        syncDimensionToClients(level);
        return true;
    }

    public static void resetZoneState(UUID zoneId) {
        SINGLE_PLAYER_TRIGGERED.remove(zoneId);
        SERVER_WIDE_LOCKED.remove(zoneId);
        SERVER_WIDE_DIED.remove(zoneId);
        UNLIMITED_INSIDE.remove(zoneId);
    }

    public static void syncDimensionToClients(ServerLevel level) {
        ResourceLocation dimId = level.dimension().location();
        List<WarningZoneData> list = new ArrayList<>(getZones(dimId));
        ModNetwork.CHANNEL.send(
                PacketDistributor.DIMENSION.with(level::dimension),
                new S2CSyncZonesPacket(dimId, list)
        );
    }

    public static void syncDimensionToPlayer(ServerPlayer player) {
        ResourceLocation dimId = player.level().dimension().location();
        List<WarningZoneData> list = new ArrayList<>(getZones(dimId));
        ModNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new S2CSyncZonesPacket(dimId, list)
        );
    }

    /**
     * 每 Tick 检测玩家碰撞箱是否与当前维度内的任意警告区域相交，并按限制模式执行触发。
     */
    public static void tickPlayer(ServerPlayer player) {
        if (player.isSpectator()) {
            return;
        }
        ResourceLocation dimId = player.level().dimension().location();
        Collection<WarningZoneData> zones = getZones(dimId);
        if (zones.isEmpty()) {
            return;
        }

        AABB playerBox = player.getBoundingBox();
        UUID playerId = player.getUUID();

        for (WarningZoneData zone : zones) {
            AABB zoneBox = zone.toAABB();
            boolean inside = zoneBox.intersects(playerBox);

            switch (zone.getTriggerLimit()) {
                case SINGLE_PLAYER -> {
                    if (inside) {
                        Set<UUID> triggered = SINGLE_PLAYER_TRIGGERED
                                .computeIfAbsent(zone.getId(), k -> ConcurrentHashMap.newKeySet());
                        if (triggered.add(playerId)) {
                            sendWarning(player, zone);
                        }
                    }
                }
                case SERVER_WIDE -> {
                    if (inside && !SERVER_WIDE_LOCKED.contains(zone.getId())) {
                        SERVER_WIDE_LOCKED.add(zone.getId());
                        SERVER_WIDE_DIED.computeIfAbsent(zone.getId(), k -> ConcurrentHashMap.newKeySet()).clear();
                        MinecraftServer server = player.getServer();
                        if (server != null) {
                            for (ServerPlayer online : server.getPlayerList().getPlayers()) {
                                sendWarning(online, zone);
                            }
                        }
                    }
                }
                case UNLIMITED -> {
                    Set<UUID> insideSet = UNLIMITED_INSIDE
                            .computeIfAbsent(zone.getId(), k -> ConcurrentHashMap.newKeySet());
                    if (inside) {
                        // 进入区域时触发一次；离开后再进入可再次触发，避免站立不动时每 tick 刷屏
                        if (insideSet.add(playerId)) {
                            sendWarning(player, zone);
                        }
                    } else {
                        insideSet.remove(playerId);
                    }
                }
            }
        }
    }

    /**
     * 玩家死亡时：
     * 1. 重置该玩家在所有「单人限制」区域的触发记录；
     * 2. 记录该玩家在「全服限制」区域的死亡状态，若所有在线玩家均已死亡过一次，则解锁该区域。
     */
    public static void onPlayerDeath(ServerPlayer deadPlayer) {
        UUID deadId = deadPlayer.getUUID();

        // 1. 单人限制：移除该玩家的触发记录
        for (Set<UUID> triggered : SINGLE_PLAYER_TRIGGERED.values()) {
            triggered.remove(deadId);
        }

        // 2. 无限制：死亡后移出区域内状态集合
        for (Set<UUID> inside : UNLIMITED_INSIDE.values()) {
            inside.remove(deadId);
        }

        // 3. 全服限制：记录死亡玩家并检查全服在线玩家是否全部死亡过
        MinecraftServer server = deadPlayer.getServer();
        if (server == null) {
            return;
        }
        List<ServerPlayer> onlinePlayers = server.getPlayerList().getPlayers();
        for (UUID zoneId : new ArrayList<>(SERVER_WIDE_LOCKED)) {
            Set<UUID> diedSet = SERVER_WIDE_DIED
                    .computeIfAbsent(zoneId, k -> ConcurrentHashMap.newKeySet());
            diedSet.add(deadId);

            boolean allOnlineDied = !onlinePlayers.isEmpty()
                    && onlinePlayers.stream().allMatch(p -> diedSet.contains(p.getUUID()));
            if (allOnlineDied) {
                SERVER_WIDE_LOCKED.remove(zoneId);
                diedSet.clear();
            }
        }
    }

    public static void onPlayerLogout(ServerPlayer player) {
        UUID playerId = player.getUUID();
        for (Set<UUID> inside : UNLIMITED_INSIDE.values()) {
            inside.remove(playerId);
        }
    }

    public static Component buildWarningComponent(WarningZoneData zone) {
        MutableComponent prefix = Component.literal("[")
                .append(Component.literal(zone.getWarnerName()).withStyle(zone.getWarnerColor().getFormatting()))
                .append(Component.literal("] "))
                .withStyle(zone.getWarnerColor().getFormatting());

        MutableComponent content = Component.literal(zone.getWarningContent())
                .withStyle(ChatFormatting.WHITE);

        return prefix.append(content);
    }

    private static void sendWarning(ServerPlayer target, WarningZoneData zone) {
        Component message = buildWarningComponent(zone);
        // 聊天框与 Actionbar 同时发送格式化警告消息
        target.sendSystemMessage(message);
        target.displayClientMessage(message, true);
        // 同步通过 CustomNPCs API 通知玩家（若 CNPC IPlayer 可用则触发其消息接口）
        CnpcIntegration.notifyPlayer(target, message.getString());
    }
}
