package com.warningzone.data;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

public enum NameColor {
    BLUE("screen.warningzone.color.blue", ChatFormatting.BLUE, 0.33F, 0.33F, 1.0F),
    RED("screen.warningzone.color.red", ChatFormatting.RED, 1.0F, 0.33F, 0.33F);

    private final String translationKey;
    private final ChatFormatting formatting;
    private final float r;
    private final float g;
    private final float b;

    NameColor(String translationKey, ChatFormatting formatting, float r, float g, float b) {
        this.translationKey = translationKey;
        this.formatting = formatting;
        this.r = r;
        this.g = g;
        this.b = b;
    }

    public String getTranslationKey() {
        return translationKey;
    }

    public Component getDisplayName() {
        return Component.translatable(translationKey).withStyle(formatting);
    }

    public ChatFormatting getFormatting() {
        return formatting;
    }

    public float getR() {
        return r;
    }

    public float getG() {
        return g;
    }

    public float getB() {
        return b;
    }

    public NameColor next() {
        return this == BLUE ? RED : BLUE;
    }
}
