package com.warningzone.data;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.AABB;

import java.util.UUID;

public class WarningZoneData {
    private UUID id;
    private String dimension;
    private int minX;
    private int minY;
    private int minZ;
    private int maxX;
    private int maxY;
    private int maxZ;
    private String warnerName;
    private NameColor warnerColor;
    private String warningContent;
    private TriggerLimitMode triggerLimit;
    private boolean secondWarningEnabled;
    private String secondWarnerName;
    private String secondWarningContent;

    // 缓存碰撞箱与渲染外扩箱，避免在 Tick 与帧渲染热路径中反复 new AABB()
    private transient AABB cachedAabb;
    private transient AABB cachedRenderAabb;

    public WarningZoneData() {
    }

    public WarningZoneData(UUID id, String dimension, BlockPos posA, BlockPos posB,
                           String warnerName, NameColor warnerColor,
                           String warningContent, TriggerLimitMode triggerLimit,
                           boolean secondWarningEnabled, String secondWarnerName, String secondWarningContent) {
        this.id = id;
        this.dimension = dimension;
        this.minX = Math.min(posA.getX(), posB.getX());
        this.minY = Math.min(posA.getY(), posB.getY());
        this.minZ = Math.min(posA.getZ(), posB.getZ());
        this.maxX = Math.max(posA.getX(), posB.getX());
        this.maxY = Math.max(posA.getY(), posB.getY());
        this.maxZ = Math.max(posA.getZ(), posB.getZ());
        this.warnerName = warnerName;
        this.warnerColor = warnerColor;
        this.warningContent = warningContent;
        this.triggerLimit = triggerLimit;
        this.secondWarningEnabled = secondWarningEnabled;
        this.secondWarnerName = secondWarnerName;
        this.secondWarningContent = secondWarningContent;
    }

    public UUID getId() {
        return id;
    }

    public String getDimension() {
        return dimension;
    }

    public int getMinX() {
        return minX;
    }

    public int getMinY() {
        return minY;
    }

    public int getMinZ() {
        return minZ;
    }

    public int getMaxX() {
        return maxX;
    }

    public int getMaxY() {
        return maxY;
    }

    public int getMaxZ() {
        return maxZ;
    }

    public String getWarnerName() {
        return warnerName == null ? "" : warnerName;
    }

    public NameColor getWarnerColor() {
        return warnerColor == null ? NameColor.BLUE : warnerColor;
    }

    public String getWarningContent() {
        return warningContent == null ? "" : warningContent;
    }

    public TriggerLimitMode getTriggerLimit() {
        return triggerLimit == null ? TriggerLimitMode.SINGLE_PLAYER : triggerLimit;
    }

    public boolean isSecondWarningEnabled() {
        return secondWarningEnabled;
    }

    public String getSecondWarnerName() {
        return secondWarnerName == null ? "" : secondWarnerName;
    }

    public String getSecondWarningContent() {
        return secondWarningContent == null ? "" : secondWarningContent;
    }

    public AABB toAABB() {
        if (cachedAabb == null) {
            cachedAabb = new AABB(minX, minY, minZ, maxX + 1.0D, maxY + 1.0D, maxZ + 1.0D);
        }
        return cachedAabb;
    }

    public AABB toRenderAABB() {
        if (cachedRenderAabb == null) {
            cachedRenderAabb = toAABB().inflate(0.002D);
        }
        return cachedRenderAabb;
    }

    /**
     * 粗筛：纯基本类型坐标比较，快速排除明显不在附近的区域，避免进入 AABB.intersects。
     */
    public boolean isNearPoint(double x, double y, double z, double margin) {
        return x >= minX - margin && x <= maxX + 1.0D + margin
                && z >= minZ - margin && z <= maxZ + 1.0D + margin
                && y >= minY - margin && y <= maxY + 2.0D + margin;
    }

    public boolean containsBlock(BlockPos pos) {
        return pos.getX() >= minX && pos.getX() <= maxX
                && pos.getY() >= minY && pos.getY() <= maxY
                && pos.getZ() >= minZ && pos.getZ() <= maxZ;
    }

    public boolean matchesBounds(BlockPos posA, BlockPos posB) {
        int aMinX = Math.min(posA.getX(), posB.getX());
        int aMinY = Math.min(posA.getY(), posB.getY());
        int aMinZ = Math.min(posA.getZ(), posB.getZ());
        int aMaxX = Math.max(posA.getX(), posB.getX());
        int aMaxY = Math.max(posA.getY(), posB.getY());
        int aMaxZ = Math.max(posA.getZ(), posB.getZ());
        return minX == aMinX && minY == aMinY && minZ == aMinZ
                && maxX == aMaxX && maxY == aMaxY && maxZ == aMaxZ;
    }

    public void writeToBuf(FriendlyByteBuf buf) {
        buf.writeUUID(id);
        buf.writeUtf(dimension);
        buf.writeInt(minX);
        buf.writeInt(minY);
        buf.writeInt(minZ);
        buf.writeInt(maxX);
        buf.writeInt(maxY);
        buf.writeInt(maxZ);
        buf.writeUtf(getWarnerName());
        buf.writeEnum(getWarnerColor());
        buf.writeUtf(getWarningContent());
        buf.writeEnum(getTriggerLimit());
        buf.writeBoolean(secondWarningEnabled);
        buf.writeUtf(getSecondWarnerName());
        buf.writeUtf(getSecondWarningContent());
    }

    public static WarningZoneData readFromBuf(FriendlyByteBuf buf) {
        WarningZoneData data = new WarningZoneData();
        data.id = buf.readUUID();
        data.dimension = buf.readUtf();
        data.minX = buf.readInt();
        data.minY = buf.readInt();
        data.minZ = buf.readInt();
        data.maxX = buf.readInt();
        data.maxY = buf.readInt();
        data.maxZ = buf.readInt();
        data.warnerName = buf.readUtf();
        data.warnerColor = buf.readEnum(NameColor.class);
        data.warningContent = buf.readUtf();
        data.triggerLimit = buf.readEnum(TriggerLimitMode.class);
        data.secondWarningEnabled = buf.readBoolean();
        data.secondWarnerName = buf.readUtf();
        data.secondWarningContent = buf.readUtf();
        return data;
    }
}
