package com.warningzone.data;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.AABB;

import java.util.UUID;

public class WarningZoneData {
    private UUID id;
    private String dimension;
    private int minX;
    private int minY;
    private int minZ;
    private int maxX;
    private int maxY;
    private int maxZ;
    private String warnerName;
    private NameColor warnerColor;
    private String warningContent;
    private TriggerLimitMode triggerLimit;

    public WarningZoneData() {
    }

    public WarningZoneData(UUID id, String dimension, BlockPos posA, BlockPos posB,
                           String warnerName, NameColor warnerColor,
                           String warningContent, TriggerLimitMode triggerLimit) {
        this.id = id;
        this.dimension = dimension;
        this.minX = Math.min(posA.getX(), posB.getX());
        this.minY = Math.min(posA.getY(), posB.getY());
        this.minZ = Math.min(posA.getZ(), posB.getZ());
        this.maxX = Math.max(posA.getX(), posB.getX());
        this.maxY = Math.max(posA.getY(), posB.getY());
        this.maxZ = Math.max(posA.getZ(), posB.getZ());
        this.warnerName = warnerName;
        this.warnerColor = warnerColor;
        this.warningContent = warningContent;
        this.triggerLimit = triggerLimit;
    }

    public UUID getId() {
        return id;
    }

    public String getDimension() {
        return dimension;
    }

    public int getMinX() {
        return minX;
    }

    public int getMinY() {
        return minY;
    }

    public int getMinZ() {
        return minZ;
    }

    public int getMaxX() {
        return maxX;
    }

    public int getMaxY() {
        return maxY;
    }

    public int getMaxZ() {
        return maxZ;
    }

    public String getWarnerName() {
        return warnerName == null ? "" : warnerName;
    }

    public NameColor getWarnerColor() {
        return warnerColor == null ? NameColor.BLUE : warnerColor;
    }

    public String getWarningContent() {
        return warningContent == null ? "" : warningContent;
    }

    public TriggerLimitMode getTriggerLimit() {
        return triggerLimit == null ? TriggerLimitMode.SINGLE_PLAYER : triggerLimit;
    }

    public AABB toAABB() {
        return new AABB(minX, minY, minZ, maxX + 1.0D, maxY + 1.0D, maxZ + 1.0D);
    }

    public boolean matchesBounds(BlockPos posA, BlockPos posB) {
        int aMinX = Math.min(posA.getX(), posB.getX());
        int aMinY = Math.min(posA.getY(), posB.getY());
        int aMinZ = Math.min(posA.getZ(), posB.getZ());
        int aMaxX = Math.max(posA.getX(), posB.getX());
        int aMaxY = Math.max(posA.getY(), posB.getY());
        int aMaxZ = Math.max(posA.getZ(), posB.getZ());
        return minX == aMinX && minY == aMinY && minZ == aMinZ
                && maxX == aMaxX && maxY == aMaxY && maxZ == aMaxZ;
    }

    public void writeToBuf(FriendlyByteBuf buf) {
        buf.writeUUID(id);
        buf.writeUtf(dimension);
        buf.writeInt(minX);
        buf.writeInt(minY);
        buf.writeInt(minZ);
        buf.writeInt(maxX);
        buf.writeInt(maxY);
        buf.writeInt(maxZ);
        buf.writeUtf(getWarnerName());
        buf.writeEnum(getWarnerColor());
        buf.writeUtf(getWarningContent());
        buf.writeEnum(getTriggerLimit());
    }

    public static WarningZoneData readFromBuf(FriendlyByteBuf buf) {
        WarningZoneData data = new WarningZoneData();
        data.id = buf.readUUID();
        data.dimension = buf.readUtf();
        data.minX = buf.readInt();
        data.minY = buf.readInt();
        data.minZ = buf.readInt();
        data.maxX = buf.readInt();
        data.maxY = buf.readInt();
        data.maxZ = buf.readInt();
        data.warnerName = buf.readUtf();
        data.warnerColor = buf.readEnum(NameColor.class);
        data.warningContent = buf.readUtf();
        data.triggerLimit = buf.readEnum(TriggerLimitMode.class);
        return data;
    }
}
