package com.warningzone.data;

import net.minecraft.network.chat.Component;

public enum TriggerLimitMode {
    SINGLE_PLAYER("screen.warningzone.limit.single_player"),
    SERVER_WIDE("screen.warningzone.limit.server_wide"),
    UNLIMITED("screen.warningzone.limit.unlimited");

    private final String translationKey;

    TriggerLimitMode(String translationKey) {
        this.translationKey = translationKey;
    }

    public String getTranslationKey() {
        return translationKey;
    }

    public Component getDisplayName() {
        return Component.translatable(translationKey);
    }

    public TriggerLimitMode next() {
        TriggerLimitMode[] values = values();
        return values[(ordinal() + 1) % values.length];
    }
}
