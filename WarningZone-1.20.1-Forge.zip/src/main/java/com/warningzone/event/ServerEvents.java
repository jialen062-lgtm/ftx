package com.warningzone.event;

import com.warningzone.WarningZoneMod;
import com.warningzone.data.WarningZoneManager;
import com.warningzone.item.ModItems;
import com.warningzone.item.WarningZoneItem;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = WarningZoneMod.MOD_ID)
public final class ServerEvents {
    private ServerEvents() {
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        WarningZoneManager.loadAll(event.getServer());
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        WarningZoneManager.saveAll(event.getServer());
        WarningZoneManager.clearAll();
    }

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            WarningZoneManager.syncDimensionToPlayer(player);
        }
    }

    @SubscribeEvent
    public static void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            WarningZoneManager.syncDimensionToPlayer(player);
        }
    }

    @SubscribeEvent
    public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            WarningZoneManager.onPlayerLogout(player);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide()) {
            return;
        }
        if (event.player instanceof ServerPlayer serverPlayer) {
            WarningZoneManager.tickPlayer(serverPlayer);
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer deadPlayer && !deadPlayer.level().isClientSide()) {
            WarningZoneManager.onPlayerDeath(deadPlayer);
        }
    }

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        ItemStack stack = event.getItemStack();
        if (!stack.is(ModItems.WARNING_ZONE_WAND.get())) {
            return;
        }
        event.setCanceled(true);
        if (!event.getLevel().isClientSide()) {
            WarningZoneItem.setPosA(stack, event.getPos());
            event.getEntity().sendSystemMessage(Component.translatable(
                    "message.warningzone.pos_a_set",
                    event.getPos().getX(), event.getPos().getY(), event.getPos().getZ()
            ));
        }
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        ItemStack stack = event.getItemStack();
        if (!stack.is(ModItems.WARNING_ZONE_WAND.get())) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (!event.getLevel().isClientSide()) {
            WarningZoneItem.setPosB(stack, event.getPos());
            event.getEntity().sendSystemMessage(Component.translatable(
                    "message.warningzone.pos_b_set",
                    event.getPos().getX(), event.getPos().getY(), event.getPos().getZ()
            ));
        }
    }
}
