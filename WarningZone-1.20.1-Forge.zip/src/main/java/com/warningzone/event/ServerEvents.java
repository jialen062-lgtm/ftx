package com.warningzone.event;

import com.mojang.brigadier.CommandDispatcher;
import com.warningzone.WarningZoneMod;
import com.warningzone.data.WarningZoneData;
import com.warningzone.data.WarningZoneManager;
import com.warningzone.item.ModItems;
import com.warningzone.item.WarningZoneItem;
import com.warningzone.network.ModNetwork;
import com.warningzone.network.S2CSelectionPacket;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = WarningZoneMod.MOD_ID)
public final class ServerEvents {
    private ServerEvents() {
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("sc")
                .then(Commands.literal("jg")
                        .requires(source -> source.hasPermission(2))
                        .executes(ctx -> {
                            int count = WarningZoneManager.deleteAllZones(ctx.getSource().getServer());
                            ctx.getSource().sendSuccess(
                                    () -> Component.translatable("message.warningzone.deleted_all", count),
                                    true
                            );
                            return count;
                        })
                )
        );
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        WarningZoneManager.loadAll(event.getServer());
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        WarningZoneManager.saveAll(event.getServer());
        WarningZoneManager.clearAll();
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            WarningZoneManager.tickScheduledWarnings(event.getServer());
        }
    }

    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            WarningZoneManager.syncDimensionToPlayer(player);
        }
    }

    @SubscribeEvent
    public static void onPlayerChangedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            WarningZoneManager.syncDimensionToPlayer(player);
        }
    }

    @SubscribeEvent
    public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            WarningZoneManager.onPlayerLogout(player);
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide()) {
            return;
        }
        if (event.player instanceof ServerPlayer serverPlayer) {
            WarningZoneManager.tickPlayer(serverPlayer);
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer deadPlayer && !deadPlayer.level().isClientSide()) {
            WarningZoneManager.onPlayerDeath(deadPlayer);
        }
    }

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        ItemStack stack = event.getItemStack();
        if (stack.is(ModItems.ZONE_EDITOR_WAND.get())) {
            event.setCanceled(true);
            return;
        }
        if (!stack.is(ModItems.WARNING_ZONE_WAND.get())) {
            return;
        }
        event.setCanceled(true);
        if (!event.getLevel().isClientSide() && event.getEntity() instanceof ServerPlayer player) {
            BlockPos pos = event.getPos().immutable();
            WarningZoneItem.setPosA(stack, pos);
            player.sendSystemMessage(Component.translatable(
                    "message.warningzone.pos_a_set",
                    pos.getX(), pos.getY(), pos.getZ()
            ));
            BlockPos posB = WarningZoneItem.getPosB(stack);
            boolean bothSet = (posB != null);
            ModNetwork.CHANNEL.send(
                    PacketDistributor.PLAYER.with(() -> player),
                    new S2CSelectionPacket(pos, posB, bothSet)
            );
        }
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        ItemStack stack = event.getItemStack();

        // 1. 「区域设置器」右键方块：查找点击位置或玩家附近已保存的区域并打开编辑界面
        if (stack.is(ModItems.ZONE_EDITOR_WAND.get())) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
            if (!event.getLevel().isClientSide() && event.getEntity() instanceof ServerPlayer player) {
                openEditorForPlayer(player, event.getPos().immutable());
            }
            return;
        }

        // 2. 「警告区域器」右键方块：记录点 B 并在选满 A/B 后打开配置界面
        if (!stack.is(ModItems.WARNING_ZONE_WAND.get())) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);

        if (!event.getLevel().isClientSide() && event.getEntity() instanceof ServerPlayer player) {
            BlockPos pos = event.getPos().immutable();
            WarningZoneItem.setPosB(stack, pos);
            player.sendSystemMessage(Component.translatable(
                    "message.warningzone.pos_b_set",
                    pos.getX(), pos.getY(), pos.getZ()
            ));
            BlockPos posA = WarningZoneItem.getPosA(stack);
            boolean bothSet = (posA != null);
            ModNetwork.CHANNEL.send(
                    PacketDistributor.PLAYER.with(() -> player),
                    new S2CSelectionPacket(posA, pos, bothSet)
            );
        }
    }

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }
        ItemStack stack = event.getItemStack();
        if (!stack.is(ModItems.ZONE_EDITOR_WAND.get())) {
            return;
        }
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (!event.getLevel().isClientSide() && event.getEntity() instanceof ServerPlayer player) {
            openEditorForPlayer(player, player.blockPosition());
        }
    }

    private static void openEditorForPlayer(ServerPlayer player, BlockPos targetPos) {
        WarningZoneData zone = WarningZoneManager.findZoneForEditor(
                player.level().dimension().location(),
                targetPos,
                player.blockPosition()
        );
        if (zone == null) {
            player.sendSystemMessage(Component.translatable("message.warningzone.no_zone_found"));
            return;
        }
        BlockPos a = new BlockPos(zone.getMinX(), zone.getMinY(), zone.getMinZ());
        BlockPos b = new BlockPos(zone.getMaxX(), zone.getMaxY(), zone.getMaxZ());
        ModNetwork.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> player),
                new S2CSelectionPacket(a, b, true, zone.getId())
        );
    }
}
