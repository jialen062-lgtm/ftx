package com.warningzone.item;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

public class WarningZoneItem extends Item {
    private static final String TAG_POS_A = "WarningZonePosA";
    private static final String TAG_POS_B = "WarningZonePosB";

    public WarningZoneItem(Properties properties) {
        super(properties);
    }

    @Override
    public boolean canAttackBlock(BlockState state, Level level, BlockPos pos, Player player) {
        // 防止创造模式左键选点时破坏方块
        return false;
    }

    public static void setPosA(ItemStack stack, BlockPos pos) {
        stack.getOrCreateTag().putIntArray(TAG_POS_A, new int[]{pos.getX(), pos.getY(), pos.getZ()});
    }

    public static void setPosB(ItemStack stack, BlockPos pos) {
        stack.getOrCreateTag().putIntArray(TAG_POS_B, new int[]{pos.getX(), pos.getY(), pos.getZ()});
    }

    @Nullable
    public static BlockPos getPosA(ItemStack stack) {
        return readPos(stack, TAG_POS_A);
    }

    @Nullable
    public static BlockPos getPosB(ItemStack stack) {
        return readPos(stack, TAG_POS_B);
    }

    public static void clearSelection(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        if (tag != null) {
            tag.remove(TAG_POS_A);
            tag.remove(TAG_POS_B);
        }
    }

    @Nullable
    private static BlockPos readPos(ItemStack stack, String key) {
        CompoundTag tag = stack.getTag();
        if (tag == null || !tag.contains(key, Tag.TAG_INT_ARRAY)) {
            return null;
        }
        int[] arr = tag.getIntArray(key);
        if (arr.length != 3) {
            return null;
        }
        return new BlockPos(arr[0], arr[1], arr[2]);
    }
}
