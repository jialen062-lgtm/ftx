package com.warningzone.item;

import com.warningzone.WarningZoneMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, WarningZoneMod.MOD_ID);

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, WarningZoneMod.MOD_ID);

    public static final RegistryObject<Item> WARNING_ZONE_WAND = ITEMS.register(
            "warning_zone_wand",
            () -> new WarningZoneItem(new Item.Properties().stacksTo(1))
    );

    public static final RegistryObject<Item> ZONE_EDITOR_WAND = ITEMS.register(
            "zone_editor_wand",
            () -> new ZoneEditorItem(new Item.Properties().stacksTo(1))
    );

    public static final RegistryObject<CreativeModeTab> WARNING_ZONE_TAB = CREATIVE_TABS.register(
            "warning_zone_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("creativetab.warningzone"))
                    .icon(() -> new ItemStack(WARNING_ZONE_WAND.get()))
                    .displayItems((params, output) -> {
                        output.accept(WARNING_ZONE_WAND.get());
                        output.accept(ZONE_EDITOR_WAND.get());
                    })
                    .build()
    );

    private ModItems() {
    }
}
