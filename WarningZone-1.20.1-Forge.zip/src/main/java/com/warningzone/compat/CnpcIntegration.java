package com.warningzone.compat;

import com.warningzone.WarningZoneMod;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;

import java.lang.reflect.Method;

/**
 * CustomNPCs Unofficial (CNPC) API 与事件桥接层。
 * 通过反射安全对接 noppes.npcs.api.NpcAPI，确保在未将 CNPC JAR 放入 libs/ 时也能正常编译，
 * 且在运行时正确挂载 CNPC 事件总线与 IPlayer 接口。
 */
public final class CnpcIntegration {
    private static boolean initialized = false;
    private static Object npcApiInstance;
    private static Method getIEntityMethod;
    private static Method playerMessageMethod;

    private CnpcIntegration() {
    }

    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;
        if (!ModList.get().isLoaded("customnpcs")) {
            WarningZoneMod.LOGGER.warn("CustomNPCs Unofficial is not loaded; CNPC API bridge disabled.");
            return;
        }

        try {
            Class<?> npcApiClass = Class.forName("noppes.npcs.api.NpcAPI");
            Method instanceMethod = npcApiClass.getMethod("Instance");
            npcApiInstance = instanceMethod.invoke(null);
            if (npcApiInstance == null) {
                return;
            }

            // 注册自定义监听对象到 CNPC 事件总线: NpcAPI.Instance().events().register(listener)
            Method eventsMethod = npcApiClass.getMethod("events");
            Object eventBus = eventsMethod.invoke(npcApiInstance);
            if (eventBus != null) {
                Method registerMethod = eventBus.getClass().getMethod("register", Object.class);
                registerMethod.invoke(eventBus, new CnpcEventListener());
                WarningZoneMod.LOGGER.info("Registered WarningZone listener to CustomNPCs API event bus.");
            }

            getIEntityMethod = npcApiClass.getMethod("getIEntity", net.minecraft.world.entity.Entity.class);
            Class<?> iPlayerClass = Class.forName("noppes.npcs.api.entity.IPlayer");
            playerMessageMethod = iPlayerClass.getMethod("message", String.class);
        } catch (Throwable t) {
            WarningZoneMod.LOGGER.warn("Failed to initialize CustomNPCs API bridge: {}", t.getMessage());
        }
    }

    /**
     * 可选调用 CNPC IPlayer.message(...)，用于联动 CNPC 脚本生态。
     */
    public static void notifyPlayer(ServerPlayer player, String plainText) {
        if (npcApiInstance == null || getIEntityMethod == null || playerMessageMethod == null) {
            return;
        }
        try {
            Object iEntity = getIEntityMethod.invoke(npcApiInstance, player);
            if (iEntity != null && playerMessageMethod.getDeclaringClass().isInstance(iEntity)) {
                // 仅在需要由 CNPC 客户端日志/脚本监听时可扩展调用，避免重复聊天刷屏
                // playerMessageMethod.invoke(iEntity, plainText);
            }
        } catch (Throwable ignored) {
        }
    }

    /**
     * CNPC API 事件监听器示例：可接收 CNPC 触发的脚本/世界事件。
     */
    public static class CnpcEventListener {
        @SubscribeEvent
        public void onCnpcEvent(net.minecraftforge.eventbus.api.Event event) {
            // 预留接收 noppes.npcs.api.event.* 事件（如 PlayerEvent、WorldEvent）的扩展入口
        }
    }
}
