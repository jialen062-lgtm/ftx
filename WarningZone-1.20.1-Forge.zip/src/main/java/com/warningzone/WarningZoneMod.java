package com.warningzone;

import com.mojang.logging.LogUtils;
import com.warningzone.compat.CnpcIntegration;
import com.warningzone.item.ModItems;
import com.warningzone.network.ModNetwork;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(WarningZoneMod.MOD_ID)
public class WarningZoneMod {
    public static final String MOD_ID = "warningzone";
    public static final Logger LOGGER = LogUtils.getLogger();

    public WarningZoneMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modEventBus);
        ModItems.CREATIVE_TABS.register(modEventBus);
        modEventBus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            ModNetwork.register();
            CnpcIntegration.init();
        });
    }
}
