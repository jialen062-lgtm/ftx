package com.warningzone.network;

import com.warningzone.client.ClientZoneCache;
import com.warningzone.client.screen.WarningZoneScreen;
import com.warningzone.data.WarningZoneData;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.function.Supplier;

public class S2CSelectionPacket {
    @Nullable
    private final BlockPos posA;
    @Nullable
    private final BlockPos posB;
    private final boolean openGui;

    public S2CSelectionPacket(@Nullable BlockPos posA, @Nullable BlockPos posB, boolean openGui) {
        this.posA = posA;
        this.posB = posB;
        this.openGui = openGui;
    }

    public static void encode(S2CSelectionPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.posA != null);
        if (msg.posA != null) {
            buf.writeBlockPos(msg.posA);
        }
        buf.writeBoolean(msg.posB != null);
        if (msg.posB != null) {
            buf.writeBlockPos(msg.posB);
        }
        buf.writeBoolean(msg.openGui);
    }

    public static S2CSelectionPacket decode(FriendlyByteBuf buf) {
        BlockPos a = buf.readBoolean() ? buf.readBlockPos() : null;
        BlockPos b = buf.readBoolean() ? buf.readBlockPos() : null;
        boolean open = buf.readBoolean();
        return new S2CSelectionPacket(a, b, open);
    }

    public static void handle(S2CSelectionPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            ClientZoneCache.setPendingPosA(msg.posA);
            ClientZoneCache.setPendingPosB(msg.posB);
            if (msg.openGui && msg.posA != null && msg.posB != null) {
                WarningZoneData existing = ClientZoneCache.findMatchingZone(msg.posA, msg.posB);
                Minecraft.getInstance().setScreen(new WarningZoneScreen(msg.posA, msg.posB, existing));
            }
        });
        ctx.setPacketHandled(true);
    }
}
