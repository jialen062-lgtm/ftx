package com.warningzone.network;

import com.warningzone.data.NameColor;
import com.warningzone.data.TriggerLimitMode;
import com.warningzone.data.WarningZoneData;
import com.warningzone.data.WarningZoneManager;
import com.warningzone.item.ModItems;
import com.warningzone.item.WarningZoneItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.UUID;
import java.util.function.Supplier;

public class C2SSaveZonePacket {
    @Nullable
    private final UUID zoneId;
    private final BlockPos posA;
    private final BlockPos posB;
    private final String warnerName;
    private final NameColor warnerColor;
    private final String warningContent;
    private final TriggerLimitMode triggerLimit;
    private final boolean secondWarningEnabled;
    private final String secondWarnerName;
    private final String secondWarningContent;

    public C2SSaveZonePacket(@Nullable UUID zoneId, BlockPos posA, BlockPos posB,
                             String warnerName, NameColor warnerColor,
                             String warningContent, TriggerLimitMode triggerLimit,
                             boolean secondWarningEnabled, String secondWarnerName, String secondWarningContent) {
        this.zoneId = zoneId;
        this.posA = posA;
        this.posB = posB;
        this.warnerName = warnerName;
        this.warnerColor = warnerColor;
        this.warningContent = warningContent;
        this.triggerLimit = triggerLimit;
        this.secondWarningEnabled = secondWarningEnabled;
        this.secondWarnerName = secondWarnerName;
        this.secondWarningContent = secondWarningContent;
    }

    public static void encode(C2SSaveZonePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.zoneId != null);
        if (msg.zoneId != null) {
            buf.writeUUID(msg.zoneId);
        }
        buf.writeBlockPos(msg.posA);
        buf.writeBlockPos(msg.posB);
        buf.writeUtf(msg.warnerName == null ? "" : msg.warnerName);
        buf.writeEnum(msg.warnerColor == null ? NameColor.BLUE : msg.warnerColor);
        buf.writeUtf(msg.warningContent == null ? "" : msg.warningContent);
        buf.writeEnum(msg.triggerLimit == null ? TriggerLimitMode.SINGLE_PLAYER : msg.triggerLimit);
        buf.writeBoolean(msg.secondWarningEnabled);
        buf.writeUtf(msg.secondWarnerName == null ? "" : msg.secondWarnerName);
        buf.writeUtf(msg.secondWarningContent == null ? "" : msg.secondWarningContent);
    }

    public static C2SSaveZonePacket decode(FriendlyByteBuf buf) {
        UUID id = buf.readBoolean() ? buf.readUUID() : null;
        BlockPos posA = buf.readBlockPos();
        BlockPos posB = buf.readBlockPos();
        String name = buf.readUtf();
        NameColor color = buf.readEnum(NameColor.class);
        String content = buf.readUtf();
        TriggerLimitMode limit = buf.readEnum(TriggerLimitMode.class);
        boolean secondEnabled = buf.readBoolean();
        String secondName = buf.readUtf();
        String secondContent = buf.readUtf();
        return new C2SSaveZonePacket(id, posA, posB, name, color, content, limit, secondEnabled, secondName, secondContent);
    }

    public static void handle(C2SSaveZonePacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ServerPlayer player = ctx.getSender();
        if (player == null) {
            ctx.setPacketHandled(true);
            return;
        }
        boolean hasTool = player.getMainHandItem().is(ModItems.WARNING_ZONE_WAND.get())
                || player.getOffhandItem().is(ModItems.WARNING_ZONE_WAND.get())
                || player.getMainHandItem().is(ModItems.ZONE_EDITOR_WAND.get())
                || player.getOffhandItem().is(ModItems.ZONE_EDITOR_WAND.get());
        if (!hasTool && !player.hasPermissions(2)) {
            ctx.setPacketHandled(true);
            return;
        }

        ServerLevel level = player.serverLevel();
        UUID id = msg.zoneId != null ? msg.zoneId : UUID.randomUUID();
        WarningZoneData zone = new WarningZoneData(
                id,
                level.dimension().location().toString(),
                msg.posA,
                msg.posB,
                msg.warnerName,
                msg.warnerColor,
                msg.warningContent,
                msg.triggerLimit,
                msg.secondWarningEnabled,
                msg.secondWarnerName,
                msg.secondWarningContent
        );
        WarningZoneManager.saveOrUpdateZone(level, zone);
        if (player.getMainHandItem().is(ModItems.WARNING_ZONE_WAND.get())) {
            WarningZoneItem.clearSelection(player.getMainHandItem());
        }
        player.sendSystemMessage(Component.translatable("message.warningzone.saved"));
        ctx.setPacketHandled(true);
    }
}
