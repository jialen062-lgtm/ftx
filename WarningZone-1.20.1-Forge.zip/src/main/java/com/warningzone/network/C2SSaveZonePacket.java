package com.warningzone.network;

import com.warningzone.data.NameColor;
import com.warningzone.data.TriggerLimitMode;
import com.warningzone.data.WarningZoneData;
import com.warningzone.data.WarningZoneManager;
import com.warningzone.item.ModItems;
import com.warningzone.item.WarningZoneItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import javax.annotation.Nullable;
import java.util.UUID;
import java.util.function.Supplier;

public class C2SSaveZonePacket {
    @Nullable
    private final UUID zoneId;
    private final BlockPos posA;
    private final BlockPos posB;
    private final String warnerName;
    private final NameColor warnerColor;
    private final String warningContent;
    private final TriggerLimitMode triggerLimit;

    public C2SSaveZonePacket(@Nullable UUID zoneId, BlockPos posA, BlockPos posB,
                             String warnerName, NameColor warnerColor,
                             String warningContent, TriggerLimitMode triggerLimit) {
        this.zoneId = zoneId;
        this.posA = posA;
        this.posB = posB;
        this.warnerName = warnerName;
        this.warnerColor = warnerColor;
        this.warningContent = warningContent;
        this.triggerLimit = triggerLimit;
    }

    public static void encode(C2SSaveZonePacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.zoneId != null);
        if (msg.zoneId != null) {
            buf.writeUUID(msg.zoneId);
        }
        buf.writeBlockPos(msg.posA);
        buf.writeBlockPos(msg.posB);
        buf.writeUtf(msg.warnerName == null ? "" : msg.warnerName);
        buf.writeEnum(msg.warnerColor == null ? NameColor.BLUE : msg.warnerColor);
        buf.writeUtf(msg.warningContent == null ? "" : msg.warningContent);
        buf.writeEnum(msg.triggerLimit == null ? TriggerLimitMode.SINGLE_PLAYER : msg.triggerLimit);
    }

    public static C2SSaveZonePacket decode(FriendlyByteBuf buf) {
        UUID id = buf.readBoolean() ? buf.readUUID() : null;
        BlockPos posA = buf.readBlockPos();
        BlockPos posB = buf.readBlockPos();
        String name = buf.readUtf();
        NameColor color = buf.readEnum(NameColor.class);
        String content = buf.readUtf();
        TriggerLimitMode limit = buf.readEnum(TriggerLimitMode.class);
        return new C2SSaveZonePacket(id, posA, posB, name, color, content, limit);
    }

    public static void handle(C2SSaveZonePacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ServerPlayer player = ctx.getSender();
        if (player == null) {
            ctx.setPacketHandled(true);
            return;
        }
        if (!player.getMainHandItem().is(ModItems.WARNING_ZONE_WAND.get())
                && !player.getOffhandItem().is(ModItems.WARNING_ZONE_WAND.get())
                && !player.hasPermissions(2)) {
            ctx.setPacketHandled(true);
            return;
        }

        ServerLevel level = player.serverLevel();
        UUID id = msg.zoneId != null ? msg.zoneId : UUID.randomUUID();
        WarningZoneData zone = new WarningZoneData(
                id,
                level.dimension().location().toString(),
                msg.posA,
                msg.posB,
                msg.warnerName,
                msg.warnerColor,
                msg.warningContent,
                msg.triggerLimit
        );
        WarningZoneManager.saveOrUpdateZone(level, zone);
        if (player.getMainHandItem().is(ModItems.WARNING_ZONE_WAND.get())) {
            WarningZoneItem.clearSelection(player.getMainHandItem());
        }
        player.sendSystemMessage(Component.translatable("message.warningzone.saved"));
        ctx.setPacketHandled(true);
    }
}
