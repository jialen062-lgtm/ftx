package com.warningzone.network;

import com.warningzone.data.WarningZoneManager;
import com.warningzone.item.ModItems;
import com.warningzone.item.WarningZoneItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

public class C2SDeleteZonePacket {
    private final UUID zoneId;

    public C2SDeleteZonePacket(UUID zoneId) {
        this.zoneId = zoneId;
    }

    public static void encode(C2SDeleteZonePacket msg, FriendlyByteBuf buf) {
        buf.writeUUID(msg.zoneId);
    }

    public static C2SDeleteZonePacket decode(FriendlyByteBuf buf) {
        return new C2SDeleteZonePacket(buf.readUUID());
    }

    public static void handle(C2SDeleteZonePacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ServerPlayer player = ctx.getSender();
        if (player == null) {
            ctx.setPacketHandled(true);
            return;
        }
        boolean hasTool = player.getMainHandItem().is(ModItems.WARNING_ZONE_WAND.get())
                || player.getOffhandItem().is(ModItems.WARNING_ZONE_WAND.get())
                || player.getMainHandItem().is(ModItems.ZONE_EDITOR_WAND.get())
                || player.getOffhandItem().is(ModItems.ZONE_EDITOR_WAND.get());
        if (!hasTool && !player.hasPermissions(2)) {
            ctx.setPacketHandled(true);
            return;
        }

        ServerLevel level = player.serverLevel();
        if (player.getMainHandItem().is(ModItems.WARNING_ZONE_WAND.get())) {
            WarningZoneItem.clearSelection(player.getMainHandItem());
        }
        if (WarningZoneManager.deleteZone(level, msg.zoneId)) {
            player.sendSystemMessage(Component.translatable("message.warningzone.deleted"));
        }
        ctx.setPacketHandled(true);
    }
}
