package com.warningzone.network;

import com.warningzone.item.ModItems;
import com.warningzone.item.WarningZoneItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class C2SClearSelectionPacket {
    public C2SClearSelectionPacket() {
    }

    public static void encode(C2SClearSelectionPacket msg, FriendlyByteBuf buf) {
    }

    public static C2SClearSelectionPacket decode(FriendlyByteBuf buf) {
        return new C2SClearSelectionPacket();
    }

    public static void handle(C2SClearSelectionPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ServerPlayer player = ctx.getSender();
        if (player != null) {
            ItemStack main = player.getMainHandItem();
            if (main.is(ModItems.WARNING_ZONE_WAND.get())) {
                WarningZoneItem.clearSelection(main);
            }
        }
        ctx.setPacketHandled(true);
    }
}
