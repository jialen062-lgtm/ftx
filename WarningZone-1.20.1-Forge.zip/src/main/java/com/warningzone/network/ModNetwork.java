package com.warningzone.network;

import com.warningzone.WarningZoneMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(WarningZoneMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int packetId = 0;

    private ModNetwork() {
    }

    public static void register() {
        CHANNEL.messageBuilder(C2SSaveZonePacket.class, packetId++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(C2SSaveZonePacket::encode)
                .decoder(C2SSaveZonePacket::decode)
                .consumerMainThread(C2SSaveZonePacket::handle)
                .add();

        CHANNEL.messageBuilder(C2SDeleteZonePacket.class, packetId++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(C2SDeleteZonePacket::encode)
                .decoder(C2SDeleteZonePacket::decode)
                .consumerMainThread(C2SDeleteZonePacket::handle)
                .add();

        CHANNEL.messageBuilder(S2CSyncZonesPacket.class, packetId++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(S2CSyncZonesPacket::encode)
                .decoder(S2CSyncZonesPacket::decode)
                .consumerMainThread(S2CSyncZonesPacket::handle)
                .add();
    }
}
