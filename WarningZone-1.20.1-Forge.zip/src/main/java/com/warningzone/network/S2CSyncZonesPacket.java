package com.warningzone.network;

import com.warningzone.client.ClientZoneCache;
import com.warningzone.data.WarningZoneData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class S2CSyncZonesPacket {
    private final ResourceLocation dimension;
    private final List<WarningZoneData> zones;

    public S2CSyncZonesPacket(ResourceLocation dimension, List<WarningZoneData> zones) {
        this.dimension = dimension;
        this.zones = zones;
    }

    public static void encode(S2CSyncZonesPacket msg, FriendlyByteBuf buf) {
        buf.writeResourceLocation(msg.dimension);
        buf.writeInt(msg.zones.size());
        for (WarningZoneData zone : msg.zones) {
            zone.writeToBuf(buf);
        }
    }

    public static S2CSyncZonesPacket decode(FriendlyByteBuf buf) {
        ResourceLocation dim = buf.readResourceLocation();
        int count = buf.readInt();
        List<WarningZoneData> list = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            list.add(WarningZoneData.readFromBuf(buf));
        }
        return new S2CSyncZonesPacket(dim, list);
    }

    public static void handle(S2CSyncZonesPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientZoneCache.setZones(msg.dimension, msg.zones)
        );
        ctx.setPacketHandled(true);
    }
}
