package com.jjkmod.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class ModConfig {
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final Common COMMON;

    public static final ForgeConfigSpec CLIENT_SPEC;
    public static final Client CLIENT;

    static {
        ForgeConfigSpec.Builder commonBuilder = new ForgeConfigSpec.Builder();
        COMMON = new Common(commonBuilder);
        COMMON_SPEC = commonBuilder.build();

        ForgeConfigSpec.Builder clientBuilder = new ForgeConfigSpec.Builder();
        CLIENT = new Client(clientBuilder);
        CLIENT_SPEC = clientBuilder.build();
    }

    public static class Common {
        // Cursed Energy & Creative
        public final ForgeConfigSpec.DoubleValue baseMaxCursedEnergy;
        public final ForgeConfigSpec.DoubleValue cursedEnergyRegenPerTick;
        public final ForgeConfigSpec.BooleanValue creativeModeCooldownApplies;

        // Finger Growth & Drop
        public final ForgeConfigSpec.IntValue maxFingerCount;
        public final ForgeConfigSpec.DoubleValue perFingerMaxEnergy;
        public final ForgeConfigSpec.DoubleValue perFingerDamageBonus;
        public final ForgeConfigSpec.DoubleValue fingerBaseChance;
        public final ForgeConfigSpec.DoubleValue fingerPerLevelBonus;
        public final ForgeConfigSpec.DoubleValue fingerMaxChance;

        // Kai & Batsu
        public final ForgeConfigSpec.DoubleValue kaiDamage;
        public final ForgeConfigSpec.DoubleValue kaiCost;
        public final ForgeConfigSpec.IntValue kaiCooldown;
        public final ForgeConfigSpec.BooleanValue kaiBreakFragileBlocks;

        public final ForgeConfigSpec.DoubleValue batsuBaseDamage;
        public final ForgeConfigSpec.DoubleValue batsuMaxMultiplier;
        public final ForgeConfigSpec.DoubleValue batsuCost;
        public final ForgeConfigSpec.IntValue batsuCooldown;

        // Grid Slash
        public final ForgeConfigSpec.IntValue gridSlashSize;
        public final ForgeConfigSpec.DoubleValue gridSlashSpacing;
        public final ForgeConfigSpec.DoubleValue gridSlashDistance;
        public final ForgeConfigSpec.IntValue gridSlashHits;
        public final ForgeConfigSpec.DoubleValue gridSlashDamagePerHit;
        public final ForgeConfigSpec.IntValue gridSlashDelayTicks;
        public final ForgeConfigSpec.IntValue gridSlashCooldown;
        public final ForgeConfigSpec.DoubleValue gridSlashCursedEnergyCost;
        public final ForgeConfigSpec.DoubleValue gridSlashDomainCooldownMultiplier;
        public final ForgeConfigSpec.DoubleValue gridSlashDomainDamageMultiplier;

        // World Slash
        public final ForgeConfigSpec.DoubleValue worldSlashRange;
        public final ForgeConfigSpec.DoubleValue worldSlashAngle;
        public final ForgeConfigSpec.DoubleValue worldSlashDamage;
        public final ForgeConfigSpec.IntValue worldSlashWindupTicks;
        public final ForgeConfigSpec.IntValue worldSlashCooldown;
        public final ForgeConfigSpec.DoubleValue worldSlashCursedEnergyCost;
        public final ForgeConfigSpec.BooleanValue worldSlashIgnoreArmor;
        public final ForgeConfigSpec.BooleanValue worldSlashIgnoreInvulnerability;
        public final ForgeConfigSpec.BooleanValue worldSlashPierceBlocks;
        public final ForgeConfigSpec.BooleanValue worldSlashLivingOnly;
        public final ForgeConfigSpec.DoubleValue worldSlashDomainDamageMultiplier;

        // Domain Expansion
        public final ForgeConfigSpec.DoubleValue sukunaDomainRadius;
        public final ForgeConfigSpec.IntValue sukunaDomainDurationTicks;
        public final ForgeConfigSpec.IntValue sukunaDomainCooldownTicks;
        public final ForgeConfigSpec.DoubleValue sukunaDomainCursedEnergyCost;
        public final ForgeConfigSpec.IntValue domainTickInterval;
        public final ForgeConfigSpec.BooleanValue domainBreakBlocks;
        public final ForgeConfigSpec.DoubleValue gojoDomainRadius;
        public final ForgeConfigSpec.IntValue gojoDomainDurationTicks;
        public final ForgeConfigSpec.IntValue gojoDomainCooldownTicks;
        public final ForgeConfigSpec.DoubleValue gojoDomainCursedEnergyCost;
        public final ForgeConfigSpec.IntValue rikaDurationTicks;
        public final ForgeConfigSpec.DoubleValue pureLoveBeamDamage;
        public final ForgeConfigSpec.DoubleValue pureLoveBeamRange;

        public Common(ForgeConfigSpec.Builder b) {
            b.push("cursed_energy");
            baseMaxCursedEnergy = b.defineInRange("baseMaxCursedEnergy", 1000.0, 100.0, 100000.0);
            cursedEnergyRegenPerTick = b.defineInRange("cursedEnergyRegenPerTick", 2.5, 0.0, 500.0);
            creativeModeCooldownApplies = b.define("creativeModeCooldownApplies", true);
            b.pop();

            b.push("sukuna_finger");
            maxFingerCount = b.defineInRange("maxFingerCount", 20, 1, 100);
            perFingerMaxEnergy = b.defineInRange("perFingerMaxEnergy", 250.0, 0.0, 10000.0);
            perFingerDamageBonus = b.defineInRange("perFingerDamageBonus", 0.15, 0.0, 5.0);
            fingerBaseChance = b.defineInRange("fingerBaseChance", 0.10, 0.0, 1.0);
            fingerPerLevelBonus = b.defineInRange("fingerPerLevelBonus", 0.02, 0.0, 1.0);
            fingerMaxChance = b.defineInRange("fingerMaxChance", 0.50, 0.0, 1.0);
            b.pop();

            b.push("kai_and_batsu");
            kaiDamage = b.defineInRange("kaiDamage", 4.0, 0.5, 500.0);
            kaiCost = b.defineInRange("kaiCost", 20.0, 0.0, 5000.0);
            kaiCooldown = b.defineInRange("kaiCooldown", 15, 0, 1200);
            kaiBreakFragileBlocks = b.define("kaiBreakFragileBlocks", true);

            b.pop();
            b.push("batsu");
            batsuBaseDamage = b.defineInRange("batsuBaseDamage", 8.0, 1.0, 500.0);
            batsuMaxMultiplier = b.defineInRange("batsuMaxMultiplier", 3.5, 1.0, 20.0);
            batsuCost = b.defineInRange("batsuCost", 40.0, 0.0, 5000.0);
            batsuCooldown = b.defineInRange("batsuCooldown", 30, 0, 1200);
            b.pop();

            b.push("grid_slash");
            gridSlashSize = b.defineInRange("gridSlashSize", 5, 2, 15);
            gridSlashSpacing = b.defineInRange("gridSlashSpacing", 1.5, 0.5, 5.0);
            gridSlashDistance = b.defineInRange("gridSlashDistance", 6.0, 2.0, 24.0);
            gridSlashHits = b.defineInRange("gridSlashHits", 3, 1, 20);
            gridSlashDamagePerHit = b.defineInRange("gridSlashDamagePerHit", 7.0, 1.0, 500.0);
            gridSlashDelayTicks = b.defineInRange("gridSlashDelayTicks", 10, 1, 100);
            gridSlashCooldown = b.defineInRange("gridSlashCooldown", 100, 0, 2400);
            gridSlashCursedEnergyCost = b.defineInRange("gridSlashCursedEnergyCost", 120.0, 0.0, 10000.0);
            gridSlashDomainCooldownMultiplier = b.defineInRange("gridSlashDomainCooldownMultiplier", 0.5, 0.1, 1.0);
            gridSlashDomainDamageMultiplier = b.defineInRange("gridSlashDomainDamageMultiplier", 1.35, 1.0, 5.0);
            b.pop();

            b.push("world_slash");
            worldSlashRange = b.defineInRange("worldSlashRange", 40.0, 5.0, 150.0);
            worldSlashAngle = b.defineInRange("worldSlashAngle", 25.0, 5.0, 180.0);
            worldSlashDamage = b.defineInRange("worldSlashDamage", 45.0, 5.0, 2000.0);
            worldSlashWindupTicks = b.defineInRange("worldSlashWindupTicks", 20, 0, 100);
            worldSlashCooldown = b.defineInRange("worldSlashCooldown", 240, 0, 6000);
            worldSlashCursedEnergyCost = b.defineInRange("worldSlashCursedEnergyCost", 300.0, 0.0, 20000.0);
            worldSlashIgnoreArmor = b.define("worldSlashIgnoreArmor", true);
            worldSlashIgnoreInvulnerability = b.define("worldSlashIgnoreInvulnerability", true);
            worldSlashPierceBlocks = b.define("worldSlashPierceBlocks", true);
            worldSlashLivingOnly = b.define("worldSlashLivingOnly", true);
            worldSlashDomainDamageMultiplier = b.defineInRange("worldSlashDomainDamageMultiplier", 1.5, 1.0, 5.0);
            b.pop();

            b.push("domain_expansion");
            sukunaDomainRadius = b.defineInRange("sukunaDomainRadius", 200.0, 20.0, 300.0);
            sukunaDomainDurationTicks = b.defineInRange("sukunaDomainDurationTicks", 600, 100, 6000);
            sukunaDomainCooldownTicks = b.defineInRange("sukunaDomainCooldownTicks", 1200, 0, 12000);
            sukunaDomainCursedEnergyCost = b.defineInRange("sukunaDomainCursedEnergyCost", 500.0, 0.0, 20000.0);
            domainTickInterval = b.defineInRange("domainTickInterval", 20, 5, 100);
            domainBreakBlocks = b.define("domainBreakBlocks", true);
            gojoDomainRadius = b.defineInRange("gojoDomainRadius", 28.0, 8.0, 120.0);
            gojoDomainDurationTicks = b.defineInRange("gojoDomainDurationTicks", 400, 100, 6000);
            gojoDomainCooldownTicks = b.defineInRange("gojoDomainCooldownTicks", 1200, 0, 12000);
            gojoDomainCursedEnergyCost = b.defineInRange("gojoDomainCursedEnergyCost", 450.0, 0.0, 20000.0);
            rikaDurationTicks = b.defineInRange("rikaDurationTicks", 6000, 200, 24000);
            pureLoveBeamDamage = b.defineInRange("pureLoveBeamDamage", 36.0, 5.0, 1000.0);
            pureLoveBeamRange = b.defineInRange("pureLoveBeamRange", 35.0, 5.0, 120.0);
            b.pop();
        }
    }

    public static class Client {
        public final ForgeConfigSpec.BooleanValue enableDomainBgm;
        public final ForgeConfigSpec.DoubleValue domainBgmVolume;
        public final ForgeConfigSpec.IntValue domainParticleLodDensity;

        public Client(ForgeConfigSpec.Builder b) {
            b.push("audio_and_visuals");
            enableDomainBgm = b.define("enableDomainBgm", true);
            domainBgmVolume = b.defineInRange("domainBgmVolume", 0.75, 0.0, 1.0);
            domainParticleLodDensity = b.defineInRange("domainParticleLodDensity", 128, 16, 512);
            b.pop();
        }
    }
}
