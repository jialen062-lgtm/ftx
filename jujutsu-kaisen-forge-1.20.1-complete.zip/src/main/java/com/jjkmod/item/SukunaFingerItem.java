package com.jjkmod.item;

import com.jjkmod.config.ModConfig;
import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.SyncCursedDataS2CPacket;
import com.jjkmod.registry.CharacterRegistry;
import com.jjkmod.registry.ModCapabilities;
import com.jjkmod.registry.ModSounds;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class SukunaFingerItem extends Item {
    public SukunaFingerItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            int maxFingers = ModConfig.COMMON.maxFingerCount.get();
            serverPlayer.getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(data -> {
                if (data.getFingerCount() >= maxFingers) {
                    serverPlayer.displayClientMessage(
                            Component.translatable("message.jjkmod.finger_max_reached", maxFingers), true);
                    return;
                }
                int nextCount = data.getFingerCount() + 1;
                data.setFingerCount(nextCount);
                if (nextCount == 1) {
                    CharacterRegistry.get(CharacterRegistry.SUKUNA)
                            .ifPresent(def -> def.baseTechniques().forEach(data::unlockTechnique));
                    serverPlayer.displayClientMessage(
                            Component.translatable("message.jjkmod.sukuna_awakened"), false);
                }
                data.setCursedEnergy(data.getMaxCursedEnergy());
                if (!serverPlayer.isCreative()) {
                    stack.shrink(1);
                }
                level.playSound(null, serverPlayer.blockPosition(), ModSounds.FINGER_EAT.get(),
                        SoundSource.PLAYERS, 1.0f, 1.0f);
                serverPlayer.displayClientMessage(
                        Component.translatable("message.jjkmod.finger_consumed", nextCount, maxFingers), true);
                ModNetwork.sendToPlayer(new SyncCursedDataS2CPacket(data), serverPlayer);
            });
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
