package com.jjkmod.item;

import com.jjkmod.domain.DomainManager;
import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.DomainBgmS2CPacket;
import com.jjkmod.network.packet.OpenCharacterScreenS2CPacket;
import com.jjkmod.network.packet.SyncCursedDataS2CPacket;
import com.jjkmod.registry.CharacterRegistry;
import com.jjkmod.registry.ModCapabilities;
import com.jjkmod.registry.ModSounds;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class CharacterSwitchBookItem extends Item {
    public CharacterSwitchBookItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            if (serverPlayer.isShiftKeyDown()) {
                serverPlayer.getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(data -> {
                    ResourceLocation next = CharacterRegistry.getNextCharacter(data.getCurrentCharacter());
                    switchCharacter(serverPlayer, next);
                });
            } else {
                ModNetwork.sendToPlayer(new OpenCharacterScreenS2CPacket(), serverPlayer);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    public static void switchCharacter(ServerPlayer player, ResourceLocation targetCharacter) {
        if (CharacterRegistry.get(targetCharacter).isEmpty()) return;

        // Stop active domain and clean up domain entities + BGM
        DomainManager.dismissPlayerDomain(player);
        ModNetwork.sendToPlayer(new DomainBgmS2CPacket(false, null, null), player);

        player.getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(data -> {
            data.setCurrentCharacter(targetCharacter);
            // Preserves fingerCount and finger bonuses; refreshes unlocked techniques
            data.recalculateFingerBonuses();
            data.refreshUnlockedTechniquesForCharacter(targetCharacter);

            player.level().playSound(null, player.blockPosition(), ModSounds.CHARACTER_SWITCH.get(),
                    SoundSource.PLAYERS, 1.0f, 1.0f);

            String nameKey = CharacterRegistry.get(targetCharacter)
                    .map(CharacterRegistry.CharacterDefinition::displayNameKey)
                    .orElse("character.jjkmod.sukuna");
            player.displayClientMessage(
                    Component.translatable("message.jjkmod.character_switched", Component.translatable(nameKey)), true);

            ModNetwork.sendToPlayer(new SyncCursedDataS2CPacket(data), player);
        });
    }
}
