package com.jjkmod.network;

import com.jjkmod.JJKMod;
import com.jjkmod.network.packet.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOL_VERSION = "1";
    public static SimpleChannel CHANNEL;
    private static int packetId = 0;

    private static int id() { return packetId++; }

    public static void register() {
        CHANNEL = NetworkRegistry.ChannelBuilder
                .named(new ResourceLocation(JJKMod.MODID, "main"))
                .networkProtocolVersion(() -> PROTOCOL_VERSION)
                .clientAcceptedVersions(PROTOCOL_VERSION::equals)
                .serverAcceptedVersions(PROTOCOL_VERSION::equals)
                .simpleChannel();

        CHANNEL.messageBuilder(SyncCursedDataS2CPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncCursedDataS2CPacket::encode)
                .decoder(SyncCursedDataS2CPacket::new)
                .consumerMainThread(SyncCursedDataS2CPacket::handle)
                .add();

        CHANNEL.messageBuilder(CastTechniqueC2SPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .encoder(CastTechniqueC2SPacket::encode)
                .decoder(CastTechniqueC2SPacket::new)
                .consumerMainThread(CastTechniqueC2SPacket::handle)
                .add();

        CHANNEL.messageBuilder(ExpandDomainC2SPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .encoder(ExpandDomainC2SPacket::encode)
                .decoder(ExpandDomainC2SPacket::new)
                .consumerMainThread(ExpandDomainC2SPacket::handle)
                .add();

        CHANNEL.messageBuilder(SwitchCharacterC2SPacket.class, id(), NetworkDirection.PLAY_TO_SERVER)
                .encoder(SwitchCharacterC2SPacket::encode)
                .decoder(SwitchCharacterC2SPacket::new)
                .consumerMainThread(SwitchCharacterC2SPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenCharacterScreenS2CPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenCharacterScreenS2CPacket::encode)
                .decoder(OpenCharacterScreenS2CPacket::new)
                .consumerMainThread(OpenCharacterScreenS2CPacket::handle)
                .add();

        CHANNEL.messageBuilder(GridSlashVisualS2CPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .encoder(GridSlashVisualS2CPacket::encode)
                .decoder(GridSlashVisualS2CPacket::new)
                .consumerMainThread(GridSlashVisualS2CPacket::handle)
                .add();

        CHANNEL.messageBuilder(WorldSlashVisualS2CPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .encoder(WorldSlashVisualS2CPacket::encode)
                .decoder(WorldSlashVisualS2CPacket::new)
                .consumerMainThread(WorldSlashVisualS2CPacket::handle)
                .add();

        CHANNEL.messageBuilder(DomainBgmS2CPacket.class, id(), NetworkDirection.PLAY_TO_CLIENT)
                .encoder(DomainBgmS2CPacket::encode)
                .decoder(DomainBgmS2CPacket::new)
                .consumerMainThread(DomainBgmS2CPacket::handle)
                .add();
    }

    public static <MSG> void sendToServer(MSG msg) {
        CHANNEL.sendToServer(msg);
    }

    public static <MSG> void sendToPlayer(MSG msg, ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
    }

    public static <MSG> void sendToTrackingAndSelf(MSG msg, ServerPlayer player) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player), msg);
    }
}
