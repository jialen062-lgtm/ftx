package com.jjkmod.network.packet;

import com.jjkmod.client.sound.DomainBgmManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class DomainBgmS2CPacket {
    private final boolean start;
    private final ResourceLocation openSound;
    private final ResourceLocation loopSound;

    public DomainBgmS2CPacket(boolean start, ResourceLocation openSound, ResourceLocation loopSound) {
        this.start = start;
        this.openSound = openSound;
        this.loopSound = loopSound;
    }

    public DomainBgmS2CPacket(FriendlyByteBuf buf) {
        this.start = buf.readBoolean();
        this.openSound = buf.readBoolean() ? buf.readResourceLocation() : null;
        this.loopSound = buf.readBoolean() ? buf.readResourceLocation() : null;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(start);
        buf.writeBoolean(openSound != null);
        if (openSound != null) buf.writeResourceLocation(openSound);
        buf.writeBoolean(loopSound != null);
        if (loopSound != null) buf.writeResourceLocation(loopSound);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
                    if (start) DomainBgmManager.playDomainBgm(openSound, loopSound);
                    else DomainBgmManager.stopDomainBgm();
                })
        );
        ctx.get().setPacketHandled(true);
    }
}
