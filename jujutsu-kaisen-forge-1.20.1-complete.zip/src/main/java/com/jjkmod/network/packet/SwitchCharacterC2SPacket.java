package com.jjkmod.network.packet;

import com.jjkmod.item.CharacterSwitchBookItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SwitchCharacterC2SPacket {
    private final ResourceLocation characterId;

    public SwitchCharacterC2SPacket(ResourceLocation characterId) {
        this.characterId = characterId;
    }

    public SwitchCharacterC2SPacket(FriendlyByteBuf buf) {
        this.characterId = buf.readResourceLocation();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeResourceLocation(characterId);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                CharacterSwitchBookItem.switchCharacter(player, characterId);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
