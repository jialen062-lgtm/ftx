package com.jjkmod.network.packet;

import com.jjkmod.domain.DomainManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ExpandDomainC2SPacket {
    public ExpandDomainC2SPacket() {}
    public ExpandDomainC2SPacket(FriendlyByteBuf buf) {}
    public void encode(FriendlyByteBuf buf) {}

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                DomainManager.tryExpandPlayerDomain(player);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
