package com.jjkmod.network.packet;

import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.client.ClientCursedDataCache;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SyncCursedDataS2CPacket {
    private final CompoundTag tag;

    public SyncCursedDataS2CPacket(PlayerCursedData data) {
        this.tag = data.saveNBT();
    }

    public SyncCursedDataS2CPacket(FriendlyByteBuf buf) {
        this.tag = buf.readNbt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeNbt(tag);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientCursedDataCache.updateFromNbt(tag));
        ctx.get().setPacketHandled(true);
    }
}
