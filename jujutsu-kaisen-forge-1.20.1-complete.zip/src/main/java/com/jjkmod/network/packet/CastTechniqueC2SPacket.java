package com.jjkmod.network.packet;

import com.jjkmod.technique.TechniqueManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class CastTechniqueC2SPacket {
    private final ResourceLocation techniqueId;

    public CastTechniqueC2SPacket(ResourceLocation techniqueId) {
        this.techniqueId = techniqueId;
    }

    public CastTechniqueC2SPacket(FriendlyByteBuf buf) {
        this.techniqueId = buf.readResourceLocation();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeResourceLocation(techniqueId);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                TechniqueManager.tryCastTechnique(player, techniqueId);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
