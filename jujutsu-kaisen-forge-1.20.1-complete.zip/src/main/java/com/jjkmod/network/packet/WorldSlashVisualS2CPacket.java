package com.jjkmod.network.packet;

import com.jjkmod.client.renderer.ClientDomainRenderer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class WorldSlashVisualS2CPacket {
    private final Vec3 start;
    private final Vec3 dir;
    private final double range;

    public WorldSlashVisualS2CPacket(Vec3 start, Vec3 dir, double range) {
        this.start = start;
        this.dir = dir;
        this.range = range;
    }

    public WorldSlashVisualS2CPacket(FriendlyByteBuf buf) {
        this.start = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        this.dir = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        this.range = buf.readDouble();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeDouble(start.x);
        buf.writeDouble(start.y);
        buf.writeDouble(start.z);
        buf.writeDouble(dir.x);
        buf.writeDouble(dir.y);
        buf.writeDouble(dir.z);
        buf.writeDouble(range);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () ->
                        () -> ClientDomainRenderer.spawnWorldRiftParticles(start, dir, range))
        );
        ctx.get().setPacketHandled(true);
    }
}
