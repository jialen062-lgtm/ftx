package com.jjkmod.network.packet;

import com.jjkmod.client.gui.CharacterSelectScreen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class OpenCharacterScreenS2CPacket {
    public OpenCharacterScreenS2CPacket() {}
    public OpenCharacterScreenS2CPacket(FriendlyByteBuf buf) {}
    public void encode(FriendlyByteBuf buf) {}

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> CharacterSelectScreen::open)
        );
        ctx.get().setPacketHandled(true);
    }
}
