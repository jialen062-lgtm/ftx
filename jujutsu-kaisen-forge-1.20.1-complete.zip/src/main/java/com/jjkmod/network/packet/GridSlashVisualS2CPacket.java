package com.jjkmod.network.packet;

import com.jjkmod.client.renderer.ClientDomainRenderer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class GridSlashVisualS2CPacket {
    private final Vec3 center;
    private final Vec3 forward;
    private final int size;
    private final double spacing;

    public GridSlashVisualS2CPacket(Vec3 center, Vec3 forward, int size, double spacing) {
        this.center = center;
        this.forward = forward;
        this.size = size;
        this.spacing = spacing;
    }

    public GridSlashVisualS2CPacket(FriendlyByteBuf buf) {
        this.center = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        this.forward = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        this.size = buf.readInt();
        this.spacing = buf.readDouble();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeDouble(center.x);
        buf.writeDouble(center.y);
        buf.writeDouble(center.z);
        buf.writeDouble(forward.x);
        buf.writeDouble(forward.y);
        buf.writeDouble(forward.z);
        buf.writeInt(size);
        buf.writeDouble(spacing);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () ->
                        () -> ClientDomainRenderer.spawnGridSlashParticles(center, forward, size, spacing))
        );
        ctx.get().setPacketHandled(true);
    }
}
