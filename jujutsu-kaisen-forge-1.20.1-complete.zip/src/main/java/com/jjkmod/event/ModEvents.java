package com.jjkmod.event;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.capability.PlayerCursedDataProvider;
import com.jjkmod.config.ModConfig;
import com.jjkmod.domain.DomainManager;
import com.jjkmod.entity.CursedSpiritEntity;
import com.jjkmod.entity.RikaEntity;
import com.jjkmod.entity.SukunaEntity;
import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.SyncCursedDataS2CPacket;
import com.jjkmod.registry.ModCapabilities;
import com.jjkmod.registry.ModEntities;
import com.jjkmod.registry.ModItems;
import com.jjkmod.technique.TechniqueManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class ModEvents {

    @Mod.EventBusSubscriber(modid = JJKMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBusEvents {
        @SubscribeEvent
        public static void registerAttributes(EntityAttributeCreationEvent event) {
            event.put(ModEntities.CURSED_SPIRIT.get(), CursedSpiritEntity.createAttributes().build());
            event.put(ModEntities.SUKUNA_BOSS.get(), SukunaEntity.createAttributes().build());
            event.put(ModEntities.RIKA.get(), RikaEntity.createAttributes().build());
        }

        @SubscribeEvent
        public static void registerCaps(RegisterCapabilitiesEvent event) {
            event.register(PlayerCursedData.class);
        }
    }

    @Mod.EventBusSubscriber(modid = JJKMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeBusEvents {
        @SubscribeEvent
        public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
            if (event.getObject() instanceof Player) {
                if (!event.getObject().getCapability(ModCapabilities.PLAYER_CURSED_DATA).isPresent()) {
                    event.addCapability(new ResourceLocation(JJKMod.MODID, "cursed_data"), new PlayerCursedDataProvider());
                }
            }
        }

        @SubscribeEvent
        public static void onPlayerClone(PlayerEvent.Clone event) {
            event.getOriginal().reviveCaps();
            event.getOriginal().getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(oldData ->
                    event.getEntity().getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(newData ->
                            newData.copyFrom(oldData)));
            event.getOriginal().invalidateCaps();
        }

        @SubscribeEvent
        public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
            if (event.getEntity() instanceof ServerPlayer sp) {
                sp.getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(data -> {
                    data.recalculateFingerBonuses();
                    ModNetwork.sendToPlayer(new SyncCursedDataS2CPacket(data), sp);
                });
            }
        }

        @SubscribeEvent
        public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
            if (event.getEntity() instanceof ServerPlayer sp) {
                sp.getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(data ->
                        ModNetwork.sendToPlayer(new SyncCursedDataS2CPacket(data), sp));
            }
        }

        @SubscribeEvent
        public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
            if (event.getEntity() instanceof ServerPlayer sp) {
                DomainManager.dismissPlayerDomain(sp);
                TechniqueManager.setWindingUp(sp.getUUID(), false);
            }
        }

        @SubscribeEvent
        public static void onServerTick(TickEvent.ServerTickEvent event) {
            if (event.phase == TickEvent.Phase.END) {
                TechniqueManager.tick();
            }
        }

        @SubscribeEvent
        public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
            if (event.phase == TickEvent.Phase.END && event.player instanceof ServerPlayer sp) {
                sp.getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(data -> {
                    data.tickCooldowns();
                    double regen = ModConfig.COMMON.cursedEnergyRegenPerTick.get();
                    if (data.getCursedEnergy() < data.getMaxCursedEnergy()) {
                        data.setCursedEnergy(data.getCursedEnergy() + regen);
                    }
                    if (sp.tickCount % 10 == 0) {
                        ModNetwork.sendToPlayer(new SyncCursedDataS2CPacket(data), sp);
                    }
                });
            }
        }

        @SubscribeEvent
        public static void onLivingDeath(LivingDeathEvent event) {
            if (!event.getEntity().level().isClientSide && event.getEntity() instanceof CursedSpiritEntity spirit) {
                if (event.getSource().getEntity() instanceof Player) {
                    double base = ModConfig.COMMON.fingerBaseChance.get();
                    double perLvl = ModConfig.COMMON.fingerPerLevelBonus.get();
                    double max = ModConfig.COMMON.fingerMaxChance.get();
                    double chance = Math.min(max, base + spirit.getSpiritLevel() * perLvl);

                    if (spirit.getRandom().nextDouble() < chance) {
                        ItemEntity drop = new ItemEntity(spirit.level(), spirit.getX(), spirit.getY() + 0.5, spirit.getZ(),
                                new ItemStack(ModItems.SUKUNA_FINGER.get()));
                        spirit.level().addFreshEntity(drop);
                    }
                }
            }
        }
    }
}
