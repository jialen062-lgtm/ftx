package com.jjkmod.registry;

import com.jjkmod.domain.IDomainDefinition;
import com.jjkmod.domain.impl.*;
import net.minecraft.resources.ResourceLocation;

import java.util.*;

public class DomainRegistry {
    private static final Map<ResourceLocation, IDomainDefinition> REGISTRY = new LinkedHashMap<>();

    public static void init() {
        REGISTRY.clear();
        register(new MalevolentShrineDomain());
        register(new UnlimitedVoidDomain());
        register(new ChimeraShadowGardenDomain());
        register(new AuthenticMutualLoveDomain());
    }

    public static void register(IDomainDefinition domain) {
        REGISTRY.put(domain.getId(), domain);
    }

    public static Optional<IDomainDefinition> get(ResourceLocation id) {
        return Optional.ofNullable(REGISTRY.get(id));
    }

    public static Collection<IDomainDefinition> getAll() {
        return Collections.unmodifiableCollection(REGISTRY.values());
    }
}
