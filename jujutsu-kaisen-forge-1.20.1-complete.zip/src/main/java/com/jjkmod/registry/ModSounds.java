package com.jjkmod.registry;

import com.jjkmod.JJKMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, JJKMod.MODID);

    public static final RegistryObject<SoundEvent> DOMAIN_SUKUNA_OPEN = register("domain_sukuna_open");
    public static final RegistryObject<SoundEvent> DOMAIN_SUKUNA_LOOP = register("domain_sukuna_loop");
    public static final RegistryObject<SoundEvent> DOMAIN_GOJO_OPEN = register("domain_gojo_open");
    public static final RegistryObject<SoundEvent> DOMAIN_GOJO_LOOP = register("domain_gojo_loop");
    public static final RegistryObject<SoundEvent> DOMAIN_YUTA_OPEN = register("domain_yuta_open");
    public static final RegistryObject<SoundEvent> DOMAIN_YUTA_LOOP = register("domain_yuta_loop");
    public static final RegistryObject<SoundEvent> PURE_LOVE_BEAM = register("pure_love_beam");
    public static final RegistryObject<SoundEvent> SLASH_KAI = register("slash_kai");
    public static final RegistryObject<SoundEvent> SLASH_BATSU = register("slash_batsu");
    public static final RegistryObject<SoundEvent> SLASH_GRID = register("slash_grid");
    public static final RegistryObject<SoundEvent> SLASH_WORLD = register("slash_world");
    public static final RegistryObject<SoundEvent> FINGER_EAT = register("finger_eat");
    public static final RegistryObject<SoundEvent> CHARACTER_SWITCH = register("character_switch");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(JJKMod.MODID, name)));
    }
}
