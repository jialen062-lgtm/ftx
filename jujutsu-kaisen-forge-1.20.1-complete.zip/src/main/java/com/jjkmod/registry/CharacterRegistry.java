package com.jjkmod.registry;

import com.jjkmod.JJKMod;
import net.minecraft.resources.ResourceLocation;

import java.util.*;

public class CharacterRegistry {
    public static final ResourceLocation SUKUNA = new ResourceLocation(JJKMod.MODID, "sukuna");
    public static final ResourceLocation GOJO = new ResourceLocation(JJKMod.MODID, "gojo");
    public static final ResourceLocation MEGUMI = new ResourceLocation(JJKMod.MODID, "megumi");
    public static final ResourceLocation YUTA = new ResourceLocation(JJKMod.MODID, "yuta");

    private static final Map<ResourceLocation, CharacterDefinition> REGISTRY = new LinkedHashMap<>();

    public record CharacterDefinition(
            ResourceLocation id,
            String displayNameKey,
            ResourceLocation modelLocation,
            ResourceLocation textureLocation,
            ResourceLocation animationLocation,
            List<ResourceLocation> baseTechniques,
            ResourceLocation domainId,
            ResourceLocation domainOpenSound,
            ResourceLocation domainLoopSound,
            ResourceLocation hudIcon
    ) {}

    public static void init() {
        REGISTRY.clear();
        register(new CharacterDefinition(
                SUKUNA,
                "character.jjkmod.sukuna",
                new ResourceLocation(JJKMod.MODID, "geo/sukuna.geo.json"),
                new ResourceLocation(JJKMod.MODID, "textures/entity/sukuna.png"),
                new ResourceLocation(JJKMod.MODID, "animations/sukuna.animation.json"),
                List.of(
                        new ResourceLocation(JJKMod.MODID, "kai"),
                        new ResourceLocation(JJKMod.MODID, "batsu"),
                        new ResourceLocation(JJKMod.MODID, "grid_slash"),
                        new ResourceLocation(JJKMod.MODID, "world_slash")
                ),
                new ResourceLocation(JJKMod.MODID, "malevolent_shrine"),
                ModSounds.DOMAIN_SUKUNA_OPEN.getId(),
                ModSounds.DOMAIN_SUKUNA_LOOP.getId(),
                new ResourceLocation(JJKMod.MODID, "textures/gui/hud_sukuna.png")
        ));

        register(new CharacterDefinition(
                GOJO,
                "character.jjkmod.gojo",
                new ResourceLocation(JJKMod.MODID, "geo/gojo.geo.json"),
                new ResourceLocation(JJKMod.MODID, "textures/entity/gojo.png"),
                new ResourceLocation(JJKMod.MODID, "animations/gojo.animation.json"),
                List.of(new ResourceLocation(JJKMod.MODID, "unlimited_void_pulse")),
                new ResourceLocation(JJKMod.MODID, "unlimited_void"),
                ModSounds.DOMAIN_GOJO_OPEN.getId(),
                ModSounds.DOMAIN_GOJO_LOOP.getId(),
                new ResourceLocation(JJKMod.MODID, "textures/gui/hud_gojo.png")
        ));

        register(new CharacterDefinition(
                MEGUMI,
                "character.jjkmod.megumi",
                new ResourceLocation(JJKMod.MODID, "geo/megumi.geo.json"),
                new ResourceLocation(JJKMod.MODID, "textures/entity/megumi.png"),
                new ResourceLocation(JJKMod.MODID, "animations/megumi.animation.json"),
                List.of(new ResourceLocation(JJKMod.MODID, "chimera_shadow_summon")),
                new ResourceLocation(JJKMod.MODID, "chimera_shadow_garden"),
                ModSounds.DOMAIN_SUKUNA_OPEN.getId(),
                ModSounds.DOMAIN_SUKUNA_LOOP.getId(),
                new ResourceLocation(JJKMod.MODID, "textures/gui/hud_megumi.png")
        ));

        register(new CharacterDefinition(
                YUTA,
                "character.jjkmod.yuta",
                new ResourceLocation(JJKMod.MODID, "geo/yuta.geo.json"),
                new ResourceLocation(JJKMod.MODID, "textures/entity/yuta.png"),
                new ResourceLocation(JJKMod.MODID, "animations/yuta.animation.json"),
                List.of(
                        new ResourceLocation(JJKMod.MODID, "rika_manifest"),
                        new ResourceLocation(JJKMod.MODID, "cursed_speech"),
                        new ResourceLocation(JJKMod.MODID, "true_mutual_love_blade"),
                        new ResourceLocation(JJKMod.MODID, "pure_love_beam")
                ),
                new ResourceLocation(JJKMod.MODID, "authentic_mutual_love"),
                ModSounds.DOMAIN_YUTA_OPEN.getId(),
                ModSounds.DOMAIN_YUTA_LOOP.getId(),
                new ResourceLocation(JJKMod.MODID, "textures/gui/hud_yuta.png")
        ));
    }

    public static void register(CharacterDefinition def) {
        REGISTRY.put(def.id(), def);
    }

    public static Optional<CharacterDefinition> get(ResourceLocation id) {
        return Optional.ofNullable(REGISTRY.get(id));
    }

    public static List<CharacterDefinition> getAll() {
        return List.copyOf(REGISTRY.values());
    }

    public static ResourceLocation getNextCharacter(ResourceLocation current) {
        List<ResourceLocation> keys = new ArrayList<>(REGISTRY.keySet());
        if (keys.isEmpty()) return SUKUNA;
        int idx = keys.indexOf(current);
        return keys.get((idx + 1) % keys.size());
    }
}
