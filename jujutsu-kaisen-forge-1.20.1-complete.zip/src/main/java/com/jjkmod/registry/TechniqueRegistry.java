package com.jjkmod.registry;

import com.jjkmod.technique.ITechnique;
import com.jjkmod.technique.impl.*;
import net.minecraft.resources.ResourceLocation;

import java.util.*;

public class TechniqueRegistry {
    private static final Map<ResourceLocation, ITechnique> REGISTRY = new LinkedHashMap<>();

    public static void init() {
        REGISTRY.clear();
        register(new KaiTechnique());
        register(new BatsuTechnique());
        register(new GridSlashTechnique());
        register(new WorldSlashTechnique());
        register(new GojoUnlimitedVoidPulseTechnique());
        register(new MegumiShadowSummonTechnique());
        register(new RikaManifestTechnique());
        register(new CursedSpeechTechnique());
        register(new YutaCopyBladeTechnique());
        register(new PureLoveBeamTechnique());
    }

    public static void register(ITechnique technique) {
        REGISTRY.put(technique.getId(), technique);
    }

    public static Optional<ITechnique> get(ResourceLocation id) {
        return Optional.ofNullable(REGISTRY.get(id));
    }

    public static Collection<ITechnique> getAll() {
        return Collections.unmodifiableCollection(REGISTRY.values());
    }
}
