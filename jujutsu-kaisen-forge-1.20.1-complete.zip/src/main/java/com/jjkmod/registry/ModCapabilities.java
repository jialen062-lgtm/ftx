package com.jjkmod.registry;

import com.jjkmod.capability.PlayerCursedData;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

public class ModCapabilities {
    public static final Capability<PlayerCursedData> PLAYER_CURSED_DATA =
            CapabilityManager.get(new CapabilityToken<>() {});
}
