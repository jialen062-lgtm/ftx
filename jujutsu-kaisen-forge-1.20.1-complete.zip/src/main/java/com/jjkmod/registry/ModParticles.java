package com.jjkmod.registry;

import com.jjkmod.JJKMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, JJKMod.MODID);

    public static final RegistryObject<SimpleParticleType> GRID_SLASH_LINE =
            PARTICLES.register("grid_slash_line", () -> new SimpleParticleType(true));
    public static final RegistryObject<SimpleParticleType> WORLD_RIFT_LINE =
            PARTICLES.register("world_rift_line", () -> new SimpleParticleType(true));
    public static final RegistryObject<SimpleParticleType> DOMAIN_SLASH_SPARK =
            PARTICLES.register("domain_slash_spark", () -> new SimpleParticleType(true));
}
