package com.jjkmod.registry;

import com.jjkmod.JJKMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JJKMod.MODID);

    public static final RegistryObject<CreativeModeTab> JJK_TAB = CREATIVE_TABS.register("jjk_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.jjkmod"))
                    .icon(() -> new ItemStack(ModItems.SUKUNA_FINGER.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.SUKUNA_FINGER.get());
                        output.accept(ModItems.CHARACTER_SWITCH_BOOK.get());
                        output.accept(ModItems.SUKUNA_SPAWN_EGG.get());
                        output.accept(ModItems.CURSED_SPIRIT_SPAWN_EGG.get());
                        output.accept(ModItems.RIKA_SPAWN_EGG.get());
                    })
                    .build());
}
