package com.jjkmod.registry;

import com.jjkmod.JJKMod;
import com.jjkmod.item.CharacterSwitchBookItem;
import com.jjkmod.item.SukunaFingerItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, JJKMod.MODID);

    public static final RegistryObject<Item> SUKUNA_FINGER =
            ITEMS.register("sukuna_finger", () -> new SukunaFingerItem(new Item.Properties().stacksTo(20)));

    public static final RegistryObject<Item> CHARACTER_SWITCH_BOOK =
            ITEMS.register("character_switch_book", () -> new CharacterSwitchBookItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> SUKUNA_SPAWN_EGG =
            ITEMS.register("sukuna_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.SUKUNA_BOSS, 0x3D0C11, 0xD80032, new Item.Properties()));

    public static final RegistryObject<Item> RIKA_SPAWN_EGG =
            ITEMS.register("rika_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.RIKA, 0x1D132B, 0xE845B5, new Item.Properties()));

    public static final RegistryObject<Item> CURSED_SPIRIT_SPAWN_EGG =
            ITEMS.register("cursed_spirit_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.CURSED_SPIRIT, 0x1A1A2E, 0x7B2CBF, new Item.Properties()));
}
