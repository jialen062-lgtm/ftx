package com.jjkmod.registry;

import com.jjkmod.JJKMod;
import com.jjkmod.entity.CursedSpiritEntity;
import com.jjkmod.entity.DomainEntity;
import com.jjkmod.entity.RikaEntity;
import com.jjkmod.entity.SukunaEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, JJKMod.MODID);

    public static final RegistryObject<EntityType<CursedSpiritEntity>> CURSED_SPIRIT =
            ENTITIES.register("cursed_spirit", () -> EntityType.Builder.of(CursedSpiritEntity::new, MobCategory.MONSTER)
                    .sized(0.75f, 1.95f)
                    .clientTrackingRange(8)
                    .build("cursed_spirit"));

    public static final RegistryObject<EntityType<SukunaEntity>> SUKUNA_BOSS =
            ENTITIES.register("sukuna_boss", () -> EntityType.Builder.of(SukunaEntity::new, MobCategory.MONSTER)
                    .sized(0.8f, 2.1f)
                    .fireImmune()
                    .clientTrackingRange(10)
                    .build("sukuna_boss"));

    public static final RegistryObject<EntityType<RikaEntity>> RIKA =
            ENTITIES.register("rika", () -> EntityType.Builder.of(RikaEntity::new, MobCategory.CREATURE)
                    .sized(1.4f, 3.0f).clientTrackingRange(10).build("rika"));

    public static final RegistryObject<EntityType<DomainEntity>> DOMAIN_ENTITY =
            ENTITIES.register("domain_entity", () -> EntityType.Builder.<DomainEntity>of(DomainEntity::new, MobCategory.MISC)
                    .sized(1.0f, 1.0f)
                    .noSummon()
                    .fireImmune()
                    .clientTrackingRange(32)
                    .updateInterval(5)
                    .build("domain_entity"));
}
