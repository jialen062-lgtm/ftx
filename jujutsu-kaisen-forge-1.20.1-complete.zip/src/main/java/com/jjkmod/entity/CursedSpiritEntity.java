package com.jjkmod.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import org.jetbrains.annotations.Nullable;

public class CursedSpiritEntity extends Monster {
    private static final EntityDataAccessor<Integer> DATA_LEVEL =
            SynchedEntityData.defineId(CursedSpiritEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_RARITY =
            SynchedEntityData.defineId(CursedSpiritEntity.class, EntityDataSerializers.INT);

    public CursedSpiritEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.MOVEMENT_SPEED, 0.30)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_LEVEL, 1);
        this.entityData.define(DATA_RARITY, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public int getSpiritLevel() { return this.entityData.get(DATA_LEVEL); }
    public void setSpiritLevel(int lvl) { this.entityData.set(DATA_LEVEL, Math.max(1, Math.min(20, lvl))); }

    public CursedRarity getRarity() { return CursedRarity.fromOrdinal(this.entityData.get(DATA_RARITY)); }
    public void setRarity(CursedRarity rarity) { this.entityData.set(DATA_RARITY, rarity.ordinal()); }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable CompoundTag tag) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, reason, spawnData, tag);
        int roll = this.random.nextInt(100);
        CursedRarity rarity;
        if (roll < 45) rarity = CursedRarity.GRADE_4;
        else if (roll < 75) rarity = CursedRarity.GRADE_3;
        else if (roll < 90) rarity = CursedRarity.GRADE_2;
        else if (roll < 97) rarity = CursedRarity.GRADE_1;
        else rarity = CursedRarity.SPECIAL_GRADE;

        int lvl = rarity.minLevel + this.random.nextInt(rarity.maxLevel - rarity.minLevel + 1);
        setRarity(rarity);
        setSpiritLevel(lvl);
        if (this.getAttribute(Attributes.MAX_HEALTH) != null) {
            double hp = 30.0 + lvl * 6.0;
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(hp);
            this.setHealth((float) hp);
        }
        return data;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("SpiritLevel", getSpiritLevel());
        tag.putInt("SpiritRarity", getRarity().ordinal());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("SpiritLevel")) setSpiritLevel(tag.getInt("SpiritLevel"));
        if (tag.contains("SpiritRarity")) setRarity(CursedRarity.fromOrdinal(tag.getInt("SpiritRarity")));
    }
}
