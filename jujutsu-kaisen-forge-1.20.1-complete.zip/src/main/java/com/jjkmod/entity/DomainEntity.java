package com.jjkmod.entity;

import com.jjkmod.JJKMod;
import com.jjkmod.config.ModConfig;
import com.jjkmod.domain.DomainManager;
import com.jjkmod.domain.IDomainDefinition;
import com.jjkmod.registry.DomainRegistry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

import java.util.Optional;
import java.util.UUID;

public class DomainEntity extends Entity {
    private static final EntityDataAccessor<String> DATA_DOMAIN_ID =
            SynchedEntityData.defineId(DomainEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Float> DATA_RADIUS =
            SynchedEntityData.defineId(DomainEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> DATA_AGE =
            SynchedEntityData.defineId(DomainEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_DURATION =
            SynchedEntityData.defineId(DomainEntity.class, EntityDataSerializers.INT);

    private UUID ownerUuid;
    private double barrierIntegrity = 100.0;

    public DomainEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_DOMAIN_ID, new ResourceLocation(JJKMod.MODID, "malevolent_shrine").toString());
        this.entityData.define(DATA_RADIUS, 200.0f);
        this.entityData.define(DATA_AGE, 0);
        this.entityData.define(DATA_DURATION, 600);
    }

    public void configure(UUID ownerUuid, ResourceLocation domainId, float radius, int durationTicks) {
        this.ownerUuid = ownerUuid;
        this.entityData.set(DATA_DOMAIN_ID, domainId.toString());
        this.entityData.set(DATA_RADIUS, radius);
        this.entityData.set(DATA_DURATION, durationTicks);
    }

    public UUID getOwnerUuid() { return ownerUuid; }

    @javax.annotation.Nullable
    public LivingEntity getOwnerEntity(ServerLevel level) {
        if (ownerUuid == null) return null;
        Entity e = level.getEntity(ownerUuid);
        return e instanceof LivingEntity le ? le : null;
    }

    public ResourceLocation getDomainId() { return new ResourceLocation(this.entityData.get(DATA_DOMAIN_ID)); }
    public float getRadius() { return this.entityData.get(DATA_RADIUS); }
    public int getAgeTicks() { return this.entityData.get(DATA_AGE); }
    public int getDurationTicks() { return this.entityData.get(DATA_DURATION); }
    public double getBarrierIntegrity() { return barrierIntegrity; }

    /**
     * External domain clash / erosion interface.
     * Other domains can call this when overlapping to erode this domain's stability.
     */
    public void erodeByExternalDomain(DomainEntity other, double strength) {
        this.barrierIntegrity -= strength;
        if (this.barrierIntegrity <= 0.0 && !this.level().isClientSide) {
            this.discard();
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.level() instanceof ServerLevel serverLevel) {
            int age = getAgeTicks() + 1;
            this.entityData.set(DATA_AGE, age);

            if (age >= getDurationTicks()) {
                DomainManager.onDomainExpired(this, serverLevel);
                this.discard();
                return;
            }

            int interval = Math.max(1, ModConfig.COMMON.domainTickInterval.get());
            if (age % interval == 0) {
                Optional<IDomainDefinition> def = DomainRegistry.get(getDomainId());
                def.ifPresent(d -> d.onDomainTick(this, serverLevel));
            }
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.hasUUID("Owner")) this.ownerUuid = tag.getUUID("Owner");
        if (tag.contains("DomainId")) this.entityData.set(DATA_DOMAIN_ID, tag.getString("DomainId"));
        if (tag.contains("Radius")) this.entityData.set(DATA_RADIUS, tag.getFloat("Radius"));
        if (tag.contains("Age")) this.entityData.set(DATA_AGE, tag.getInt("Age"));
        if (tag.contains("Duration")) this.entityData.set(DATA_DURATION, tag.getInt("Duration"));
        if (tag.contains("Integrity")) this.barrierIntegrity = tag.getDouble("Integrity");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        if (this.ownerUuid != null) tag.putUUID("Owner", this.ownerUuid);
        tag.putString("DomainId", getDomainId().toString());
        tag.putFloat("Radius", getRadius());
        tag.putInt("Age", getAgeTicks());
        tag.putInt("Duration", getDurationTicks());
        tag.putDouble("Integrity", this.barrierIntegrity);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distanceSqr) {
        double r = getRadius() + 64.0;
        return distanceSqr < r * r;
    }
}
