package com.jjkmod.entity;

public enum CursedRarity {
    GRADE_4(1, 3),
    GRADE_3(4, 7),
    GRADE_2(8, 12),
    GRADE_1(13, 16),
    SPECIAL_GRADE(17, 20);

    public final int minLevel;
    public final int maxLevel;

    CursedRarity(int minLevel, int maxLevel) {
        this.minLevel = minLevel;
        this.maxLevel = maxLevel;
    }

    public static CursedRarity fromOrdinal(int idx) {
        CursedRarity[] vals = values();
        return vals[Math.max(0, Math.min(idx, vals.length - 1))];
    }
}
