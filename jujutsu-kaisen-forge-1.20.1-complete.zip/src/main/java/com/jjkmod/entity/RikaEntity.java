package com.jjkmod.entity;

import com.jjkmod.registry.ModCapabilities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

import javax.annotation.Nullable;
import java.util.UUID;

public class RikaEntity extends PathfinderMob implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private UUID ownerUuid;
    private int lifeTicks = 6000; // 5 minutes full manifestation
    private boolean completeManifestation = false;

    public RikaEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 350.0)
                .add(Attributes.MOVEMENT_SPEED, 0.38)
                .add(Attributes.ATTACK_DAMAGE, 16.0)
                .add(Attributes.FOLLOW_RANGE, 40.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.3, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, ServerPlayer.class, 12.0f));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }

    public void setOwner(ServerPlayer owner, int durationTicks) {
        this.ownerUuid = owner.getUUID();
        this.lifeTicks = durationTicks;
    }

    @Nullable
    public UUID getOwnerUuid() { return ownerUuid; }

    public void triggerCompleteManifestation() {
        this.completeManifestation = true;
        this.lifeTicks = Math.max(this.lifeTicks, 6000);
    }

    public boolean isCompleteManifestation() { return completeManifestation; }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.level() instanceof ServerLevel serverLevel) {
            if (--lifeTicks <= 0) {
                this.discard();
                return;
            }
            if (ownerUuid != null) {
                Entity owner = serverLevel.getEntity(ownerUuid);
                if (owner instanceof ServerPlayer sp && sp.isAlive()) {
                    double dist = this.distanceTo(sp);
                    if (dist > 24.0) {
                        this.teleportTo(sp.getX() + 1.5, sp.getY(), sp.getZ() + 1.5);
                    } else if (dist > 5.0 && this.getTarget() == null) {
                        this.getNavigation().moveTo(sp, 1.25);
                    }
                    // Assist owner's attack target
                    LivingEntity lastHurt = sp.getLastHurtMob();
                    if (lastHurt != null && lastHurt.isAlive() && lastHurt != this) {
                        this.setTarget(lastHurt);
                    }
                    // Refill owner's Cursed Energy during complete manifestation
                    if (completeManifestation && this.tickCount % 10 == 0) {
                        sp.getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(data ->
                                data.setCursedEnergy(data.getCursedEnergy() + 25.0));
                    }
                }
            }
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerUuid != null) tag.putUUID("Owner", ownerUuid);
        tag.putInt("LifeTicks", lifeTicks);
        tag.putBoolean("Complete", completeManifestation);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) ownerUuid = tag.getUUID("Owner");
        if (tag.contains("LifeTicks")) lifeTicks = tag.getInt("LifeTicks");
        completeManifestation = tag.getBoolean("Complete");
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 4, state -> {
            if (this.swinging) {
                return state.setAndContinue(RawAnimation.begin().thenPlay("animation.rika.attack"));
            }
            return state.setAndContinue(RawAnimation.begin().thenLoop("animation.rika.idle"));
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
