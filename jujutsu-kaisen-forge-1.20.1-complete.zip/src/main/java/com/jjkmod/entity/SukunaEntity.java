package com.jjkmod.entity;

import com.jjkmod.config.ModConfig;
import com.jjkmod.domain.DomainManager;
import com.jjkmod.registry.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class SukunaEntity extends Monster implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.jjkmod.sukuna_boss"),
            BossEvent.BossBarColor.RED,
            BossEvent.BossBarOverlay.PROGRESS);

    private boolean hasExpandedDomain = false;
    private int slashCooldown = 0;
    private int domainAnimTicks = 0;

    public SukunaEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 250;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 600.0)
                .add(Attributes.MOVEMENT_SPEED, 0.36)
                .add(Attributes.ATTACK_DAMAGE, 18.0)
                .add(Attributes.ARMOR, 12.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.level() instanceof ServerLevel serverLevel) {
            this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
            if (domainAnimTicks > 0) domainAnimTicks--;

            // Auto-expand Malevolent Shrine below 50% HP
            if (!hasExpandedDomain && this.getHealth() <= this.getMaxHealth() * 0.5f && this.getTarget() != null) {
                hasExpandedDomain = true;
                domainAnimTicks = 40;
                DomainManager.expandBossDomain(this, serverLevel);
                serverLevel.playSound(null, this.blockPosition(), ModSounds.DOMAIN_SUKUNA_OPEN.get(),
                        SoundSource.HOSTILE, 2.5f, 1.0f);
            }

            // Periodic ranged slash attack
            LivingEntity target = this.getTarget();
            if (target != null && target.isAlive()) {
                if (slashCooldown > 0) {
                    slashCooldown--;
                } else if (this.distanceTo(target) <= 24.0) {
                    slashCooldown = 60;
                    target.hurt(this.damageSources().mobAttack(this), 14.0f);
                    serverLevel.playSound(null, target.blockPosition(), ModSounds.SLASH_BATSU.get(),
                            SoundSource.HOSTILE, 1.2f, 1.0f);
                }
            }
        }
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("HasExpandedDomain", hasExpandedDomain);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        hasExpandedDomain = tag.getBoolean("HasExpandedDomain");
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 4, state -> {
            if (domainAnimTicks > 20) {
                return state.setAndContinue(RawAnimation.begin().thenPlay("animation.sukuna.hand_sign"));
            } else if (domainAnimTicks > 0) {
                return state.setAndContinue(RawAnimation.begin().thenPlay("animation.sukuna.domain_expand"));
            }
            return state.setAndContinue(RawAnimation.begin().thenLoop("animation.sukuna.idle"));
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
