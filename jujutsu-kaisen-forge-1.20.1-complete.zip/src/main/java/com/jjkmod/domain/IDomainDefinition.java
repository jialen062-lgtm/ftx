package com.jjkmod.domain;

import com.jjkmod.entity.DomainEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;

public interface IDomainDefinition {
    ResourceLocation getId();
    double getRadius();
    int getDurationTicks();
    int getCooldownTicks();
    double getCursedEnergyCost();
    boolean isOpenBarrier();
    ResourceLocation getOpenSound();
    ResourceLocation getLoopSound();
    void onDomainTick(DomainEntity domain, ServerLevel level);
}
