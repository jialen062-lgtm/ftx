package com.jjkmod.domain.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.domain.IDomainDefinition;
import com.jjkmod.entity.DomainEntity;
import com.jjkmod.registry.ModSounds;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class AuthenticMutualLoveDomain implements IDomainDefinition {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "authentic_mutual_love");

    @Override public ResourceLocation getId() { return ID; }
    @Override public double getRadius() { return 26.0; }
    @Override public int getDurationTicks() { return 400; }
    @Override public int getCooldownTicks() { return 1100; }
    @Override public double getCursedEnergyCost() { return 400.0; }
    @Override public boolean isOpenBarrier() { return false; }
    @Override public ResourceLocation getOpenSound() { return ModSounds.DOMAIN_YUTA_OPEN.getId(); }
    @Override public ResourceLocation getLoopSound() { return ModSounds.DOMAIN_YUTA_LOOP.getId(); }

    @Override
    public void onDomainTick(DomainEntity domain, ServerLevel level) {
        LivingEntity owner = domain.getOwnerEntity(level);
        if (owner != null) {
            owner.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 40, 1, false, false));
        }
        AABB box = domain.getBoundingBox().inflate(getRadius());
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != owner)) {
            target.hurt(level.damageSources().magic(), 6.0f);
        }
    }
}
