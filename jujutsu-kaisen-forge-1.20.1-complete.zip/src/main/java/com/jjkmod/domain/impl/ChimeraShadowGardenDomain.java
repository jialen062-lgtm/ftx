package com.jjkmod.domain.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.domain.IDomainDefinition;
import com.jjkmod.entity.DomainEntity;
import com.jjkmod.registry.ModSounds;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class ChimeraShadowGardenDomain implements IDomainDefinition {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "chimera_shadow_garden");

    @Override public ResourceLocation getId() { return ID; }
    @Override public double getRadius() { return 22.0; }
    @Override public int getDurationTicks() { return 400; }
    @Override public int getCooldownTicks() { return 1000; }
    @Override public double getCursedEnergyCost() { return 350.0; }
    @Override public boolean isOpenBarrier() { return false; }
    @Override public ResourceLocation getOpenSound() { return ModSounds.DOMAIN_SUKUNA_OPEN.getId(); }
    @Override public ResourceLocation getLoopSound() { return ModSounds.DOMAIN_SUKUNA_LOOP.getId(); }

    @Override
    public void onDomainTick(DomainEntity domain, ServerLevel level) {
        LivingEntity owner = domain.getOwnerEntity(level);
        AABB box = domain.getBoundingBox().inflate(getRadius());
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != owner)) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 2));
            target.hurt(level.damageSources().magic(), 3.0f);
        }
    }
}
