package com.jjkmod.domain.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.config.ModConfig;
import com.jjkmod.domain.IDomainDefinition;
import com.jjkmod.entity.DomainEntity;
import com.jjkmod.registry.ModCapabilities;
import com.jjkmod.registry.ModSounds;
import com.jjkmod.technique.impl.BatsuTechnique;
import com.jjkmod.technique.impl.KaiTechnique;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

import java.util.List;

public class MalevolentShrineDomain implements IDomainDefinition {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "malevolent_shrine");

    @Override public ResourceLocation getId() { return ID; }
    @Override public double getRadius() { return ModConfig.COMMON.sukunaDomainRadius.get(); }
    @Override public int getDurationTicks() { return ModConfig.COMMON.sukunaDomainDurationTicks.get(); }
    @Override public int getCooldownTicks() { return ModConfig.COMMON.sukunaDomainCooldownTicks.get(); }
    @Override public double getCursedEnergyCost() { return ModConfig.COMMON.sukunaDomainCursedEnergyCost.get(); }
    @Override public boolean isOpenBarrier() { return true; }
    @Override public ResourceLocation getOpenSound() { return ModSounds.DOMAIN_SUKUNA_OPEN.getId(); }
    @Override public ResourceLocation getLoopSound() { return ModSounds.DOMAIN_SUKUNA_LOOP.getId(); }

    @Override
    public void onDomainTick(DomainEntity domain, ServerLevel level) {
        double r = domain.getRadius();
        // Performance: limit active entity scan box & skip distant chunks if needed
        AABB box = domain.getBoundingBox().inflate(r, 32.0, r);
        LivingEntity owner = domain.getOwnerEntity(level);

        double damageMult = 1.0;
        double casterEnergy = 1000.0;
        if (owner instanceof ServerPlayer sp) {
            var cap = sp.getCapability(ModCapabilities.PLAYER_CURSED_DATA).resolve();
            if (cap.isPresent()) {
                damageMult = cap.get().getTechniqueDamageMultiplier();
                casterEnergy = cap.get().getCursedEnergy();
            }
        }

        List<Entity> entities = level.getEntities(domain, box, e -> e != owner && e.distanceTo(domain) <= r);
        int processed = 0;
        for (Entity e : entities) {
            if (++processed > 128) break; // Performance cap per 20-tick pulse
            if (e instanceof LivingEntity living) {
                BatsuTechnique.applyBatsuDamage(living, owner, casterEnergy, damageMult);
            } else if (KaiTechnique.isNonLivingSliceTarget(e)) {
                KaiTechnique.sliceNonLiving(e, owner, damageMult);
            }
        }

        if (ModConfig.COMMON.domainBreakBlocks.get() && owner != null) {
            KaiTechnique.breakNearbyFragileBlocks(level, domain.blockPosition(), 12, owner);
        }

        level.playSound(null, domain.blockPosition(), ModSounds.SLASH_KAI.get(), SoundSource.HOSTILE, 0.7f, 1.1f);
    }
}
