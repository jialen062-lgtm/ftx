package com.jjkmod.domain.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.config.ModConfig;
import com.jjkmod.domain.IDomainDefinition;
import com.jjkmod.entity.DomainEntity;
import com.jjkmod.registry.ModSounds;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class UnlimitedVoidDomain implements IDomainDefinition {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "unlimited_void");

    @Override public ResourceLocation getId() { return ID; }
    @Override public double getRadius() { return ModConfig.COMMON.gojoDomainRadius.get(); }
    @Override public int getDurationTicks() { return ModConfig.COMMON.gojoDomainDurationTicks.get(); }
    @Override public int getCooldownTicks() { return ModConfig.COMMON.gojoDomainCooldownTicks.get(); }
    @Override public double getCursedEnergyCost() { return ModConfig.COMMON.gojoDomainCursedEnergyCost.get(); }
    @Override public boolean isOpenBarrier() { return false; }
    @Override public ResourceLocation getOpenSound() { return ModSounds.DOMAIN_GOJO_OPEN.getId(); }
    @Override public ResourceLocation getLoopSound() { return ModSounds.DOMAIN_GOJO_LOOP.getId(); }

    @Override
    public void onDomainTick(DomainEntity domain, ServerLevel level) {
        LivingEntity owner = domain.getOwnerEntity(level);
        AABB box = domain.getBoundingBox().inflate(getRadius());
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != owner)) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 6, false, false));
            target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 1, false, false));
            target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 40, 0, false, false));
            target.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 40, 4, false, false));
        }
    }
}
