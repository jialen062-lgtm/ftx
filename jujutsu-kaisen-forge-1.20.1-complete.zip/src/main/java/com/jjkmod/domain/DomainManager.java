package com.jjkmod.domain;

import com.jjkmod.config.ModConfig;
import com.jjkmod.entity.DomainEntity;
import com.jjkmod.entity.SukunaEntity;
import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.DomainBgmS2CPacket;
import com.jjkmod.network.packet.SyncCursedDataS2CPacket;
import com.jjkmod.registry.CharacterRegistry;
import com.jjkmod.registry.DomainRegistry;
import com.jjkmod.registry.ModCapabilities;
import com.jjkmod.registry.ModEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class DomainManager {
    private static final Map<UUID, UUID> ACTIVE_DOMAINS = new ConcurrentHashMap<>();

    public static void tryExpandPlayerDomain(ServerPlayer player) {
        player.getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(data -> {
            ResourceLocation charId = data.getCurrentCharacter();
            if (charId.equals(CharacterRegistry.SUKUNA) && data.getFingerCount() < 1) {
                player.displayClientMessage(Component.translatable("message.jjkmod.need_finger"), true);
                return;
            }
            Optional<CharacterRegistry.CharacterDefinition> charDef = CharacterRegistry.get(charId);
            if (charDef.isEmpty()) return;

            ResourceLocation domainId = charDef.get().domainId();
            Optional<IDomainDefinition> domainOpt = DomainRegistry.get(domainId);
            if (domainOpt.isEmpty()) return;
            IDomainDefinition domainDef = domainOpt.get();

            int cd = data.getCooldown(domainId);
            if (cd > 0 && (!player.isCreative() || ModConfig.COMMON.creativeModeCooldownApplies.get())) {
                player.displayClientMessage(Component.translatable("message.jjkmod.on_cooldown", cd / 20.0f), true);
                return;
            }

            if (!player.isCreative() && data.getCursedEnergy() < domainDef.getCursedEnergyCost()) {
                player.displayClientMessage(Component.translatable("message.jjkmod.not_enough_energy"), true);
                return;
            }

            dismissPlayerDomain(player);

            if (!player.isCreative()) {
                data.setCursedEnergy(data.getCursedEnergy() - domainDef.getCursedEnergyCost());
            }
            if (!player.isCreative() || ModConfig.COMMON.creativeModeCooldownApplies.get()) {
                data.setCooldown(domainId, domainDef.getCooldownTicks());
            }

            ServerLevel level = player.serverLevel();
            DomainEntity entity = ModEntities.DOMAIN_ENTITY.get().create(level);
            if (entity != null) {
                entity.setPos(player.getX(), player.getY(), player.getZ());
                entity.configure(player.getUUID(), domainId, (float) domainDef.getRadius(), domainDef.getDurationTicks());
                level.addFreshEntity(entity);
                ACTIVE_DOMAINS.put(player.getUUID(), entity.getUUID());
            }

            ModNetwork.sendToPlayer(new DomainBgmS2CPacket(true, domainDef.getOpenSound(), domainDef.getLoopSound()), player);
            ModNetwork.sendToPlayer(new SyncCursedDataS2CPacket(data), player);
            player.displayClientMessage(Component.translatable("message.jjkmod.domain_expanded"), true);
        });
    }

    public static void expandBossDomain(SukunaEntity boss, ServerLevel level) {
        ResourceLocation domainId = new ResourceLocation("jjkmod", "malevolent_shrine");
        DomainRegistry.get(domainId).ifPresent(def -> {
            DomainEntity entity = ModEntities.DOMAIN_ENTITY.get().create(level);
            if (entity != null) {
                entity.setPos(boss.getX(), boss.getY(), boss.getZ());
                entity.configure(boss.getUUID(), domainId, (float) def.getRadius(), def.getDurationTicks());
                level.addFreshEntity(entity);
                ACTIVE_DOMAINS.put(boss.getUUID(), entity.getUUID());
            }
        });
    }

    public static void dismissPlayerDomain(ServerPlayer player) {
        UUID entityId = ACTIVE_DOMAINS.remove(player.getUUID());
        if (entityId != null) {
            var e = player.serverLevel().getEntity(entityId);
            if (e != null) e.discard();
        }
        ModNetwork.sendToPlayer(new DomainBgmS2CPacket(false, null, null), player);
    }

    public static void onDomainExpired(DomainEntity domain, ServerLevel level) {
        if (domain.getOwnerUuid() != null) {
            ACTIVE_DOMAINS.remove(domain.getOwnerUuid(), domain.getUUID());
            var owner = level.getServer().getPlayerList().getPlayer(domain.getOwnerUuid());
            if (owner != null) {
                ModNetwork.sendToPlayer(new DomainBgmS2CPacket(false, null, null), owner);
            }
        }
    }

    public static boolean isInsidePlayerDomain(ServerPlayer player, ResourceLocation domainId) {
        UUID entityId = ACTIVE_DOMAINS.get(player.getUUID());
        if (entityId == null) return false;
        var e = player.serverLevel().getEntity(entityId);
        if (e instanceof DomainEntity domain && domain.isAlive() && domain.getDomainId().equals(domainId)) {
            return domain.distanceTo(player) <= domain.getRadius();
        }
        return false;
    }
}
