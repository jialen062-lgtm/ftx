package com.jjkmod.capability;

import com.jjkmod.registry.ModCapabilities;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerCursedDataProvider implements ICapabilityProvider, INBTSerializable<CompoundTag> {
    private PlayerCursedData data = null;
    private final LazyOptional<PlayerCursedData> optional = LazyOptional.of(this::createData);

    private PlayerCursedData createData() {
        if (this.data == null) {
            this.data = new PlayerCursedData();
        }
        return this.data;
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ModCapabilities.PLAYER_CURSED_DATA) {
            return optional.cast();
        }
        return LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        return createData().saveNBT();
    }

    @Override
    public void deserializeNBT(CompoundTag nbt) {
        createData().loadNBT(nbt);
    }
}
