package com.jjkmod.capability;

import com.jjkmod.config.ModConfig;
import com.jjkmod.registry.CharacterRegistry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;

import java.util.*;

public class PlayerCursedData {
    private double cursedEnergy = 1000.0;
    private double maxCursedEnergy = 1000.0;
    private int fingerCount = 0;
    private ResourceLocation currentCharacter = CharacterRegistry.SUKUNA;
    private final Set<ResourceLocation> unlockedTechniques = new HashSet<>();
    private final Map<ResourceLocation, Integer> cooldowns = new HashMap<>();

    public double getCursedEnergy() { return cursedEnergy; }
    public void setCursedEnergy(double val) { this.cursedEnergy = Math.max(0.0, Math.min(val, maxCursedEnergy)); }

    public double getMaxCursedEnergy() { return maxCursedEnergy; }
    public void setMaxCursedEnergy(double val) {
        this.maxCursedEnergy = Math.max(1.0, val);
        if (this.cursedEnergy > this.maxCursedEnergy) {
            this.cursedEnergy = this.maxCursedEnergy;
        }
    }

    public int getFingerCount() { return fingerCount; }
    public void setFingerCount(int count) {
        this.fingerCount = Math.max(0, Math.min(count, ModConfig.COMMON.maxFingerCount.get()));
        recalculateFingerBonuses();
    }

    public void recalculateFingerBonuses() {
        double base = ModConfig.COMMON.baseMaxCursedEnergy.get();
        double perFinger = ModConfig.COMMON.perFingerMaxEnergy.get();
        setMaxCursedEnergy(base + fingerCount * perFinger);
    }

    public double getTechniqueDamageMultiplier() {
        return 1.0 + fingerCount * ModConfig.COMMON.perFingerDamageBonus.get();
    }

    public ResourceLocation getCurrentCharacter() { return currentCharacter; }
    public void setCurrentCharacter(ResourceLocation characterId) { this.currentCharacter = characterId; }

    public Set<ResourceLocation> getUnlockedTechniques() { return unlockedTechniques; }
    public boolean isTechniqueUnlocked(ResourceLocation id) { return unlockedTechniques.contains(id); }
    public void unlockTechnique(ResourceLocation id) { unlockedTechniques.add(id); }

    public void refreshUnlockedTechniquesForCharacter(ResourceLocation characterId) {
        // Keep Sukuna techniques if fingerCount >= 1
        Set<ResourceLocation> preserved = new HashSet<>();
        if (fingerCount >= 1) {
            CharacterRegistry.get(CharacterRegistry.SUKUNA)
                    .ifPresent(def -> preserved.addAll(def.baseTechniques()));
        }
        unlockedTechniques.clear();
        unlockedTechniques.addAll(preserved);
        if (!characterId.equals(CharacterRegistry.SUKUNA) || fingerCount >= 1) {
            CharacterRegistry.get(characterId)
                    .ifPresent(def -> unlockedTechniques.addAll(def.baseTechniques()));
        }
    }

    public int getCooldown(ResourceLocation id) { return cooldowns.getOrDefault(id, 0); }
    public void setCooldown(ResourceLocation id, int ticks) {
        if (ticks <= 0) cooldowns.remove(id);
        else cooldowns.put(id, ticks);
    }

    public Map<ResourceLocation, Integer> getCooldowns() { return cooldowns; }

    public void tickCooldowns() {
        Iterator<Map.Entry<ResourceLocation, Integer>> it = cooldowns.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<ResourceLocation, Integer> e = it.next();
            int next = e.getValue() - 1;
            if (next <= 0) it.remove();
            else e.setValue(next);
        }
    }

    public void copyFrom(PlayerCursedData source) {
        this.cursedEnergy = source.cursedEnergy;
        this.maxCursedEnergy = source.maxCursedEnergy;
        this.fingerCount = source.fingerCount;
        this.currentCharacter = source.currentCharacter;
        this.unlockedTechniques.clear();
        this.unlockedTechniques.addAll(source.unlockedTechniques);
        this.cooldowns.clear();
        this.cooldowns.putAll(source.cooldowns);
    }

    public CompoundTag saveNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putDouble("cursedEnergy", cursedEnergy);
        tag.putDouble("maxCursedEnergy", maxCursedEnergy);
        tag.putInt("fingerCount", fingerCount);
        tag.putString("currentCharacter", currentCharacter.toString());

        ListTag techList = new ListTag();
        for (ResourceLocation id : unlockedTechniques) {
            techList.add(StringTag.valueOf(id.toString()));
        }
        tag.put("unlockedTechniques", techList);

        CompoundTag cdTag = new CompoundTag();
        for (Map.Entry<ResourceLocation, Integer> e : cooldowns.entrySet()) {
            cdTag.putInt(e.getKey().toString(), e.getValue());
        }
        tag.put("cooldowns", cdTag);
        return tag;
    }

    public void loadNBT(CompoundTag tag) {
        this.fingerCount = tag.getInt("fingerCount");
        this.maxCursedEnergy = tag.contains("maxCursedEnergy") ? tag.getDouble("maxCursedEnergy") : 1000.0;
        this.cursedEnergy = tag.contains("cursedEnergy") ? tag.getDouble("cursedEnergy") : this.maxCursedEnergy;
        if (tag.contains("currentCharacter")) {
            this.currentCharacter = new ResourceLocation(tag.getString("currentCharacter"));
        }
        this.unlockedTechniques.clear();
        ListTag techList = tag.getList("unlockedTechniques", Tag.TAG_STRING);
        for (int i = 0; i < techList.size(); i++) {
            this.unlockedTechniques.add(new ResourceLocation(techList.getString(i)));
        }
        this.cooldowns.clear();
        CompoundTag cdTag = tag.getCompound("cooldowns");
        for (String key : cdTag.getAllKeys()) {
            this.cooldowns.put(new ResourceLocation(key), cdTag.getInt(key));
        }
    }
}
