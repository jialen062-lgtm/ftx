package com.jjkmod.client.sound;

import com.jjkmod.config.ModConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.registries.ForgeRegistries;

public class DomainBgmManager {
    private static SoundInstance activeLoop;

    public static void playDomainBgm(ResourceLocation openId, ResourceLocation loopId) {
        stopDomainBgm();
        if (!ModConfig.CLIENT.enableDomainBgm.get()) return;
        Minecraft mc = Minecraft.getInstance();
        float vol = ModConfig.CLIENT.domainBgmVolume.get().floatValue();

        if (openId != null) {
            SoundEvent openEvent = ForgeRegistries.SOUND_EVENTS.getValue(openId);
            if (openEvent != null) {
                mc.getSoundManager().play(SimpleSoundInstance.forMusic(openEvent));
            }
        }
        if (loopId != null) {
            SoundEvent loopEvent = ForgeRegistries.SOUND_EVENTS.getValue(loopId);
            if (loopEvent != null) {
                activeLoop = new SimpleSoundInstance(
                        loopEvent.getLocation(),
                        SoundSource.MUSIC,
                        vol,
                        1.0f,
                        SoundInstance.createUnseededRandom(),
                        true,
                        0,
                        SoundInstance.Attenuation.NONE,
                        0.0, 0.0, 0.0,
                        true
                );
                mc.getSoundManager().play(activeLoop);
            }
        }
    }

    public static void stopDomainBgm() {
        if (activeLoop != null) {
            Minecraft.getInstance().getSoundManager().stop(activeLoop);
            activeLoop = null;
        }
    }
}
