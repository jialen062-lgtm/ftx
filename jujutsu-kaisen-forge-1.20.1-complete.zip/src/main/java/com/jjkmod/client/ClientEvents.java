package com.jjkmod.client;

import com.jjkmod.JJKMod;
import com.jjkmod.client.gui.CursedHudOverlay;
import com.jjkmod.client.particle.SlashLineParticle;
import com.jjkmod.client.renderer.ClientDomainRenderer;
import com.jjkmod.client.renderer.CursedSpiritRenderer;
import com.jjkmod.client.renderer.RikaEntityRenderer;
import com.jjkmod.client.renderer.SukunaEntityRenderer;
import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.CastTechniqueC2SPacket;
import com.jjkmod.network.packet.ExpandDomainC2SPacket;
import com.jjkmod.registry.CharacterRegistry;
import com.jjkmod.registry.ModEntities;
import com.jjkmod.registry.ModParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

public class ClientEvents {

    @Mod.EventBusSubscriber(modid = JJKMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModBus {
        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(ModKeyBindings.TECHNIQUE_1);
            event.register(ModKeyBindings.TECHNIQUE_2);
            event.register(ModKeyBindings.TECHNIQUE_3);
            event.register(ModKeyBindings.TECHNIQUE_4);
            event.register(ModKeyBindings.DOMAIN_EXPAND);
        }

        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ModEntities.SUKUNA_BOSS.get(), SukunaEntityRenderer::new);
            event.registerEntityRenderer(ModEntities.RIKA.get(), RikaEntityRenderer::new);
            event.registerEntityRenderer(ModEntities.CURSED_SPIRIT.get(), CursedSpiritRenderer::new);
            event.registerEntityRenderer(ModEntities.DOMAIN_ENTITY.get(), ClientDomainRenderer::new);
        }

        @SubscribeEvent
        public static void registerParticles(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(ModParticles.GRID_SLASH_LINE.get(), SlashLineParticle.Provider::new);
            event.registerSpriteSet(ModParticles.WORLD_RIFT_LINE.get(), SlashLineParticle.Provider::new);
            event.registerSpriteSet(ModParticles.DOMAIN_SLASH_SPARK.get(), SlashLineParticle.Provider::new);
        }

        @SubscribeEvent
        public static void registerGuiOverlays(RegisterGuiOverlaysEvent event) {
            event.registerAboveAll("cursed_hud", CursedHudOverlay.HUD);
        }
    }

    @Mod.EventBusSubscriber(modid = JJKMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static class ClientForgeBus {
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;

            var charId = ClientCursedDataCache.get().getCurrentCharacter();
            List<ResourceLocation> techs = CharacterRegistry.get(charId)
                    .map(CharacterRegistry.CharacterDefinition::baseTechniques)
                    .orElse(List.of());

            if (ModKeyBindings.TECHNIQUE_1.consumeClick() && techs.size() > 0) {
                ModNetwork.sendToServer(new CastTechniqueC2SPacket(techs.get(0)));
            }
            if (ModKeyBindings.TECHNIQUE_2.consumeClick() && techs.size() > 1) {
                ModNetwork.sendToServer(new CastTechniqueC2SPacket(techs.get(1)));
            }
            if (ModKeyBindings.TECHNIQUE_3.consumeClick() && techs.size() > 2) {
                ModNetwork.sendToServer(new CastTechniqueC2SPacket(techs.get(2)));
            }
            if (ModKeyBindings.TECHNIQUE_4.consumeClick() && techs.size() > 3) {
                ModNetwork.sendToServer(new CastTechniqueC2SPacket(techs.get(3)));
            }
            if (ModKeyBindings.DOMAIN_EXPAND.consumeClick()) {
                ModNetwork.sendToServer(new ExpandDomainC2SPacket());
            }
        }
    }
}
