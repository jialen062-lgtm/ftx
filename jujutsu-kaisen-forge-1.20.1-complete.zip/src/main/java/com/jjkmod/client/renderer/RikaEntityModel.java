package com.jjkmod.client.renderer;

import com.jjkmod.JJKMod;
import com.jjkmod.entity.RikaEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class RikaEntityModel extends GeoModel<RikaEntity> {
    @Override
    public ResourceLocation getModelResource(RikaEntity animatable) {
        return new ResourceLocation(JJKMod.MODID, "geo/rika.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(RikaEntity animatable) {
        return new ResourceLocation(JJKMod.MODID, "textures/entity/rika.png");
    }

    @Override
    public ResourceLocation getAnimationResource(RikaEntity animatable) {
        return new ResourceLocation(JJKMod.MODID, "animations/rika.animation.json");
    }
}
