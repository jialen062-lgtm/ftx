package com.jjkmod.client.renderer;

import com.jjkmod.JJKMod;
import com.jjkmod.config.ModConfig;
import com.jjkmod.domain.impl.AuthenticMutualLoveDomain;
import com.jjkmod.domain.impl.ChimeraShadowGardenDomain;
import com.jjkmod.domain.impl.MalevolentShrineDomain;
import com.jjkmod.domain.impl.UnlimitedVoidDomain;
import com.jjkmod.entity.DomainEntity;
import com.jjkmod.registry.ModParticles;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public class ClientDomainRenderer extends EntityRenderer<DomainEntity> {
    private static final ResourceLocation SHRINE_TEXTURE =
            new ResourceLocation(JJKMod.MODID, "textures/entity/malevolent_shrine.png");

    public ClientDomainRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public void render(DomainEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        float time = entity.tickCount + partialTick;
        ResourceLocation domainId = entity.getDomainId();

        // Continuous rich particle effects (LOD-scaled)
        if (entity.tickCount % 2 == 0) {
            spawnBoundaryCurtain(mc.level, entity, mc.player.position());
            spawnDomainAmbientVfx(mc.level, entity, mc.player.position(), domainId);
        }

        if (domainId.equals(MalevolentShrineDomain.ID)) {
            renderDetailedMalevolentShrine(poseStack, buffer, packedLight, time);
            renderExpandingShockwaveRing(poseStack, buffer, time, 0.90f, 0.08f, 0.14f);
        } else if (domainId.equals(UnlimitedVoidDomain.ID)) {
            renderUnlimitedVoidEye(poseStack, buffer, packedLight, time);
            renderExpandingShockwaveRing(poseStack, buffer, time, 0.25f, 0.78f, 1.0f);
        } else if (domainId.equals(ChimeraShadowGardenDomain.ID)) {
            renderShadowGardenPool(poseStack, buffer, packedLight, time);
            renderExpandingShockwaveRing(poseStack, buffer, time, 0.45f, 0.15f, 0.75f);
        } else if (domainId.equals(AuthenticMutualLoveDomain.ID)) {
            renderMutualLoveSwords(poseStack, buffer, packedLight, time);
            renderExpandingShockwaveRing(poseStack, buffer, time, 0.75f, 0.55f, 0.95f);
        }
    }

    private void renderDetailedMalevolentShrine(PoseStack poseStack, MultiBufferSource buffer, int light, float time) {
        poseStack.pushPose();
        float bob = (float) Math.sin(time * 0.05f) * 0.55f;
        poseStack.translate(0.0, 4.2 + bob, 0.0);
        poseStack.mulPose(Axis.YP.rotationDegrees(time * 0.3f));

        VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucent(SHRINE_TEXTURE));

        // 1. 3-Tiered Obsidian & Crimson Foundation + Corner Lanterns
        drawBox(vc, poseStack, -4.0f, 0.0f, -4.0f, 8.0f, 0.4f, 8.0f, 0.16f, 0.13f, 0.18f, 0.90f, light);
        drawBox(vc, poseStack, -3.2f, 0.4f, -3.2f, 6.4f, 0.4f, 6.4f, 0.24f, 0.15f, 0.20f, 0.90f, light);
        drawBox(vc, poseStack, -2.7f, 0.8f, -2.7f, 5.4f, 0.4f, 5.4f, 0.58f, 0.09f, 0.14f, 0.92f, light);

        float[][] corners = {{-3.6f, -3.6f}, {3.1f, -3.6f}, {-3.6f, 3.1f}, {3.1f, 3.1f}};
        for (float[] c : corners) {
            drawBox(vc, poseStack, c[0], 0.4f, c[1], 0.5f, 0.9f, 0.5f, 0.22f, 0.18f, 0.24f, 0.92f, light);
            drawBox(vc, poseStack, c[0] + 0.1f, 0.8f, c[1] + 0.1f, 0.3f, 0.3f, 0.3f, 1.0f, 0.20f, 0.25f, 0.98f, 0xF000F0);
        }

        // 2. Four Crimson Pillars + Gold Collars + Torii Crossbeams
        float[][] pillars = {{-2.2f, -2.2f}, {1.6f, -2.2f}, {-2.2f, 1.6f}, {1.6f, 1.6f}};
        for (float[] p : pillars) {
            drawBox(vc, poseStack, p[0], 1.2f, p[1], 0.6f, 3.4f, 0.6f, 0.72f, 0.07f, 0.13f, 0.92f, light);
            drawBox(vc, poseStack, p[0] - 0.1f, 1.5f, p[1] - 0.1f, 0.8f, 0.25f, 0.8f, 0.90f, 0.74f, 0.25f, 0.95f, light);
        }
        drawBox(vc, poseStack, -2.8f, 3.8f, -2.2f, 5.6f, 0.35f, 0.4f, 0.72f, 0.07f, 0.13f, 0.92f, light);
        drawBox(vc, poseStack, -2.8f, 3.8f, 1.8f, 5.6f, 0.35f, 0.4f, 0.72f, 0.07f, 0.13f, 0.92f, light);

        // 3. Horned Demon Skull Altar + Glowing Eyes + Side Skulls
        drawBox(vc, poseStack, -0.9f, 1.4f, -0.9f, 1.8f, 1.6f, 1.8f, 0.92f, 0.87f, 0.80f, 0.95f, light);
        drawBox(vc, poseStack, -0.55f, 2.0f, -0.95f, 0.35f, 0.35f, 0.15f, 1.0f, 0.12f, 0.18f, 1.0f, 0xF000F0);
        drawBox(vc, poseStack, 0.20f, 2.0f, -0.95f, 0.35f, 0.35f, 0.15f, 1.0f, 0.12f, 0.18f, 1.0f, 0xF000F0);
        // Curved Horns
        drawBox(vc, poseStack, -1.7f, 2.5f, -0.3f, 0.8f, 0.4f, 0.5f, 0.85f, 0.80f, 0.72f, 0.95f, light);
        drawBox(vc, poseStack, -2.1f, 2.8f, -0.3f, 0.5f, 0.9f, 0.5f, 0.85f, 0.80f, 0.72f, 0.95f, light);
        drawBox(vc, poseStack, 0.9f, 2.5f, -0.3f, 0.8f, 0.4f, 0.5f, 0.85f, 0.80f, 0.72f, 0.95f, light);
        drawBox(vc, poseStack, 1.6f, 2.8f, -0.3f, 0.5f, 0.9f, 0.5f, 0.85f, 0.80f, 0.72f, 0.95f, light);

        // 4. Lower & Upper Upturned Pagoda Roofs + Golden Sorin Finial
        drawBox(vc, poseStack, -4.4f, 4.6f, -4.4f, 8.8f, 0.5f, 8.8f, 0.14f, 0.12f, 0.18f, 0.90f, light);
        drawBox(vc, poseStack, -4.9f, 4.9f, -4.9f, 1.0f, 0.35f, 1.0f, 0.72f, 0.08f, 0.14f, 0.92f, light);
        drawBox(vc, poseStack, 3.9f, 4.9f, -4.9f, 1.0f, 0.35f, 1.0f, 0.72f, 0.08f, 0.14f, 0.92f, light);
        drawBox(vc, poseStack, -4.9f, 4.9f, 3.9f, 1.0f, 0.35f, 1.0f, 0.72f, 0.08f, 0.14f, 0.92f, light);
        drawBox(vc, poseStack, 3.9f, 4.9f, 3.9f, 1.0f, 0.35f, 1.0f, 0.72f, 0.08f, 0.14f, 0.92f, light);

        drawBox(vc, poseStack, -3.0f, 5.1f, -3.0f, 6.0f, 0.9f, 6.0f, 0.65f, 0.09f, 0.15f, 0.90f, light);
        drawBox(vc, poseStack, -3.6f, 6.0f, -3.6f, 7.2f, 0.5f, 7.2f, 0.14f, 0.12f, 0.18f, 0.90f, light);
        drawBox(vc, poseStack, -2.1f, 6.5f, -2.1f, 4.2f, 0.5f, 4.2f, 0.14f, 0.12f, 0.18f, 0.90f, light);
        drawBox(vc, poseStack, -0.35f, 7.0f, -0.35f, 0.7f, 2.0f, 0.7f, 0.92f, 0.76f, 0.25f, 0.98f, 0xF000F0);

        // 5. Orbiting Ofuda Talismans & Ritual Blades
        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(-time * 2.2f));
        for (int i = 0; i < 8; i++) {
            double ang = (Math.PI * 2.0 * i) / 8.0;
            float tx = (float) (Math.cos(ang) * 3.8);
            float tz = (float) (Math.sin(ang) * 3.8);
            drawBox(vc, poseStack, tx - 0.15f, 2.6f, tz - 0.05f, 0.3f, 1.1f, 0.1f, 0.95f, 0.92f, 0.84f, 0.92f, 0xF000F0);
        }
        poseStack.popPose();

        poseStack.popPose();
    }

    private void renderExpandingShockwaveRing(PoseStack poseStack, MultiBufferSource buffer, float time, float r, float g, float b) {
        poseStack.pushPose();
        float cycle = (time % 40.0f) / 40.0f;
        float radius = 2.0f + cycle * 12.0f;
        float alpha = (1.0f - cycle) * 0.65f;
        VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucent(SHRINE_TEXTURE));
        int segments = 24;
        for (int i = 0; i < segments; i++) {
            double a1 = (Math.PI * 2.0 * i) / segments;
            double a2 = (Math.PI * 2.0 * (i + 1)) / segments;
            float x1 = (float) (Math.cos(a1) * radius);
            float z1 = (float) (Math.sin(a1) * radius);
            float x2 = (float) (Math.cos(a2) * radius);
            float z2 = (float) (Math.sin(a2) * radius);
            quad(vc, poseStack.last().pose(), x1, 0.2f, z1, x2, 0.2f, z2, x2, 1.2f, z2, x1, 1.2f, z1,
                    r, g, b, alpha, 0xF000F0, 0, 1, 0);
        }
        poseStack.popPose();
    }

    private void renderUnlimitedVoidEye(PoseStack poseStack, MultiBufferSource buffer, int light, float time) {
        poseStack.pushPose();
        float bob = (float) Math.sin(time * 0.04f) * 0.4f;
        poseStack.translate(0.0, 5.5 + bob, 0.0);
        VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucent(
                new ResourceLocation(JJKMod.MODID, "textures/entity/unlimited_void.png")));

        // Cosmic Black Void Core + Glowing Six-Eyes Iris (Front & Back)
        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(time * 0.5f));
        drawBox(vc, poseStack, -3.0f, -3.0f, -3.0f, 6.0f, 6.0f, 6.0f, 0.03f, 0.04f, 0.09f, 0.85f, light);
        drawBox(vc, poseStack, -1.8f, -1.8f, -3.15f, 3.6f, 3.6f, 0.25f, 0.30f, 0.88f, 1.0f, 0.96f, 0xF000F0);
        drawBox(vc, poseStack, -0.8f, -0.8f, -3.28f, 1.6f, 1.6f, 0.2f, 0.02f, 0.02f, 0.05f, 1.0f, light);
        drawBox(vc, poseStack, -1.8f, -1.8f, 2.90f, 3.6f, 3.6f, 0.25f, 0.30f, 0.88f, 1.0f, 0.96f, 0xF000F0);
        poseStack.popPose();

        // Inner & Outer Tilted Infinity Rings
        poseStack.pushPose();
        poseStack.mulPose(Axis.XP.rotationDegrees(25.0f));
        poseStack.mulPose(Axis.YP.rotationDegrees(-time * 1.6f));
        drawBox(vc, poseStack, -5.5f, -0.15f, -0.4f, 11.0f, 0.3f, 0.8f, 0.40f, 0.85f, 1.0f, 0.85f, 0xF000F0);
        drawBox(vc, poseStack, -0.4f, -0.15f, -5.5f, 0.8f, 0.3f, 11.0f, 0.40f, 0.85f, 1.0f, 0.85f, 0xF000F0);
        poseStack.popPose();

        poseStack.pushPose();
        poseStack.mulPose(Axis.ZP.rotationDegrees(-20.0f));
        poseStack.mulPose(Axis.YP.rotationDegrees(time * 1.1f));
        drawBox(vc, poseStack, -7.2f, -0.1f, -7.2f, 14.4f, 0.2f, 0.5f, 0.25f, 0.65f, 0.98f, 0.70f, 0xF000F0);
        drawBox(vc, poseStack, -7.2f, -0.1f, 6.7f, 14.4f, 0.2f, 0.5f, 0.25f, 0.65f, 0.98f, 0.70f, 0xF000F0);
        poseStack.popPose();

        poseStack.popPose();
    }

    private void renderShadowGardenPool(PoseStack poseStack, MultiBufferSource buffer, int light, float time) {
        poseStack.pushPose();
        VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucent(SHRINE_TEXTURE));
        drawBox(vc, poseStack, -12.0f, 0.06f, -12.0f, 24.0f, 0.12f, 24.0f, 0.03f, 0.02f, 0.06f, 0.82f, light);
        poseStack.popPose();
    }

    private void renderMutualLoveSwords(PoseStack poseStack, MultiBufferSource buffer, int light, float time) {
        poseStack.pushPose();
        VertexConsumer vc = buffer.getBuffer(RenderType.entityTranslucent(SHRINE_TEXTURE));
        for (int i = 0; i < 16; i++) {
            double ang = (Math.PI * 2.0 * i) / 16.0;
            float r = (i % 2 == 0) ? 5.0f : 8.5f;
            float sx = (float) (Math.cos(ang) * r);
            float sz = (float) (Math.sin(ang) * r);
            drawBox(vc, poseStack, sx - 0.1f, 0.0f, sz - 0.1f, 0.2f, 2.8f, 0.2f, 0.88f, 0.88f, 0.96f, 0.92f, 0xF000F0);
        }
        poseStack.popPose();
    }

    private void drawBox(VertexConsumer vc, PoseStack ps, float x, float y, float z,
                         float w, float h, float d, float r, float g, float b, float a, int light) {
        Matrix4f m = ps.last().pose();
        float x2 = x + w, y2 = y + h, z2 = z + d;
        quad(vc, m, x, y, z2, x2, y, z2, x2, y2, z2, x, y2, z2, r, g, b, a, light, 0, 0, 1);
        quad(vc, m, x2, y, z, x, y, z, x, y2, z, x2, y2, z, r, g, b, a, light, 0, 0, -1);
        quad(vc, m, x, y, z, x, y, z2, x, y2, z2, x, y2, z, r, g, b, a, light, -1, 0, 0);
        quad(vc, m, x2, y, z2, x2, y, z, x2, y2, z, x2, y2, z2, r, g, b, a, light, 1, 0, 0);
        quad(vc, m, x, y2, z2, x2, y2, z2, x2, y2, z, x, y2, z, r, g, b, a, light, 0, 1, 0);
        quad(vc, m, x, y, z, x2, y, z, x2, y, z2, x, y, z2, r, g, b, a, light, 0, -1, 0);
    }

    private void quad(VertexConsumer vc, Matrix4f m,
                      float x1, float y1, float z1, float x2, float y2, float z2,
                      float x3, float y3, float z3, float x4, float y4, float z4,
                      float r, float g, float b, float a, int light, float nx, float ny, float nz) {
        vc.vertex(m, x1, y1, z1).color(r, g, b, a).uv(0, 0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(nx, ny, nz).endVertex();
        vc.vertex(m, x2, y2, z2).color(r, g, b, a).uv(1, 0).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(nx, ny, nz).endVertex();
        vc.vertex(m, x3, y3, z3).color(r, g, b, a).uv(1, 1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(nx, ny, nz).endVertex();
        vc.vertex(m, x4, y4, z4).color(r, g, b, a).uv(0, 1).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(nx, ny, nz).endVertex();
    }

    private void spawnBoundaryCurtain(ClientLevel level, DomainEntity entity, Vec3 playerPos) {
        double radius = entity.getRadius();
        int points = ModConfig.CLIENT.domainParticleLodDensity.get();
        if (playerPos.distanceTo(entity.position()) > radius + 128.0) return;
        for (int i = 0; i < points; i++) {
            double angle = (2.0 * Math.PI * i) / points;
            double px = entity.getX() + Math.cos(angle) * radius;
            double pz = entity.getZ() + Math.sin(angle) * radius;
            if (playerPos.distanceToSqr(px, entity.getY(), pz) < 64.0 * 64.0) {
                level.addParticle(ModParticles.DOMAIN_SLASH_SPARK.get(),
                        px, entity.getY() + (i % 7) * 1.4, pz, 0, 0.08, 0);
                if (i % 4 == 0) {
                    level.addParticle(ParticleTypes.CRIMSON_SPORE, px, entity.getY() + 2.0, pz, 0, 0.04, 0);
                }
            }
        }
    }

    private void spawnDomainAmbientVfx(ClientLevel level, DomainEntity entity, Vec3 playerPos, ResourceLocation domainId) {
        if (playerPos.distanceTo(entity.position()) > entity.getRadius() + 32.0) return;
        var rnd = level.random;
        if (domainId.equals(MalevolentShrineDomain.ID)) {
            // Peeling slash sparks around shrine + random ground slash marks near player
            for (int i = 0; i < 6; i++) {
                double sx = entity.getX() + (rnd.nextDouble() - 0.5) * 8.0;
                double sy = entity.getY() + 5.0 + rnd.nextDouble() * 6.0;
                double sz = entity.getZ() + (rnd.nextDouble() - 0.5) * 8.0;
                level.addParticle(ModParticles.DOMAIN_SLASH_SPARK.get(), sx, sy, sz,
                        (rnd.nextDouble() - 0.5) * 0.25, -0.05, (rnd.nextDouble() - 0.5) * 0.25);
            }
            for (int i = 0; i < 4; i++) {
                double gx = playerPos.x + (rnd.nextDouble() - 0.5) * 18.0;
                double gz = playerPos.z + (rnd.nextDouble() - 0.5) * 18.0;
                level.addParticle(ParticleTypes.SWEEP_ATTACK, gx, playerPos.y + 0.15, gz, 0, 0, 0);
                level.addParticle(ModParticles.GRID_SLASH_LINE.get(), gx, playerPos.y + 0.2, gz, 0, 0.02, 0);
            }
        } else if (domainId.equals(UnlimitedVoidDomain.ID)) {
            for (int i = 0; i < 5; i++) {
                level.addParticle(ParticleTypes.END_ROD,
                        playerPos.x + (rnd.nextDouble() - 0.5) * 16.0,
                        playerPos.y + rnd.nextDouble() * 6.0,
                        playerPos.z + (rnd.nextDouble() - 0.5) * 16.0, 0, 0.02, 0);
            }
        } else if (domainId.equals(ChimeraShadowGardenDomain.ID)) {
            for (int i = 0; i < 6; i++) {
                level.addParticle(ParticleTypes.SQUID_INK,
                        playerPos.x + (rnd.nextDouble() - 0.5) * 14.0,
                        playerPos.y + 0.3,
                        playerPos.z + (rnd.nextDouble() - 0.5) * 14.0, 0, 0.08, 0);
            }
        }
    }

    public static void spawnGridSlashParticles(Vec3 center, Vec3 forward, int size, double spacing) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        Vec3 right = forward.cross(new Vec3(0, 1, 0));
        if (right.lengthSqr() < 1e-4) right = new Vec3(1, 0, 0);
        else right = right.normalize();
        Vec3 up = right.cross(forward).normalize();
        double half = (size - 1) * spacing * 0.5;
        for (int i = 0; i < size; i++) {
            double offset = -half + i * spacing;
            for (double t = -half; t <= half; t += 0.25) {
                Vec3 p1 = center.add(right.scale(offset)).add(up.scale(t));
                Vec3 p2 = center.add(up.scale(offset)).add(right.scale(t));
                level.addParticle(ModParticles.GRID_SLASH_LINE.get(), p1.x, p1.y, p1.z, 0, 0, 0);
                level.addParticle(ModParticles.GRID_SLASH_LINE.get(), p2.x, p2.y, p2.z, 0, 0, 0);
            }
        }
        level.addParticle(ParticleTypes.SWEEP_ATTACK, center.x, center.y, center.z, 0, 0, 0);
    }

    public static void spawnWorldRiftParticles(Vec3 start, Vec3 dir, double range) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        Vec3 side = dir.cross(new Vec3(0, 1, 0));
        if (side.lengthSqr() < 1e-4) side = new Vec3(1, 0, 0);
        else side = side.normalize();

        for (double d = 1.0; d <= range; d += 0.3) {
            Vec3 pos = start.add(dir.scale(d));
            level.addParticle(ModParticles.WORLD_RIFT_LINE.get(), pos.x, pos.y, pos.z, 0, 0, 0);
            level.addParticle(ParticleTypes.END_ROD, pos.x, pos.y, pos.z, 0, 0, 0);
            if (((int) (d * 3)) % 3 == 0) {
                Vec3 edge1 = pos.add(side.scale(0.8));
                Vec3 edge2 = pos.subtract(side.scale(0.8));
                level.addParticle(ParticleTypes.SQUID_INK, edge1.x, edge1.y, edge1.z, 0, 0.03, 0);
                level.addParticle(ParticleTypes.SQUID_INK, edge2.x, edge2.y, edge2.z, 0, 0.03, 0);
            }
        }
        level.addParticle(ParticleTypes.FLASH, start.x + dir.x * 2.0, start.y + dir.y * 2.0, start.z + dir.z * 2.0, 0, 0, 0);
    }

    @Override
    public ResourceLocation getTextureLocation(DomainEntity entity) {
        return SHRINE_TEXTURE;
    }
}
