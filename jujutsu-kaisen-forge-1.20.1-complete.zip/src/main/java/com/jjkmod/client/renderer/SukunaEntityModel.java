package com.jjkmod.client.renderer;

import com.jjkmod.JJKMod;
import com.jjkmod.entity.SukunaEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class SukunaEntityModel extends GeoModel<SukunaEntity> {
    @Override
    public ResourceLocation getModelResource(SukunaEntity animatable) {
        return new ResourceLocation(JJKMod.MODID, "geo/sukuna.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(SukunaEntity animatable) {
        return new ResourceLocation(JJKMod.MODID, "textures/entity/sukuna.png");
    }

    @Override
    public ResourceLocation getAnimationResource(SukunaEntity animatable) {
        return new ResourceLocation(JJKMod.MODID, "animations/sukuna.animation.json");
    }
}
