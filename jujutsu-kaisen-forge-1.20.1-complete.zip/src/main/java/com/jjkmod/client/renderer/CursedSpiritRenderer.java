package com.jjkmod.client.renderer;

import com.jjkmod.JJKMod;
import com.jjkmod.entity.CursedSpiritEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CursedSpiritRenderer extends HumanoidMobRenderer<CursedSpiritEntity, HumanoidModel<CursedSpiritEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(JJKMod.MODID, "textures/entity/cursed_spirit.png");

    public CursedSpiritRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(CursedSpiritEntity entity) {
        return TEXTURE;
    }
}
