package com.jjkmod.client.renderer;

import com.jjkmod.entity.SukunaEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class SukunaEntityRenderer extends GeoEntityRenderer<SukunaEntity> {
    public SukunaEntityRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new SukunaEntityModel());
        this.shadowRadius = 0.6f;
    }
}
