package com.jjkmod.client.renderer;

import com.jjkmod.entity.RikaEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class RikaEntityRenderer extends GeoEntityRenderer<RikaEntity> {
    public RikaEntityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new RikaEntityModel());
        this.shadowRadius = 1.0f;
    }
}
