package com.jjkmod.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;

public class SlashLineParticle extends TextureSheetParticle {
    protected SlashLineParticle(ClientLevel level, double x, double y, double z,
                                double xd, double yd, double zd, SpriteSet sprites) {
        super(level, x, y, z, xd, yd, zd);
        this.lifetime = 16;
        this.gravity = 0.0f;
        this.quadSize = 0.28f;
        this.rCol = 1.0f;
        this.gCol = 0.22f;
        this.bCol = 0.28f;
        this.alpha = 0.95f;
        this.pickSprite(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        this.alpha = Math.max(0.05f, 1.0f - ((float) this.age / (float) this.lifetime));
        this.quadSize *= 0.97f;
    }

    @Override
    public int getLightColor(float partialTick) {
        return 0xF000F0; // Full-bright glowing slash particles
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                       double x, double y, double z, double xd, double yd, double zd) {
            return new SlashLineParticle(level, x, y, z, xd, yd, zd, sprites);
        }
    }
}
