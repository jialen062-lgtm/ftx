package com.jjkmod.client.gui;

import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.client.ClientCursedDataCache;
import com.jjkmod.registry.CharacterRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

public class CursedHudOverlay {
    public static final IGuiOverlay HUD = (gui, gfx, partialTick, width, height) -> {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        PlayerCursedData data = ClientCursedDataCache.get();
        int x = 12;
        int y = 12;

        String charName = CharacterRegistry.get(data.getCurrentCharacter())
                .map(def -> Component.translatable(def.displayNameKey()).getString())
                .orElse("Sukuna");

        gfx.fill(x - 4, y - 4, x + 150, y + 48, 0x88000000);
        gfx.drawString(mc.font, charName + " | Fingers: " + data.getFingerCount() + "/20", x, y, 0xFFEFD6D2);

        // Cursed Energy Bar
        double ratio = data.getMaxCursedEnergy() > 0 ? data.getCursedEnergy() / data.getMaxCursedEnergy() : 0.0;
        int barW = 140;
        gfx.fill(x, y + 14, x + barW, y + 24, 0xFF222222);
        gfx.fill(x, y + 14, x + (int) (barW * Math.min(1.0, ratio)), y + 24, 0xFFB8002E);
        gfx.drawString(mc.font, String.format("CE: %.0f / %.0f", data.getCursedEnergy(), data.getMaxCursedEnergy()),
                x, y + 28, 0xFFFFFFFF);
    };
}
