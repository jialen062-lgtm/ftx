package com.jjkmod.client.gui;

import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.SwitchCharacterC2SPacket;
import com.jjkmod.registry.CharacterRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class CharacterSelectScreen extends Screen {
    public CharacterSelectScreen() {
        super(Component.translatable("screen.jjkmod.character_select"));
    }

    public static void open() {
        Minecraft.getInstance().setScreen(new CharacterSelectScreen());
    }

    @Override
    protected void init() {
        List<CharacterRegistry.CharacterDefinition> chars = CharacterRegistry.getAll();
        int btnW = 160;
        int btnH = 24;
        int startY = this.height / 2 - (chars.size() * 30) / 2;

        for (int i = 0; i < chars.size(); i++) {
            CharacterRegistry.CharacterDefinition def = chars.get(i);
            this.addRenderableWidget(Button.builder(Component.translatable(def.displayNameKey()), btn -> {
                ModNetwork.sendToServer(new SwitchCharacterC2SPacket(def.id()));
                this.onClose();
            }).bounds(this.width / 2 - btnW / 2, startY + i * 30, btnW, btnH).build());
        }
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(gfx);
        gfx.drawCenteredString(this.font, this.title, this.width / 2, 30, 0xFFFFFF);
        super.render(gfx, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
