package com.jjkmod.client;

import com.jjkmod.capability.PlayerCursedData;
import net.minecraft.nbt.CompoundTag;

public class ClientCursedDataCache {
    private static final PlayerCursedData DATA = new PlayerCursedData();

    public static void updateFromNbt(CompoundTag tag) {
        if (tag != null) {
            DATA.loadNBT(tag);
        }
    }

    public static PlayerCursedData get() {
        return DATA;
    }
}
