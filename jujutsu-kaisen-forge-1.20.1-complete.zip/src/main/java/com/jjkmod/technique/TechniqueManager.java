package com.jjkmod.technique;

import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.config.ModConfig;
import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.SyncCursedDataS2CPacket;
import com.jjkmod.registry.ModCapabilities;
import com.jjkmod.registry.TechniqueRegistry;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.*;

public class TechniqueManager {
    private static final List<ScheduledTask> PENDING_TASKS = new ArrayList<>();
    private static final Set<UUID> WINDING_UP_PLAYERS = new HashSet<>();

    public static class ScheduledTask {
        public int ticksRemaining;
        public final Runnable action;

        public ScheduledTask(int ticksRemaining, Runnable action) {
            this.ticksRemaining = ticksRemaining;
            this.action = action;
        }
    }

    public static void schedule(int delayTicks, Runnable action) {
        if (delayTicks <= 0) action.run();
        else PENDING_TASKS.add(new ScheduledTask(delayTicks, action));
    }

    public static void setWindingUp(UUID playerId, boolean windingUp) {
        if (windingUp) WINDING_UP_PLAYERS.add(playerId);
        else WINDING_UP_PLAYERS.remove(playerId);
    }

    public static boolean isWindingUp(UUID playerId) {
        return WINDING_UP_PLAYERS.contains(playerId);
    }

    public static void tick() {
        if (PENDING_TASKS.isEmpty()) return;
        Iterator<ScheduledTask> it = PENDING_TASKS.iterator();
        List<Runnable> toRun = new ArrayList<>();
        while (it.hasNext()) {
            ScheduledTask task = it.next();
            task.ticksRemaining--;
            if (task.ticksRemaining <= 0) {
                toRun.add(task.action);
                it.remove();
            }
        }
        toRun.forEach(Runnable::run);
    }

    public static void tryCastTechnique(ServerPlayer player, ResourceLocation techniqueId) {
        if (isWindingUp(player.getUUID())) {
            player.displayClientMessage(Component.translatable("message.jjkmod.already_casting"), true);
            return;
        }

        Optional<ITechnique> opt = TechniqueRegistry.get(techniqueId);
        if (opt.isEmpty()) return;
        ITechnique tech = opt.get();

        player.getCapability(ModCapabilities.PLAYER_CURSED_DATA).ifPresent(data -> {
            if (data.getFingerCount() < tech.getRequiredFingers()) {
                player.displayClientMessage(Component.translatable("message.jjkmod.need_finger"), true);
                return;
            }
            if (!data.isTechniqueUnlocked(techniqueId)) {
                player.displayClientMessage(Component.translatable("message.jjkmod.technique_locked"), true);
                return;
            }

            int cd = data.getCooldown(techniqueId);
            if (cd > 0 && (!player.isCreative() || ModConfig.COMMON.creativeModeCooldownApplies.get())) {
                player.displayClientMessage(Component.translatable("message.jjkmod.on_cooldown", String.format("%.1f", cd / 20.0f)), true);
                return;
            }

            double cost = tech.getCursedEnergyCost();
            if (!player.isCreative() && data.getCursedEnergy() < cost) {
                player.displayClientMessage(Component.translatable("message.jjkmod.not_enough_energy"), true);
                return;
            }

            if (!player.isCreative()) {
                data.setCursedEnergy(data.getCursedEnergy() - cost);
            }
            if (!player.isCreative() || ModConfig.COMMON.creativeModeCooldownApplies.get()) {
                data.setCooldown(techniqueId, tech.getCooldownTicks(player));
            }

            tech.cast(player, data);
            ModNetwork.sendToPlayer(new SyncCursedDataS2CPacket(data), player);
        });
    }
}
