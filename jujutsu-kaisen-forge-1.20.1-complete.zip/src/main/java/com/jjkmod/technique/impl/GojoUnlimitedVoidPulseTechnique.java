package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.technique.ITechnique;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class GojoUnlimitedVoidPulseTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "unlimited_void_pulse");

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.unlimited_void_pulse"; }
    @Override public double getCursedEnergyCost() { return 80.0; }
    @Override public int getCooldownTicks(ServerPlayer player) { return 80; }
    @Override public int getRequiredFingers() { return 0; }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        ServerLevel level = player.serverLevel();
        AABB box = player.getBoundingBox().inflate(10.0);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != player)) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 5));
            target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 1));
            target.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 100, 4));
        }
    }
}
