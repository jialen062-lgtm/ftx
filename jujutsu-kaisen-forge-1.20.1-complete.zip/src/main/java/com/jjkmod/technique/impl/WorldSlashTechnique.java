package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.config.ModConfig;
import com.jjkmod.domain.DomainManager;
import com.jjkmod.domain.impl.MalevolentShrineDomain;
import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.WorldSlashVisualS2CPacket;
import com.jjkmod.registry.ModSounds;
import com.jjkmod.technique.ITechnique;
import com.jjkmod.technique.TechniqueManager;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class WorldSlashTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "world_slash");
    public static final ResourceKey<DamageType> WORLD_SLASH_DAMAGE_TYPE =
            ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(JJKMod.MODID, "world_slash"));

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.world_slash"; }
    @Override public double getCursedEnergyCost() { return ModConfig.COMMON.worldSlashCursedEnergyCost.get(); }
    @Override public int getCooldownTicks(ServerPlayer player) { return ModConfig.COMMON.worldSlashCooldown.get(); }
    @Override public int getRequiredFingers() { return 1; }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        int windup = ModConfig.COMMON.worldSlashWindupTicks.get();
        TechniqueManager.setWindingUp(player.getUUID(), true);

        if (windup > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, windup, 3, false, false));
            player.addEffect(new MobEffectInstance(MobEffects.GLOWING, windup, 0, false, false));
            player.displayClientMessage(Component.translatable("message.jjkmod.world_slash_windup"), true);
        }

        boolean inDomain = DomainManager.isInsidePlayerDomain(player, MalevolentShrineDomain.ID);
        double fingerMult = data.getTechniqueDamageMultiplier();
        double domainMult = inDomain ? ModConfig.COMMON.worldSlashDomainDamageMultiplier.get() : 1.0;
        float finalDamage = (float) (ModConfig.COMMON.worldSlashDamage.get() * fingerMult * domainMult);

        TechniqueManager.schedule(windup, () -> {
            TechniqueManager.setWindingUp(player.getUUID(), false);
            if (!player.isAlive()) return;
            executeWorldSlash(player, finalDamage);
        });
    }

    private void executeWorldSlash(ServerPlayer player, float damage) {
        ServerLevel level = player.serverLevel();
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle().normalize();
        double maxRange = ModConfig.COMMON.worldSlashRange.get();

        if (!ModConfig.COMMON.worldSlashPierceBlocks.get()) {
            HitResult blockHit = level.clip(new ClipContext(start, start.add(dir.scale(maxRange)),
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (blockHit.getType() != HitResult.Type.MISS) {
                maxRange = start.distanceTo(blockHit.getLocation());
            }
        }

        double cosThreshold = Math.cos(Math.toRadians(ModConfig.COMMON.worldSlashAngle.get() * 0.5));
        AABB searchBox = new AABB(start, start.add(dir.scale(maxRange))).inflate(4.0);
        boolean livingOnly = ModConfig.COMMON.worldSlashLivingOnly.get();
        boolean ignoreArmor = ModConfig.COMMON.worldSlashIgnoreArmor.get();
        boolean ignoreIFrames = ModConfig.COMMON.worldSlashIgnoreInvulnerability.get();

        DamageSource source = ignoreArmor
                ? new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(WORLD_SLASH_DAMAGE_TYPE), player)
                : level.damageSources().playerAttack(player);

        double finalRange = maxRange;
        List<Entity> candidates = level.getEntities(player, searchBox, e -> {
            if (livingOnly && !(e instanceof LivingEntity)) return false;
            Vec3 toTarget = e.getBoundingBox().getCenter().subtract(start);
            double dist = toTarget.length();
            if (dist > finalRange || dist < 0.1) return false;
            return toTarget.normalize().dot(dir) >= cosThreshold;
        });

        for (Entity target : candidates) {
            if (ignoreIFrames) {
                target.invulnerableTime = 0;
            }
            target.hurt(source, damage);
        }

        ModNetwork.sendToTrackingAndSelf(new WorldSlashVisualS2CPacket(start, dir, maxRange), player);
        level.playSound(null, player.blockPosition(), ModSounds.SLASH_WORLD.get(), SoundSource.PLAYERS, 1.8f, 0.9f);
    }
}
