package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.config.ModConfig;
import com.jjkmod.registry.ModCapabilities;
import com.jjkmod.registry.ModSounds;
import com.jjkmod.technique.ITechnique;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class BatsuTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "batsu");

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.batsu"; }
    @Override public double getCursedEnergyCost() { return ModConfig.COMMON.batsuCost.get(); }
    @Override public int getCooldownTicks(ServerPlayer player) { return ModConfig.COMMON.batsuCooldown.get(); }
    @Override public int getRequiredFingers() { return 1; }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        ServerLevel level = player.serverLevel();
        Vec3 center = player.getEyePosition().add(player.getLookAngle().scale(4.5));
        AABB box = new AABB(center, center).inflate(4.0);

        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box, e -> e != player && e.isAlive());
        double fingerMult = data.getTechniqueDamageMultiplier();
        for (LivingEntity target : targets) {
            applyBatsuDamage(target, player, data.getCursedEnergy(), fingerMult);
        }

        level.playSound(null, player.blockPosition(), ModSounds.SLASH_BATSU.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
    }

    /**
     * Calculates Batsu damage per target based on target current health and cursed energy gap.
     */
    public static void applyBatsuDamage(LivingEntity target, Entity attacker, double casterEnergy, double fingerMult) {
        double targetEnergy = target.getMaxHealth() * 20.0;
        if (target instanceof ServerPlayer sp) {
            targetEnergy = sp.getCapability(ModCapabilities.PLAYER_CURSED_DATA)
                    .map(PlayerCursedData::getCursedEnergy)
                    .orElse(targetEnergy);
        }

        double energyGap = Math.max(0.0, (casterEnergy - targetEnergy) / Math.max(100.0, casterEnergy));
        double healthFactor = Math.min(1.5, target.getHealth() / 40.0);
        double adaptiveMult = Math.min(ModConfig.COMMON.batsuMaxMultiplier.get(), 1.0 + energyGap * 1.5 + healthFactor * 0.5);

        float damage = (float) (ModConfig.COMMON.batsuBaseDamage.get() * adaptiveMult * fingerMult);
        target.hurt(attacker != null ? target.damageSources().mobAttack((LivingEntity) attacker) : target.damageSources().magic(), damage);
    }
}
