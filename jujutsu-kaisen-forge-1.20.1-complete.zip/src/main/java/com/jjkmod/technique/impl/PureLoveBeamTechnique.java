package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.config.ModConfig;
import com.jjkmod.entity.RikaEntity;
import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.WorldSlashVisualS2CPacket;
import com.jjkmod.registry.ModSounds;
import com.jjkmod.technique.ITechnique;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class PureLoveBeamTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "pure_love_beam");

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.pure_love_beam"; }
    @Override public double getCursedEnergyCost() { return 280.0; }
    @Override public int getCooldownTicks(ServerPlayer player) { return 220; }
    @Override public int getRequiredFingers() { return 0; }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        ServerLevel level = player.serverLevel();
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle().normalize();
        double range = ModConfig.COMMON.pureLoveBeamRange.get();

        boolean hasRika = !level.getEntitiesOfClass(RikaEntity.class,
                new AABB(player.blockPosition()).inflate(32.0),
                r -> player.getUUID().equals(r.getOwnerUuid())).isEmpty();

        float dmg = (float) (ModConfig.COMMON.pureLoveBeamDamage.get() * (hasRika ? 1.5 : 1.0));
        AABB search = new AABB(start, start.add(dir.scale(range))).inflate(3.0);

        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, search, e -> {
            if (e == player || !e.isAlive()) return false;
            Vec3 to = e.getBoundingBox().getCenter().subtract(start);
            double d = to.length();
            return d <= range && d > 0.2 && to.normalize().dot(dir) >= 0.92;
        });

        for (LivingEntity t : targets) {
            t.invulnerableTime = 0;
            t.hurt(level.damageSources().magic(), dmg);
        }

        ModNetwork.sendToTrackingAndSelf(new WorldSlashVisualS2CPacket(start, dir, range), player);
        level.playSound(null, player.blockPosition(), ModSounds.PURE_LOVE_BEAM.get(), SoundSource.PLAYERS, 1.5f, 1.0f);
    }
}
