package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.config.ModConfig;
import com.jjkmod.entity.RikaEntity;
import com.jjkmod.registry.ModEntities;
import com.jjkmod.technique.ITechnique;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.AABB;

import java.util.List;

public class RikaManifestTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "rika_manifest");

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.rika_manifest"; }
    @Override public double getCursedEnergyCost() { return 120.0; }
    @Override public int getCooldownTicks(ServerPlayer player) { return 200; }
    @Override public int getRequiredFingers() { return 0; }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        ServerLevel level = player.serverLevel();
        List<RikaEntity> existing = level.getEntitiesOfClass(RikaEntity.class,
                new AABB(player.blockPosition()).inflate(64.0),
                r -> player.getUUID().equals(r.getOwnerUuid()));

        if (!existing.isEmpty()) {
            existing.forEach(RikaEntity::triggerCompleteManifestation);
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 1));
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 1));
            player.displayClientMessage(Component.translatable("message.jjkmod.rika_complete"), true);
        } else {
            RikaEntity rika = ModEntities.RIKA.get().create(level);
            if (rika != null) {
                rika.setPos(player.getX() + 1.8, player.getY(), player.getZ() + 1.8);
                rika.setOwner(player, ModConfig.COMMON.rikaDurationTicks.get());
                level.addFreshEntity(rika);
                player.displayClientMessage(Component.translatable("message.jjkmod.rika_summoned"), true);
            }
        }
    }
}
