package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.technique.ITechnique;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class CursedSpeechTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "cursed_speech");

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.cursed_speech"; }
    @Override public double getCursedEnergyCost() { return 110.0; }
    @Override public int getCooldownTicks(ServerPlayer player) { return 120; }
    @Override public int getRequiredFingers() { return 0; }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        ServerLevel level = player.serverLevel();
        Vec3 center = player.getEyePosition().add(player.getLookAngle().scale(6.0));
        AABB box = new AABB(center, center).inflate(6.0);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != player && e.isAlive())) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 6));
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 2));
            target.hurt(level.damageSources().sonicBoom(player), 10.0f);
        }
    }
}
