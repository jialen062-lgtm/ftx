package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.technique.ITechnique;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

public class YutaCopyBladeTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "true_mutual_love_blade");

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.true_mutual_love_blade"; }
    @Override public double getCursedEnergyCost() { return 90.0; }
    @Override public int getCooldownTicks(ServerPlayer player) { return 100; }
    @Override public int getRequiredFingers() { return 0; }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 120, 1));
        ServerLevel level = player.serverLevel();
        AABB box = player.getBoundingBox().inflate(5.0);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != player)) {
            target.hurt(level.damageSources().playerAttack(player), 12.0f);
        }
    }
}
