package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.technique.ITechnique;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Wolf;

public class MegumiShadowSummonTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "chimera_shadow_summon");

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.chimera_shadow_summon"; }
    @Override public double getCursedEnergyCost() { return 100.0; }
    @Override public int getCooldownTicks(ServerPlayer player) { return 160; }
    @Override public int getRequiredFingers() { return 0; }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        ServerLevel level = player.serverLevel();
        Wolf shikigami = EntityType.WOLF.create(level);
        if (shikigami != null) {
            shikigami.setPos(player.getX() + 1.5, player.getY(), player.getZ() + 1.5);
            shikigami.tame(player);
            level.addFreshEntity(shikigami);
        }
    }
}
