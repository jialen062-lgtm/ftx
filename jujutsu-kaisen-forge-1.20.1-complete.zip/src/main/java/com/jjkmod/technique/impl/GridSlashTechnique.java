package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.config.ModConfig;
import com.jjkmod.domain.DomainManager;
import com.jjkmod.domain.impl.MalevolentShrineDomain;
import com.jjkmod.network.ModNetwork;
import com.jjkmod.network.packet.GridSlashVisualS2CPacket;
import com.jjkmod.registry.ModSounds;
import com.jjkmod.technique.ITechnique;
import com.jjkmod.technique.TechniqueManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class GridSlashTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "grid_slash");

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.grid_slash"; }
    @Override public double getCursedEnergyCost() { return ModConfig.COMMON.gridSlashCursedEnergyCost.get(); }
    @Override public int getRequiredFingers() { return 1; }

    @Override
    public int getCooldownTicks(ServerPlayer player) {
        int baseCd = ModConfig.COMMON.gridSlashCooldown.get();
        if (DomainManager.isInsidePlayerDomain(player, MalevolentShrineDomain.ID)) {
            return (int) Math.max(1, Math.round(baseCd * ModConfig.COMMON.gridSlashDomainCooldownMultiplier.get()));
        }
        return baseCd;
    }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        ServerLevel level = player.serverLevel();
        Vec3 forward = player.getLookAngle().normalize();
        Vec3 center = player.getEyePosition().add(forward.scale(ModConfig.COMMON.gridSlashDistance.get()));

        int size = ModConfig.COMMON.gridSlashSize.get();
        double spacing = ModConfig.COMMON.gridSlashSpacing.get();
        int delay = ModConfig.COMMON.gridSlashDelayTicks.get();
        int hits = ModConfig.COMMON.gridSlashHits.get();

        double halfSpan = (size - 1) * spacing * 0.5 + 1.0;
        AABB gridBox = new AABB(center, center).inflate(halfSpan, halfSpan, halfSpan);

        // Send visual grid packet to client(s)
        ModNetwork.sendToTrackingAndSelf(new GridSlashVisualS2CPacket(center, forward, size, spacing), player);
        level.playSound(null, player.blockPosition(), ModSounds.SLASH_GRID.get(), SoundSource.PLAYERS, 1.3f, 1.0f);

        boolean inDomain = DomainManager.isInsidePlayerDomain(player, MalevolentShrineDomain.ID);
        double fingerMult = data.getTechniqueDamageMultiplier();
        double domainMult = inDomain ? ModConfig.COMMON.gridSlashDomainDamageMultiplier.get() : 1.0;
        float damagePerHit = (float) (ModConfig.COMMON.gridSlashDamagePerHit.get() * fingerMult * domainMult);

        for (int i = 0; i < hits; i++) {
            int hitDelay = delay + i * 4;
            TechniqueManager.schedule(hitDelay, () -> {
                if (!player.isAlive()) return;
                List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, gridBox, e -> e != player && e.isAlive());
                for (LivingEntity target : targets) {
                    target.invulnerableTime = 0;
                    target.hurt(level.damageSources().playerAttack(player), damagePerHit);
                }
                level.playSound(null, center.x, center.y, center.z, ModSounds.SLASH_GRID.get(), SoundSource.PLAYERS, 0.8f, 1.2f);
            });
        }
    }
}
