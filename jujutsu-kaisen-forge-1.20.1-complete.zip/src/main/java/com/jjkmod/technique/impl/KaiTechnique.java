package com.jjkmod.technique.impl;

import com.jjkmod.JJKMod;
import com.jjkmod.capability.PlayerCursedData;
import com.jjkmod.config.ModConfig;
import com.jjkmod.registry.ModSounds;
import com.jjkmod.technique.ITechnique;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class KaiTechnique implements ITechnique {
    public static final ResourceLocation ID = new ResourceLocation(JJKMod.MODID, "kai");

    @Override public ResourceLocation getId() { return ID; }
    @Override public String getDisplayNameKey() { return "technique.jjkmod.kai"; }
    @Override public double getCursedEnergyCost() { return ModConfig.COMMON.kaiCost.get(); }
    @Override public int getCooldownTicks(ServerPlayer player) { return ModConfig.COMMON.kaiCooldown.get(); }
    @Override public int getRequiredFingers() { return 1; }

    @Override
    public void cast(ServerPlayer player, PlayerCursedData data) {
        ServerLevel level = player.serverLevel();
        Vec3 center = player.getEyePosition().add(player.getLookAngle().scale(4.0));
        AABB box = new AABB(center, center).inflate(4.5);

        double mult = data.getTechniqueDamageMultiplier();
        List<Entity> targets = level.getEntities(player, box, KaiTechnique::isNonLivingSliceTarget);
        for (Entity e : targets) {
            sliceNonLiving(e, player, mult);
        }

        if (ModConfig.COMMON.kaiBreakFragileBlocks.get()) {
            breakNearbyFragileBlocks(level, BlockPos.containing(center), 3, player);
        }

        level.playSound(null, player.blockPosition(), ModSounds.SLASH_KAI.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
    }

    public static boolean isNonLivingSliceTarget(Entity e) {
        return e instanceof ItemEntity
                || e instanceof AbstractArrow
                || e instanceof Projectile
                || e instanceof Boat
                || e instanceof AbstractMinecart
                || e instanceof ArmorStand;
    }

    public static void sliceNonLiving(Entity target, Entity attacker, double damageMultiplier) {
        float dmg = (float) (ModConfig.COMMON.kaiDamage.get() * damageMultiplier);
        if (target instanceof ArmorStand stand) {
            stand.hurt(target.damageSources().generic(), dmg);
        } else {
            target.hurt(target.damageSources().generic(), dmg);
            target.discard();
        }
    }

    public static void breakNearbyFragileBlocks(ServerLevel level, BlockPos center, int radius, Entity breaker) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    pos.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockState state = level.getBlockState(pos);
                    if (isFragileBlock(state)) {
                        level.destroyBlock(pos, true, breaker);
                    }
                }
            }
        }
    }

    private static boolean isFragileBlock(BlockState state) {
        return state.is(BlockTags.LEAVES)
                || state.is(Blocks.GLASS)
                || state.is(Blocks.GLASS_PANE)
                || state.getBlock() instanceof CropBlock
                || state.is(BlockTags.FLOWERS)
                || state.is(Blocks.GRASS)
                || state.is(Blocks.TALL_GRASS);
    }
}
