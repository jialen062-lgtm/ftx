package com.jjkmod.technique;

import com.jjkmod.capability.PlayerCursedData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

public interface ITechnique {
    ResourceLocation getId();
    String getDisplayNameKey();
    double getCursedEnergyCost();
    int getCooldownTicks(ServerPlayer player);
    int getRequiredFingers();
    void cast(ServerPlayer player, PlayerCursedData data);
}
