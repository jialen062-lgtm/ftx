# Jujutsu Kaisen Forge 1.20.1 Mod (`jjkmod`)

环境要求：Minecraft 1.20.1 / Forge 47.2.20 (47.2.x) / Java 17 / Official Mappings / Gradle / GeckoLib 4.4.9

## 1. 资源文件路径清单（需补齐的占位美术与音频）
代码与 JSON 注册已就绪，上线前需将自制或占位资产放入以下路径：
- 音频 (OGG Mono/Stereo)：
  - `src/main/resources/assets/jjkmod/sounds/domain/sukuna_open.ogg`
  - `src/main/resources/assets/jjkmod/sounds/domain/sukuna_loop.ogg`
  - `src/main/resources/assets/jjkmod/sounds/slash/kai.ogg`
  - `src/main/resources/assets/jjkmod/sounds/slash/batsu.ogg`
  - `src/main/resources/assets/jjkmod/sounds/slash/grid.ogg`
  - `src/main/resources/assets/jjkmod/sounds/slash/world.ogg`
  - `src/main/resources/assets/jjkmod/sounds/item/finger_eat.ogg`
  - `src/main/resources/assets/jjkmod/sounds/item/character_switch.ogg`
- GeckoLib 模型与动画：
  - `src/main/resources/assets/jjkmod/geo/sukuna.geo.json`
  - `src/main/resources/assets/jjkmod/animations/sukuna.animation.json` (`animation.sukuna.idle`, `animation.sukuna.hand_sign`, `animation.sukuna.domain_expand`)
  - `src/main/resources/assets/jjkmod/textures/entity/sukuna.png`
  - `src/main/resources/assets/jjkmod/textures/entity/cursed_spirit.png`
- 物品与 HUD 贴图：
  - `src/main/resources/assets/jjkmod/textures/item/sukuna_finger.png`
  - `src/main/resources/assets/jjkmod/textures/item/character_switch_book.png`
  - `src/main/resources/assets/jjkmod/textures/gui/hud_sukuna.png`（及 `gojo`、`megumi`、`yuta`）

## 2. 核心配置项 (`config/jjkmod-common.toml` / `jjkmod-client.toml`)
- **咒力与创造模式**：`baseMaxCursedEnergy` (1000.0)、`cursedEnergyRegenPerTick` (2.5)、`creativeModeCooldownApplies` (true)
- **手指成长与掉落**：`maxFingerCount` (20)、`perFingerMaxEnergy` (250.0)、`perFingerDamageBonus` (0.15)、`fingerBaseChance` (0.10)、`fingerPerLevelBonus` (0.02)、`fingerMaxChance` (0.50)
- **解 / 捌**：`kaiDamage`、`kaiCost`、`kaiCooldown`、`kaiBreakFragileBlocks`；`batsuBaseDamage`、`batsuMaxMultiplier`、`batsuCost`、`batsuCooldown`
- **网格斩**：`gridSlashSize` (5)、`gridSlashSpacing` (1.5)、`gridSlashDistance` (6.0)、`gridSlashHits` (3)、`gridSlashDamagePerHit` (7.0)、`gridSlashDelayTicks` (10)、`gridSlashCooldown` (100)、`gridSlashCursedEnergyCost` (120.0)、`gridSlashDomainCooldownMultiplier` (0.5)、`gridSlashDomainDamageMultiplier` (1.35)
- **世界斩**：`worldSlashRange` (40.0)、`worldSlashAngle` (25.0)、`worldSlashDamage` (45.0)、`worldSlashWindupTicks` (20)、`worldSlashCooldown` (240)、`worldSlashCursedEnergyCost` (300.0)、`worldSlashIgnoreArmor` (true)、`worldSlashIgnoreInvulnerability` (true)、`worldSlashPierceBlocks` (true)、`worldSlashLivingOnly` (true)、`worldSlashDomainDamageMultiplier` (1.5)
- **领域展开**：`sukunaDomainRadius` (200.0)、`sukunaDomainDurationTicks` (600)、`sukunaDomainCooldownTicks` (1200)、`sukunaDomainCursedEnergyCost` (500.0)、`domainTickInterval` (20)、`domainBreakBlocks` (true)
- **客户端**：`domainBgmVolume` (0.75)、`domainParticleLodDensity` (128)

## 3. 完整测试步骤

1. **召唤 Boss / 玩家展开领域 / 离开领域 / 冷却 / 多人服务端同步**
   - 启动 `runServer` 与两个 `runClient` 加入同一局域网/专用服。
   - 使用宿傩生成蛋召唤 `SukunaEntity`，将其血量打至 50% 以下，验证自动触发手印/领域展开动画并生成 `DomainEntity`（半径 200 格，无碰撞阻挡）。
   - 玩家吃下 1 根宿傩手指后按 `R` 展开伏魔御厨子，验证客户端播放 `domain_sukuna_open` 与 `domain_sukuna_loop` BGM、空中神龛与边界粒子渲染；走出领域范围后仍可自由穿行；领域结束后进入冷却，期间再次按 `R` 提示剩余冷却秒数；第二名玩家客户端能同步看到领域实体与斩击粒子。

2. **生存击杀不同等级咒灵验证掉落概率**
   - 切换至生存模式，召唤多只 `CursedSpiritEntity`（可通过 `/data get entity` 查看 `SpiritLevel` 1~20 与 `SpiritRarity`）。
   - 统计击杀低等级（如 Lv.1，理论概率 12%）与特级（如 Lv.20，理论概率上限 50%）咒灵时的 `SukunaFingerItem` 掉落率，验证符合 `min(0.50, 0.10 + level * 0.02)`。

3. **吃 1 / 2 / 20 / 21 根手指**
   - 初始状态下按 `Z/X/C/V/R` 应提示需先吞噬至少 1 根手指。
   - 右键吃第 1 根手指：HUD 显示 `Fingers: 1/20`，`maxCursedEnergy` 升至 `1250`，聊天栏提示宿傩术式全部解锁。
   - 吃第 2 根手指：`Fingers: 2/20`，`maxCursedEnergy` 升至 `1500`，伤害倍率 `1.30`。
   - 吃到第 20 根：`Fingers: 20/20`，`maxCursedEnergy` 升至 `6000`。
   - 尝试吃第 21 根：服务端拒绝消耗物品，提示“已达到 20 根宿傩手指上限”。

4. **创造模式释放领域与四种术式不耗咒力**
   - 切换 `/gamemode creative`，记录当前 HUD 咒力值。
   - 依次按 `Z`（解）、`X`（捌）、`C`（网格斩）、`V`（世界斩）、`R`（伏魔御厨子）。
   - 验证咒力值不减少；同时验证默认 `creativeModeCooldownApplies=true` 时冷却仍生效（改为 `false` 重载后则无冷却）。

5. **角色转换书切换角色术式与领域**
   - 展开伏魔御厨子（此时 BGM 正在播放、领域实体存在）。
   - 使用 `CharacterSwitchBookItem` 右键打开选择界面切换为“五条悟”，或潜行+右键循环切换。
   - 验证：当前领域实体立即销毁、BGM 停止、`fingerCount` 与咒力上限保留、术式切换为五条悟的无量空处体系；再切回宿傩，已解锁的宿傩术式立即可用。

6. **释放网格斩验证网格粒子与多次伤害**
   - 在面前放置多个测试生物（如铁傀儡/僵尸），按 `C` 释放网格斩。
   - 验证：客户端出现 5×5 交叉粒子线网格与 `slash_grid` 音效；延迟 10 tick 后目标连续受到 3 次独立伤害判定（无敌帧被重置）；在伏魔御厨子内释放时冷却减半且单次伤害提升 1.35 倍。

7. **释放世界斩验证前摇、无视护甲、长距离判定与冷却**
   - 在 30~38 格距离外放置穿戴全套保护 IV 下界合金甲的测试生物，按 `V` 释放世界斩。
   - 验证：前摇 20 tick 期间玩家获得缓慢与发光提示，前摇期间重复按键被拦截；前摇结束触发白/黑空间裂缝粒子线与 `slash_world` 音效，目标受到无视护甲与抗性附魔的高额伤害，随后进入 240 tick 独立冷却。

8. **手指数量对网格斩 / 世界斩伤害加成**
   - 在 1 根手指（倍率 1.15）与 20 根手指（倍率 4.00）状态下分别对高血量目标释放网格斩与世界斩。
   - 对比实际扣血数值，验证与 `1 + fingerCount * 0.15` 公式一致。

9. **存档重载后数据保留**
   - 吞噬若干根手指、切换角色并消耗部分咒力后退出存档并重新进入（或重启服务端）。
   - 验证重新登录后 `fingerCount`、`maxCursedEnergy`、`currentCharacter`、`unlockedTechniques` 与冷却状态通过 Capability NBT 完整恢复并同步至 HUD。
